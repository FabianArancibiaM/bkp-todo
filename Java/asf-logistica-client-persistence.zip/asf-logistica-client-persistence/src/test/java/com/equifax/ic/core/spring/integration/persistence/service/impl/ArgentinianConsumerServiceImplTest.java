package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.ChileanConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.ChileanConsumer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class ArgentinianConsumerServiceImplTest {

    ChileanConsumerDao argentinianConsumerDao = Mockito.mock(ChileanConsumerDao.class);
    ChileanConsumerServiceImpl argentinianConsumerService = new ChileanConsumerServiceImpl();
    @Before
    public void init(){
        ReflectionTestUtils.setField(argentinianConsumerService,"chileanConsumerDao",argentinianConsumerDao);
    }
    @Test
    public void methodClass4() throws IOException {
        ChileanConsumer b =new ChileanConsumer();
        Mockito.when(argentinianConsumerDao.save(b)).thenReturn(null);
        argentinianConsumerService.insertChileanConsumer(b);
    }
}
