package com.equifax.ic.core.spring.integration.persistence.service.component;

import com.equifax.ic.core.spring.integration.persistence.component.MicroServicesIdCollector;
import com.equifax.ic.core.spring.integration.persistence.util.LatamConsumerApplicantDomain;
import com.equifax.ic.product.clientconfig.domain.impl.ServiceActivator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

/**
 * @author Alan Sandoval axs831
 * @since 27-08-2018 1.0
 */

public class MicroServicesIdCollectorTest {

    private MicroServicesIdCollector microServicesIdCollector;
    private Map<String, ApplicationContext> appContextsMap;

    private static final String IG_ID = "insightgateway";
    private static final String ANAV_ID = "anav"; //Not verified yet
    private static final String SMARTS_ID = "rules-editor-connector";
    private static final String MIT_ID = "mit-model-execution-server-rest";
    private Map<String, Object> headers;

    @Before
    public void setUp() {
        microServicesIdCollector = new MicroServicesIdCollector(){
            @Override
            protected Map<String, ApplicationContext> getApplicationContextsMap() throws Exception {
                return appContextsMap;
            }
        };
        appContextsMap = new HashMap<>();
        ApplicationContext appContext = new GenericApplicationContext();
        ServiceActivator sa1 = new ServiceActivator();
        ServiceActivator sa2 = new ServiceActivator();
        ServiceActivator sa3 = new ServiceActivator();
        ServiceActivator sa4 = new ServiceActivator();
        sa1.setApplicationId(IG_ID);
        sa1.setConfigurationElementId("11111-22222");
        sa1.setServicePath("/api/report/CLAROCHILE/HOGAR_DTH");
        sa2.setApplicationId(ANAV_ID);
        sa2.setConfigurationElementId("22222-33333");
        sa3.setApplicationId(SMARTS_ID);
        sa3.setConfigurationElementId("33333-44444");
        sa4.setApplicationId(MIT_ID);
        sa4.setConfigurationElementId("44444-55555");

        ((GenericApplicationContext) appContext).getBeanFactory().registerSingleton("11111-22222", sa1);
        ((GenericApplicationContext) appContext).getBeanFactory().registerSingleton("22222-33333", sa2);
        ((GenericApplicationContext) appContext).getBeanFactory().registerSingleton("33333-44444", sa3);
        ((GenericApplicationContext) appContext).getBeanFactory().registerSingleton("44444-55555", sa4);
        ((GenericApplicationContext) appContext).refresh();
        appContextsMap.put("CLAROCHILE_configclaro_initialbaseline_HOGARDTH", appContext);

        configHeader();

        ReflectionTestUtils.invokeMethod(microServicesIdCollector, "microServicesMapBuilder");
    }

    private void configHeader() {
        headers = new LinkedHashMap<>();
        Map<String, Object> transactionContext = new LinkedHashMap<>();
        transactionContext.put("organizationCode", "CLAROCHILE");
        transactionContext.put("configurationId", "configclaro");
        transactionContext.put("baselineId","initialbaseline");
        transactionContext.put(LatamConsumerApplicantDomain.ORCHESTRATION.getValue(), "HOGARDTH");

        headers.put("transactionContext", transactionContext);

    }

    @Test
    public void getMicroServicesMapTest() {
        assertNotNull(microServicesIdCollector.getMicroServicesMap());
    }



    @Test
    public void getServiceNameTest() {
        assertNotNull(microServicesIdCollector.getServiceName("11111-22222"));
    }
}