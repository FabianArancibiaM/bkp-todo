package com.equifax.ic.core.spring.integration.persistence.service.exception;

import com.equifax.ic.core.spring.integration.persistence.exception.InternalErrorException;
import org.junit.Test;

public class InternalErrorExceptionTest {
    @Test
    public void methodClass(){
        InternalErrorException ex = new InternalErrorException();
        InternalErrorException ex2 = new InternalErrorException(new Throwable());
        InternalErrorException ex3 = new InternalErrorException("",new Throwable());
        InternalErrorException ex4 = new InternalErrorException("",new Throwable(),true,true);
    }
}
