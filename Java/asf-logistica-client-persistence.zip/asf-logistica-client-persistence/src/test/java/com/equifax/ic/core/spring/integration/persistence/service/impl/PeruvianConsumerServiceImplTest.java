package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.PeruvianConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.PeruvianConsumer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class PeruvianConsumerServiceImplTest {
    PeruvianConsumerDao argentinianConsumerDao = Mockito.mock(PeruvianConsumerDao.class);
    PeruvianConsumerServiceImpl argentinianConsumerService = new PeruvianConsumerServiceImpl();
    @Before
    public void init(){
        ReflectionTestUtils.setField(argentinianConsumerService,"peruvianConsumerDao",argentinianConsumerDao);
    }
    @Test
    public void methodClass4() throws IOException {
        PeruvianConsumer b =new PeruvianConsumer();
        Mockito.when(argentinianConsumerDao.save(b)).thenReturn(null);
        argentinianConsumerService.insertPeruvianConsumer(b);
    }
}
