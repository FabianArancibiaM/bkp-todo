package com.equifax.ic.core.spring.integration.persistence.service.util;

import com.equifax.ic.core.spring.integration.persistence.util.CustomApplicantDomain;
import org.junit.Assert;
import org.junit.Test;

public class CustomApplicantDomainTest {

    @Test
    public void classTest(){
        Assert.assertNotNull(CustomApplicantDomain.CLIENTORCHESTRATIONUUID.getValue());
        Assert.assertNotNull(CustomApplicantDomain.CLIENTORCHESTRATIONDATECREATED.getValue());
        Assert.assertNotNull(CustomApplicantDomain.CLIENTORCHESTRATIONSTATUS.getValue());
        Assert.assertNotNull(CustomApplicantDomain.CLIENTORCHESTRATIONDATEMODIFIED.getValue());
    }
}
