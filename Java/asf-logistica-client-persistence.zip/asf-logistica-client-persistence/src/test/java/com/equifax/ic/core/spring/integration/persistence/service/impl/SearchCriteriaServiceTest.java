package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.SearchCriteriaDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.CriteriaBody;
import com.equifax.ic.core.spring.integration.persistence.pojo.SearchCriteria;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.hibernate.jpa.criteria.CriteriaBuilderImpl;
import org.hibernate.jpa.criteria.path.RootImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Root;
import java.io.IOException;
import java.util.Date;
import java.util.LinkedList;

public class SearchCriteriaServiceTest {
    SearchCriteriaDao service = Mockito.mock(SearchCriteriaDao.class);
    SearchCriteriaServiceImpl searchCriteriaService = new SearchCriteriaServiceImpl();
    String json = "{\"applicants\" : {\"primaryConsumer\" : {\n" +
            "\"personalInformation\" : {\"fromDate\":\"01-01-2020\",\n" +
            "\"untilDate\":\"20-01-2020\",\"chileanRut\" : \"174573824\",\n" +
            "\"decision\":\"Rechazar\",\"transactionId\": \"112680000000060055\"}}}}";

    @Before
    public void init(){
        ReflectionTestUtils.setField(searchCriteriaService, "criteriaDao", service);
    }

    @Test
    public void algoTest() throws IOException {
        Mockito.when(service.findAll()).thenReturn(new LinkedList<>());
        JsonNode jRequest = (new ObjectMapper()).readTree(json);
        searchCriteriaService.findByCriteria(jRequest);
    }

    @Test
    public void algosTest() throws IOException {
        Mockito.when(service.findAll()).thenReturn(new LinkedList<>());
        CriteriaBody criteriaBody= new CriteriaBody(new Date(),new Date(),"asdasd","Rechazo","1231234121");
        searchCriteriaService.getPredicate(criteriaBody,Mockito.mock(Root.class),Mockito.mock(CriteriaBuilder.class));
    }
    @Test
    public void algos2Test() throws IOException {
        Mockito.when(service.findAll()).thenReturn(new LinkedList<>());
        CriteriaBody criteriaBody= new CriteriaBody(null,new Date(),"asdasd","Rechazo","1231234121");
        searchCriteriaService.getPredicate(criteriaBody,Mockito.mock(Root.class),Mockito.mock(CriteriaBuilder.class));
    }
    @Test
    public void algos3Test() throws IOException {
        Mockito.when(service.findAll()).thenReturn(new LinkedList<>());
        CriteriaBody criteriaBody= new CriteriaBody(new Date(),null,"asdasd","Rechazo","1231234121");
        searchCriteriaService.getPredicate(criteriaBody,Mockito.mock(Root.class),Mockito.mock(CriteriaBuilder.class));
    }
}
