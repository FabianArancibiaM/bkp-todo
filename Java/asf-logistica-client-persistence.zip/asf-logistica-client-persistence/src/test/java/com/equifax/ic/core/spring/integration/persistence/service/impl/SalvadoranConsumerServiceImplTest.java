package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.SalvadoranConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.SalvadoranConsumer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class SalvadoranConsumerServiceImplTest {
    SalvadoranConsumerDao argentinianConsumerDao = Mockito.mock(SalvadoranConsumerDao.class);
    SalvadoranConsumerServiceImpl argentinianConsumerService = new SalvadoranConsumerServiceImpl();
    @Before
    public void init(){
        ReflectionTestUtils.setField(argentinianConsumerService,"salvadoranConsumerDao",argentinianConsumerDao);
    }
    @Test
    public void methodClass4() throws IOException {
        SalvadoranConsumer b =new SalvadoranConsumer();
        Mockito.when(argentinianConsumerDao.save(b)).thenReturn(null);
        argentinianConsumerService.insertSalvadoranConsumer(b);
    }
}
