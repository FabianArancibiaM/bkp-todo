package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.factory.impl.SmartsDecisioningFactory;
import com.equifax.ic.core.spring.integration.persistence.pojo.SmartsPojo;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class SmartsDecisioningFactoryTest {

    private SmartsDecisioningFactory smartsDecisioningFactory;
    private List<SmartsPojo> smartsPojoList;

    @Before
    public void setUp() throws Exception {
        smartsDecisioningFactory = new SmartsDecisioningFactory();
        smartsPojoList = new ArrayList<>();
    }

    @Test
    public void logSmartsDecisioning() {
        smartsDecisioningFactory.logSmartsDecisioning("", "", "", "", "", null, "", null);
    }

    @Test
    public void getList() {
        ReflectionTestUtils.setField(this.smartsDecisioningFactory, "smartsPojoList", this.smartsPojoList);
        smartsDecisioningFactory.getList();
    }

    @Test
    public void setSmartsPojoList() {
        ReflectionTestUtils.setField(this.smartsDecisioningFactory, "smartsPojoList", this.smartsPojoList);
        smartsDecisioningFactory.setSmartsPojoList(new LinkedList<>());
    }
}