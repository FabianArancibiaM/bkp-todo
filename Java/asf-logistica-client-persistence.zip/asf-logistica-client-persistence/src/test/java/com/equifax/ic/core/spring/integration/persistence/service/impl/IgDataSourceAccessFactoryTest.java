package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.factory.impl.IgDataSourceAccessFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class IgDataSourceAccessFactoryTest {

    private IgDataSourceAccessFactory igDataSourceAccessFactory;
    private List<IgDataSourceAccessFactory> igDataSourceAccessFactoryList;

    @Before
    public void setUp() throws Exception {
        igDataSourceAccessFactory = new IgDataSourceAccessFactory();
        igDataSourceAccessFactoryList = new ArrayList<>();
    }

    @Test
    public void logIgDataSource() {
        igDataSourceAccessFactory.logIgDataSource(null, null,
                null,null, new HashSet<>());
    }

    @Test
    public void getList() {
        ReflectionTestUtils.setField(this.igDataSourceAccessFactory, "igPojoList", this.igDataSourceAccessFactoryList);
        igDataSourceAccessFactory.getList();
    }

    @Test
    public void setSmartsDecisioningList() {
        ReflectionTestUtils.setField(this.igDataSourceAccessFactory, "igPojoList", this.igDataSourceAccessFactoryList);
        igDataSourceAccessFactory.setIgList(null);
    }
}