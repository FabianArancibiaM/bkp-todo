package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.ArgentinianConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.ArgentinianConsumer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class ChileanConsumerServiceImplTest {
    ArgentinianConsumerDao argentinianConsumerDao = Mockito.mock(ArgentinianConsumerDao.class);
    ArgentinianConsumerServiceImpl argentinianConsumerService = new ArgentinianConsumerServiceImpl();
    @Before
    public void init(){
        ReflectionTestUtils.setField(argentinianConsumerService,"argentinianConsumerDao",argentinianConsumerDao);
    }
    @Test
    public void methodClass4() throws IOException {
        ArgentinianConsumer b =new ArgentinianConsumer();
        Mockito.when(argentinianConsumerDao.save(b)).thenReturn(null);
        argentinianConsumerService.insertArgentinianConsumer(b);
    }
}
