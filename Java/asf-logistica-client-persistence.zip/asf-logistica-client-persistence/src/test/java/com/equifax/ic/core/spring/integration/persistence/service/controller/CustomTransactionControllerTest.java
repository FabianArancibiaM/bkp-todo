package com.equifax.ic.core.spring.integration.persistence.service.controller;

import com.equifax.ic.core.clientapi.service.OrchestrationExecutionService;
import com.equifax.ic.core.clientapi.service.SearchDeployService;
import com.equifax.ic.core.spring.integration.persistence.controller.CustomTransactionController;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CustomTransactionControllerTest {
    final CustomTransactionController customTransactionController = new CustomTransactionController();
    final Map header = new HashMap<>();
    String request = null;
    private final OrchestrationExecutionService orchestrationExecutionService = Mockito.mock(OrchestrationExecutionService.class);
    private final SearchDeployService searchDeployService = Mockito.mock(SearchDeployService.class);

    String json = "{\"applicants\" : {\"primaryConsumer\" : {\"personalInformation\" : {\"name\" : [{\"identifier\" : \"current\"}],\"chileanRut\" : \"189077505\",\n" +
            "\"chileanSerialNumber\" : \"A022912537\",\"addresses\" : [{\"identifier\" : \"current\"}],\"customerReferenceIdentifier\" : \"ASF-LOGISTICA\",\"additionalAttribute\" : {\"usu_digito_sol\" : \"4\",\"usu_serie_sol\" : \"17457382\",\n" +
            "\"usu_mto_linea_solicitada\" : \"1.000.000\",\"usu_canal\" : \"003\",\"usu_direccion\" : \"Balmaceda 456\",\"usu_region\" : \"011\",\"usu_comuna\" : \"135\",\n" +
            "\"usu_email\" : \"guille@gmail.com\",\"usu_fono\" : \"5622265898\",\"usu_refbco_cuenta\" : \"165426365455\",\"usu_refbco_banco\" : \"005\",\"usu_refbco_suc\" : \"004\"}}}}}";

    @Before
    public void setUp() throws IOException {
        request = json;
        header.put("authorization", "Basic bGF0YW1wbGF0Zm9ybXRyaWJlc3RzOmxhdGFtcGxhdGZvcm10cmliZXN0cy4yMDE5");
        customTransactionController.setGatewayPath("ASFLOGISTICA_Asflogistica_InitialBaseline_ASFLOGISTICA");
        ReflectionTestUtils.setField(customTransactionController, "orchestrationExecutionService", orchestrationExecutionService);
        ReflectionTestUtils.setField(customTransactionController, "searchDeployService", searchDeployService);
        String searchTransactionDeployEnabled = "false";
        ReflectionTestUtils.setField(customTransactionController, "searchTransactionDeployEnabled", searchTransactionDeployEnabled);
    }

    @Test(expected = NullPointerException.class)
    public void executeTransaction() throws IOException {
        customTransactionController.executeTransaction(request, header);
    }
    @Test
    public void allMethod() {
        customTransactionController.setGatewayPath("");
        customTransactionController.setOrchestrationExecutionService(Mockito.mock(OrchestrationExecutionService.class));
        customTransactionController.setSearchDeployService(Mockito.mock(SearchDeployService.class));
        customTransactionController.setSearchTransactionDeployEnabled("");
    }
}
