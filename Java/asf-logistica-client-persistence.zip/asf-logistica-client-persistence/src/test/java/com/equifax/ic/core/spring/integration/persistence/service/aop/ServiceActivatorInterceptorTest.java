package com.equifax.ic.core.spring.integration.persistence.service.aop;

import com.equifax.ic.core.spring.integration.persistence.aop.ServiceActivatorInterceptor;
import com.equifax.ic.core.spring.integration.persistence.component.MicroServicesIdCollector;
import com.equifax.ic.core.spring.integration.persistence.util.PersistenceDomain;
import org.junit.Before;
import org.junit.Test;
import org.springframework.integration.history.MessageHistory;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Constructor;
import java.util.*;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ServiceActivatorInterceptorTest {

    private ServiceActivatorInterceptor serviceActivatorInterceptor;
    private Map<String, Object> headers;
    private MicroServicesIdCollector microServicesIdCollector;
    private Map<String, Object> microServicesMap;
    private String serviceId = "8c185b2e-16a1-45ca-b9a0-97020c2a290f";

    private static final String HISTORY = "history";

    @Before
    public void setUp() throws Exception {
        serviceActivatorInterceptor = new ServiceActivatorInterceptor();
        headers = new LinkedHashMap<>();
        microServicesMap = new LinkedHashMap<>();
        microServicesIdCollector = mock(MicroServicesIdCollector.class);

        ReflectionTestUtils.setField(serviceActivatorInterceptor, "microServicesIdCollector", microServicesIdCollector);

        HashSet<String> mitList = new HashSet<>();
        mitList.add(serviceId);
        microServicesMap.put("mitList", mitList);

        List<Properties> propertiesList = new ArrayList<>();
        Properties property = new Properties();
        property.setProperty("name", serviceId);
        propertiesList.add(property);

        Constructor[] constructor = MessageHistory.class.getDeclaredConstructors();
        constructor[0].setAccessible(true);
        MessageHistory messageHistory = (MessageHistory) constructor[0].newInstance(propertiesList);

        headers.put(HISTORY, messageHistory);
    }

    @Test
    public void parametersBuilderTest() throws Exception {

        when(microServicesIdCollector.getMicroServicesMap()).thenReturn(microServicesMap);
        when(microServicesIdCollector.getServiceName(anyString())).thenReturn(serviceId);

        String executionTime = PersistenceDomain.BEFORE.toString();
        ReflectionTestUtils.invokeMethod(serviceActivatorInterceptor, "parametersBuilder", headers, executionTime);
    }
}