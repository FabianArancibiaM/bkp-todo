package com.equifax.ic.core.spring.integration.persistence.service.pojo;

import com.equifax.ic.core.spring.integration.persistence.pojo.*;
import org.junit.Test;

import java.util.Date;

public class ClassPojoTest {

    @Test
    public void classTest(){
        ArgentinianConsumer argentinianConsumer = new ArgentinianConsumer();
        argentinianConsumer.setGender("");
        argentinianConsumer.getGender();
        argentinianConsumer.setDni("");
        argentinianConsumer.getDni();
        argentinianConsumer.setConsumer(new Consumer());
        argentinianConsumer.getConsumer();
        argentinianConsumer.setId(1L);
        argentinianConsumer.getId();
        argentinianConsumer.setName("");
        argentinianConsumer.getName();
        argentinianConsumer.setReference("");
        argentinianConsumer.getReference();

        ChileanConsumer chileanConsumer = new ChileanConsumer();
        chileanConsumer.setChileanRut("");
        chileanConsumer.getChileanRut();
        chileanConsumer.setChileanSerialNumber("");
        chileanConsumer.getChileanSerialNumber();
        chileanConsumer.setConsumer(new Consumer());
        chileanConsumer.getConsumer();
        chileanConsumer.setId(1L);
        chileanConsumer.getId();

        Consumer consumer = new Consumer();
        consumer.setAge(2);
        consumer.getAge();
        consumer.setApplicationIdentifier("");
        consumer.getApplicationIdentifier();
        consumer.setArgentinianConsumer(new ArgentinianConsumer());
        consumer.getArgentinianConsumer();
        consumer.setChileanConsumer(chileanConsumer);
        consumer.getChileanConsumer();
        consumer.setCountry("");
        consumer.getCountry();
        consumer.setFirstName("");
        consumer.getFirstName();
        consumer.setId(1L);
        consumer.getId();
        consumer.setLastName("");
        consumer.getLastName();
        consumer.setPeruvianConsumer(new PeruvianConsumer());
        consumer.getPeruvianConsumer();
        consumer.setUruguayanConsumer(new UruguayanConsumer());
        consumer.getUruguayanConsumer();
        consumer.setUuid("");
        consumer.getUuid();

        CostaRicanConsumer costaRicanConsumer = new CostaRicanConsumer();
        costaRicanConsumer.setConsumer(new Consumer());
        costaRicanConsumer.getConsumer();
        costaRicanConsumer.setId(1L);
        costaRicanConsumer.getId();
        costaRicanConsumer.setIdentificationNumber("");
        costaRicanConsumer.getIdentificationNumber();

        EcuadorianConsumer ecuadorianConsumer = new EcuadorianConsumer();
        ecuadorianConsumer.setConsumer(new Consumer());
        ecuadorianConsumer.getConsumer();
        ecuadorianConsumer.setId(1L);
        ecuadorianConsumer.getId();
        ecuadorianConsumer.setNumeroDocumento("");
        ecuadorianConsumer.getNumeroDocumento();
        ecuadorianConsumer.setTipoDocumento("");
        ecuadorianConsumer.getTipoDocumento();

        HonduranConsumer honduranConsumer = new HonduranConsumer();
        honduranConsumer.setConsumer(new Consumer());
        honduranConsumer.getConsumer();
        honduranConsumer.setId(2L);
        honduranConsumer.getId();
        honduranConsumer.setIdentificationNumber("");
        honduranConsumer.getIdentificationNumber();

        PeruvianConsumer peruvianConsumer = new PeruvianConsumer();
        peruvianConsumer.setConsumer(new Consumer());
        peruvianConsumer.getConsumer();
        peruvianConsumer.setId(2L);
        peruvianConsumer.getId();
        peruvianConsumer.setPeruIdNumber("");
        peruvianConsumer.getPeruIdNumber();
        peruvianConsumer.setPeruIdType("");
        peruvianConsumer.getPeruIdType();

        SalvadoranConsumer salvadoranConsumer = new SalvadoranConsumer();
        salvadoranConsumer.setConsumer(new Consumer());
        salvadoranConsumer.getConsumer();
        salvadoranConsumer.setId(2L);
        salvadoranConsumer.getId();
        salvadoranConsumer.setIdentificationNumber("");
        salvadoranConsumer.getIdentificationNumber();

        UruguayanConsumer uruguayanConsumer = new UruguayanConsumer();
        uruguayanConsumer.setConsumer(new Consumer());
        uruguayanConsumer.getConsumer();
        uruguayanConsumer.setDocumento("");
        uruguayanConsumer.getDocumento();
        uruguayanConsumer.setFicha("");
        uruguayanConsumer.getFicha();
        uruguayanConsumer.setId(2L);
        uruguayanConsumer.getId();
        uruguayanConsumer.setName("");
        uruguayanConsumer.getName();

        DataSourceBlob dataSourceBlob = new DataSourceBlob();
        dataSourceBlob.setDataSourceName("");
        dataSourceBlob.getDataSourceName();
        dataSourceBlob.setDataSourceUuid("");
        dataSourceBlob.getDataSourceUuid();
        dataSourceBlob.setId(1L);
        dataSourceBlob.getId();
        dataSourceBlob.setIdIgDataSourceAccess(new IgPojo());
        dataSourceBlob.getIdIgDataSourceAccess();
        dataSourceBlob.setResponseBlob(new byte[6]);
        dataSourceBlob.getResponseBlob();

        AnavPojo anavPojo = new AnavPojo();
        anavPojo.setApplicantIdentifier("");
        anavPojo.getApplicantIdentifier();
        anavPojo.setBaseline("");
        anavPojo.getBaseline();
        anavPojo.setId(2L);
        anavPojo.getId();
        anavPojo.setProjectName("");
        anavPojo.getProjectName();
        anavPojo.setUuid("");
        anavPojo.getUuid();

        MitPojo mitPojo = new MitPojo();
        mitPojo.setApplicantIdentifier("");
        mitPojo.getApplicantIdentifier();
        mitPojo.setFinalscore(new Integer(2));
        mitPojo.getFinalscore();
        mitPojo.setId(2L);
        mitPojo.getId();
        mitPojo.setModelId("");
        mitPojo.getModelId();
        mitPojo.setUuid("");
        mitPojo.getUuid();

        SmartsPojo smartsPojo = new SmartsPojo();
        smartsPojo.setId(1L);
        smartsPojo.getId();
        smartsPojo.getUuid();
        smartsPojo.setType("");
        smartsPojo.getType();
        smartsPojo.setReasons("");
        smartsPojo.getReasons();
        smartsPojo.setUuid("");
        smartsPojo.setOverride(1);
        smartsPojo.getOverride();
        smartsPojo.setDateCreated(new Date());
        smartsPojo.getDateCreated();
        smartsPojo.setDecision("");
        smartsPojo.getDecision();
        smartsPojo.setDescription("");
        smartsPojo.getDescription();

        Messages messages= new Messages();
        messages.setEventType("");
        messages.getEventType();
        messages.setId(1L);
        messages.getId();
        messages.setIdSystemEvent(1L);
        messages.getIdSystemEvent();
        messages.setMessageBlob(new byte[6]);
        messages.getMessageBlob();
        messages.setSystemEvent(null);
        messages.getSystemEvent();

        SystemEvent systemEvent = new SystemEvent();
        systemEvent.setApplicantIdentifier("");
        systemEvent.getApplicantIdentifier();
        systemEvent.setClassProducer("");
        systemEvent.setDateCreated(new Date());
        systemEvent.getDateCreated();
        systemEvent.setDescription("");
        systemEvent.getDescription();
        systemEvent.setDuration(1L);
        systemEvent.getDuration();
        systemEvent.setId(1L);
        systemEvent.getId();
        systemEvent.setUuid("");
        systemEvent.getUuid();

        IgPojo ig = new IgPojo();
        ig.setApplicantIdentifier("");
        ig.getApplicantIdentifier();
        ig.setDataSourceBlob(null);
        ig.getDataSourceBlob();
        ig.setId(1L);
        ig.getId();
        ig.setOrchestration("");
        ig.getOrchestration();
        ig.setTransactionId("");
        ig.getTransactionId();
        ig.setUuid("");
        ig.getUuid();

        CriteriaBody criteriaBody = new CriteriaBody(new Date(),new Date(),"","","");
        criteriaBody.getHasta();
        criteriaBody.getDesde();
        criteriaBody.getDecision();
        criteriaBody.getTransactionId();
        criteriaBody.getRut();

        CriteriaBody.CriteriaBodyBuilder builder = new CriteriaBody.CriteriaBodyBuilder();
        builder.decision("");
        builder.desde(new Date());
        builder.hasta(new Date());
        builder.rut("");
        builder.createCriteriaBody();
    }
}
