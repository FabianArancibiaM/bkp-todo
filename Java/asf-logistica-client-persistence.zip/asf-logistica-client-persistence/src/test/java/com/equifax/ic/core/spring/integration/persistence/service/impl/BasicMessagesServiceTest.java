package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.MessagesDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BasicMessagesServiceTest {

    private BasicMessagesService basicMessagesService;
    private MessagesDao messagesDao;

    @Before
    public void setUp() {
        basicMessagesService = new BasicMessagesService();
        messagesDao = mock(MessagesDao.class);
    }

    @Test
    public void getAllMessages() {
        ReflectionTestUtils.setField(this.basicMessagesService,"messagesDao", this.messagesDao);
        when(messagesDao.findAll()).thenReturn(new LinkedList<>());
        basicMessagesService.getAllMessages();
    }

    @Test
    public void getMessageById() {
        ReflectionTestUtils.setField(this.basicMessagesService,"messagesDao", this.messagesDao);
        when(messagesDao.findOne(Mockito.anyLong())).thenReturn(new Messages());
        basicMessagesService.getMessageById((Mockito.anyLong()));
    }

    @Test
    public void saveNewMessage() {
        ReflectionTestUtils.setField(this.basicMessagesService,"messagesDao", this.messagesDao);
        when(messagesDao.save(Mockito.any(Messages.class))).thenReturn(new Messages());
        basicMessagesService.saveNewMessage(new Messages());
    }

    @Test
    public void updateMessage() {
        ReflectionTestUtils.setField(this.basicMessagesService,"messagesDao", this.messagesDao);
        when(messagesDao.save(Mockito.any(Messages.class))).thenReturn(new Messages());
        when(basicMessagesService.getMessageById(Mockito.anyLong())).thenReturn(new Messages());
            try {
                basicMessagesService.updateMessage((new Messages()));
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

    @Test
    public void insertList() {
        List<Messages> messagesDecisioningList= new ArrayList();
        messagesDecisioningList.add(new Messages());

        ReflectionTestUtils.setField(this.basicMessagesService,"messagesDao", this.messagesDao);
        when(messagesDao.save(Mockito.any(Messages.class))).thenReturn(new Messages());
        basicMessagesService.insertList(messagesDecisioningList);
    }
}