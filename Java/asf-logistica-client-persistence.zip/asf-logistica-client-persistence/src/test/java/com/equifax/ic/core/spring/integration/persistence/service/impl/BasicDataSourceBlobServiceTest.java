package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.DataSourceBlobDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.DataSourceBlob;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class BasicDataSourceBlobServiceTest {

    DataSourceBlobDao dataSourceBlobDao = Mockito.mock(DataSourceBlobDao.class);
    BasicDataSourceBlobService basicDataSourceBlobService = new BasicDataSourceBlobService();
    @Before
    public void init(){
        ReflectionTestUtils.setField(basicDataSourceBlobService,"dataSourceBlobDao",dataSourceBlobDao);
    }

    @Test
    public void methodClass(){
        Mockito.when(dataSourceBlobDao.findAll()).thenReturn(null);
        basicDataSourceBlobService.getAllDataSourceBlob();
    }
    @Test
    public void methodClass2(){
        Mockito.when(dataSourceBlobDao.save(new DataSourceBlob())).thenReturn(null);
        basicDataSourceBlobService.insertDataSourceBlob(new DataSourceBlob());
    }
    @Test
    public void methodClass3(){
        Mockito.when(dataSourceBlobDao.findOne(1L)).thenReturn(null);
        basicDataSourceBlobService.getDataSourceBlobById(1L);
    }
    @Test
    public void methodClass4() throws IOException {
        DataSourceBlob b =new DataSourceBlob();
        b.setId(1L);
        Mockito.when(dataSourceBlobDao.save(b)).thenReturn(null);
        Mockito.when(basicDataSourceBlobService.getDataSourceBlobById(b.getId())).thenReturn(new DataSourceBlob());
        basicDataSourceBlobService.updateDataSourceBlob(b);
    }
}
