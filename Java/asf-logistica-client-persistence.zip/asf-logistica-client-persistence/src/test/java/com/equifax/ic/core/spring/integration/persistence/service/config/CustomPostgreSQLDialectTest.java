package com.equifax.ic.core.spring.integration.persistence.service.config;

import com.equifax.ic.core.spring.integration.persistence.config.CustomPostgreSQLDialect;
import org.hibernate.type.descriptor.sql.SqlTypeDescriptor;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertNotNull;

public class CustomPostgreSQLDialectTest {

    @Test
    public void sqlTest(){
        CustomPostgreSQLDialect dialect = new CustomPostgreSQLDialect();
        SqlTypeDescriptor sql2 = dialect.remapSqlTypeDescriptor(Mockito.mock(SqlTypeDescriptor.class));
        assertNotNull(sql2);
    }
}
