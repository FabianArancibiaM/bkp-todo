package com.equifax.ic.core.spring.integration.persistence.service.handler;

import com.equifax.ic.core.spring.integration.persistence.handler.CustomExceptionHandler;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.web.context.request.WebRequest;

public class CustomExceptionHandlerTest {
    final CustomExceptionHandler customExceptionHandler = new CustomExceptionHandler();
    final Exception exception = Mockito.mock(Exception.class);
    final WebRequest request = Mockito.mock(WebRequest.class);

    @Test
    public void handleUnauthorizedExceptionHandler() {
        customExceptionHandler.handleUnauthorizedExceptionHandler(exception, request);
    }

    @Test
    public void handleInternalErrorExceptionHandler() {
        customExceptionHandler.handleUnauthorizedExceptionHandler(exception, request);
    }
}
