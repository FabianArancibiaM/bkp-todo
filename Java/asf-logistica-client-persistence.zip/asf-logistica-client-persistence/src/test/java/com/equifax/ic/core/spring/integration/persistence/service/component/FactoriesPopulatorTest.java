package com.equifax.ic.core.spring.integration.persistence.service.component;

import com.equifax.ic.core.spring.integration.persistence.component.FactoriesPopulator;
import com.equifax.ic.core.spring.integration.persistence.component.OrchestrationProperties;
import com.equifax.ic.core.spring.integration.persistence.config.SystemEventFactory;
import com.equifax.ic.core.spring.integration.persistence.factory.PersistenceFactories;
import com.equifax.ic.core.spring.integration.persistence.factory.impl.*;
import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;
import com.equifax.ic.core.spring.integration.persistence.util.LatamConsumerApplicantDomain;
import com.equifax.ic.core.spring.integration.persistence.util.PersistenceDomain;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * 
 * @author Alan Sandoval axs831
 * @since 19-08-2018 1.0
 */
public class FactoriesPopulatorTest {

	private FactoriesPopulator factoriesPopulator;
	
	private Map<String, Object> payload;
	private Map<String, Object> headers;
	private String initialRequest = "{\"applicants\":{\"primaryConsumer\":{\"personalInformation\":{\"chileanRut\":\"184566362\",\"chileanSerialNumber\":\"A000000002\"}}}}";
	private String smartsResponse = "[{\"Variables_Scores\":{\"SCORE\":\"475\"},\"Variables_Scores_NPN\":{\"SCORE_NPN\":714,\"SCORE_CLARO_NPN\":\"NO\"},\"Segmentacion\":{\"NODO_REAL\":11,\"NODO_TERMINAL\":56},\"Segmentacion_NPN\":{\"RIESGO_CLARO\":5},\"Description\":\"test\",\"Reasons\":\"test\"}]";
	private String igResponse = "{\"transactionId\":\"111341000000010636\",\"status\":\"completed\",\"applicants\":{\"primaryConsumer\":{\"personalInformation\":{\"chileanRut\":\"184566362\",\"chileanSerialNumber\":\"A000000002\"},\"ccb\":{\"ccb\":{\"uuid\":\"e94ff29f-ddc9-4de5-b7e1-a8e24dc590bd\",\"transactionInfo\":{\"documentNumber\":\"184566362\",\"serialNumber\":\"A000000002\",\"fatherSurname\":\"ROJAS\",\"motherSurname\":\"REYES\",\"name\":\"FELIPE ALBERTO  \",\"uuidTransaction\":\"\",\"username\":\"IGCLARO\",\"date\":\"none\",\"hour\":\"none\"},\"expg04Section\":{\"attributes\":[{\"variableName\":\"DIC_MONTOTOTALUF_02\",\"variableType\":\"N\",\"correlative\":\"006\",\"value\":\"0.00\",\"decimalNumber\":\"02\"}]}},\"exclusionaryConditions\":{\"ErrorsPresent\":false,\"NoHit\":false,\"NotAvailable\":false},\"nativeText\":{\"raw\":\"\",\"type\":\"reponse\"},\"returnedProducts\":[\"ccb\"]},\"equifax-chi-kpidummy\":{\"KPI\":{\"uuid\":\"90b6216e-ee30-431c-bb50-a54bcac0f532\",\"transactionInfo\":{\"documentNumber\":\"184566362K\",\"date\":\"none\",\"hour\":\"none\"},\"kpiSection\":{\"attributes\":[{\"variableName\":\"KPI_ISE_01\",\"value\":\"C3\",\"variableType\":\"T\"}]}},\"exclusionaryConditions\":{\"ErrorsPresent\":false,\"NoHit\":false,\"NotAvailable\":false},\"nativeText\":{\"raw\":\"\",\"type\":\"reponse\"},\"returnedProducts\":[\"KPI\"]},\"equifax-cl-household\":{\"household\":{\"Fault\":{\"faultcode\":\"soapenv:Server\",\"faultstring\":\"test\",\"detail\":{\"fault\":{\"reason\":\"test\",\"errorCode\":\"BEA-380000\",\"location\":{\"pipeline\":\"GetHouseHoldByIdPipeline_request\",\"node\":\"GetHouseHoldByIdPipeline\",\"path\":\"request-pipeline\",\"stage\":\"RequestGetHouseHoldById\"}}}}},\"exclusionaryConditions\":{\"NotAvailable\":true,\"ErrorsPresent\":false},\"returnedProducts\":[\"household\"]}}}}";
	private String mitResponse = "{\"organization\":\"CLAROCHILE\",\"modelId\":\"SCA01\",\"outputs\":[{\"name\":\"CLAROCHILE.CLA02.modelScore\"},{\"name\":\"Reject Code\",\"value\":\"\"},{\"name\":\"INPUT2_uncapped final score\",\"value\":\"773.0\"},{\"name\":\"pointDiffPercentage\",\"value\":\"0.5\"},{\"name\":\"Reason Code 1\",\"value\":\"\"},{\"name\":\"Reason Code 2\",\"value\":\"\"},{\"name\":\"Reason Code 3\",\"value\":\"\"},{\"name\":\"INPUT2_WinningSegmentId\"},{\"name\":\"Reason Code 4\",\"value\":\"\"},{\"name\":\"INPUT1_WinningSegmentId\"},{\"name\":\"CLAROCHILE.CLA01.finalScore\",\"value\":\"773\"},{\"name\":\"INPUT1_Reason Code 5\"},{\"name\":\"INPUT1_Reason Code 4\"},{\"name\":\"adjustedReasonCodes\",\"value\":\";;;;\"},{\"name\":\"INPUT1_Reason Code 3\"},{\"name\":\"INPUT1_Reason Code 2\"},{\"name\":\"INPUT1_Reason Code 1\"},{\"name\":\"final score\",\"value\":\"773\"},{\"name\":\"INPUT1_uncapped final score\"},{\"name\":\"CLAROCHILE.CLA01.reasonCode4\"},{\"name\":\"CLAROCHILE.CLA01.reasonCode2\"},{\"name\":\"CLAROCHILE.CLA01.reasonCode3\"},{\"name\":\"INPUT1_predicted score\"},{\"name\":\"CLAROCHILE.CLA01.reasonCode1\"},{\"name\":\"INPUT2_predicted score\"},{\"name\":\"uncappedScore\",\"value\":\"773\"},{\"name\":\"CLAROCHILE.CLA02.reasonCode2\"},{\"name\":\"CLAROCHILE.CLA02.finalScore\"},{\"name\":\"CLAROCHILE.CLA02.reasonCode1\"},{\"name\":\"INPUT1_model score\"},{\"name\":\"CLAROCHILE.CLA02.reasonCode4\"},{\"name\":\"INPUT2_Reason Code 1\"},{\"name\":\"INPUT1_final score\"},{\"name\":\"CLAROCHILE.CLA02.reasonCode3\"},{\"name\":\"CLAROCHILE.CLA01.predictedScore\"},{\"name\":\"INPUT2_model score\",\"value\":\"773.0\"},{\"name\":\"INPUT2_Reason Code 5\",\"value\":\"\"},{\"name\":\"INPUT2_Reason Code 4\"},{\"name\":\"INPUT2_final score\",\"value\":\"773\"},{\"name\":\"INPUT2_Reason Code 3\"},{\"name\":\"INPUT2_Reason Code 2\"}]}";
	private PersistenceFactories persistenceFactories;
	private String uuid = "11111-22222-33333-44444";
	private Map<String, Object> parametersMap;
	
	@InjectMocks
    FactoriesPopulator test;
	
	@Mock
	private OrchestrationProperties orchestrationProperties;
	

	
	
	
	private static final String EXECUTION_TIME = "executionTime";
	private static final String MICROSERVICE_NAME = "microServiceName";
	private static final String SERVICE_ACTIVATOR_ID = "serviceActivatorId";
	private static final String UUID = "uuid";
	

	
	@Before
	public void setUpBefore() throws Exception {
		payload = new LinkedHashMap<>();
		headers = new LinkedHashMap<>();
		factoriesPopulator = new FactoriesPopulator();
		parametersMap = new LinkedHashMap<>();
		orchestrationProperties = new OrchestrationProperties();

		ObjectNode initialRequestJson = new ObjectMapper().readValue(initialRequest, ObjectNode.class);
		ObjectNode igResponseJson = new ObjectMapper().readValue(igResponse, ObjectNode.class);
		ArrayNode smartsResponseJson = new ObjectMapper().readValue(smartsResponse, ArrayNode.class);
		ObjectNode mitResponseJson = new ObjectMapper().readValue(mitResponse, ObjectNode.class);

		payload.put("INITIAL_REQUEST", initialRequestJson);
		payload.put("8c185b2e-16a1-45ca-b9a0-97020c2a290f_RESPONSE", igResponseJson);
		payload.put("53d362ac-b5d8-4a5a-a499-d304be1ef18d_RESPONSE", smartsResponseJson);
		payload.put("dd6686f4-67d1-40f2-9809-57f7096fd10b_RESPONSE", mitResponseJson);
		payload.put("dd6686f4-67d1-40f2-9809-57f7096fd10b_REQUEST", mitResponseJson);

		Map<String, Object> criMap = new LinkedHashMap<>();
		criMap.put(LatamConsumerApplicantDomain.ORCHESTRATION.getValue(), "CLIENTIMPLEMENTATION-IG");
		headers.put(LatamConsumerApplicantDomain.TRANSACTION_CONTEXT.getValue(), criMap);

		persistenceFactories = mock(PersistenceFactories.class);
		headers.put("persistenceFactories", persistenceFactories);
		parametersMap.put("persistenceFactories", persistenceFactories);

		Map<String, String> orchestrationParameters = new LinkedHashMap<>();
		orchestrationParameters.put("service.smarts.decision", "");
		orchestrationParameters.put("service.smarts.description", "");
		orchestrationParameters.put("service.smarts.reasons", "");
		orchestrationParameters.put("service.ig.dataSourceList", "");

		Map<String, Map<String, String>> orchestrations = new LinkedHashMap<>();
		orchestrations.put("CLIENTIMPLEMENTATION-IG", orchestrationParameters);
		orchestrationProperties.setClient(new LinkedHashMap<>());
		orchestrationProperties.setOrchestration(orchestrations);

		ReflectionTestUtils.setField(factoriesPopulator, "objectMapper", new ObjectMapper());
		ReflectionTestUtils.setField(factoriesPopulator, "orchestrationProperties", orchestrationProperties);
	
		MockitoAnnotations.initMocks(this);

		
	}
	
	@Test
	public void systemEventsBuilderTest() {
		parametersMap.put(EXECUTION_TIME, PersistenceDomain.BEFORE.toString());
		parametersMap.put(MICROSERVICE_NAME, PersistenceDomain.IG.toString());

		String mapId = "dd6686f4-67d1-40f2-9809-57f7096fd10b";
		parametersMap.put(SERVICE_ACTIVATOR_ID, mapId);
		
		when(persistenceFactories.getFactory(SystemEventFactory.class)).thenReturn(new SystemEventFactory());
		when(persistenceFactories.getFactory(MessagesFactory.class)).thenReturn(new MessagesFactory());
		
		factoriesPopulator.systemEventsBuilder(payload, headers, parametersMap);
	}

	@Test
	public void mitScoringBuilderTest() {
		String mapId = "dd6686f4-67d1-40f2-9809-57f7096fd10b_RESPONSE";
		String uuid = "123456";
		parametersMap.put(SERVICE_ACTIVATOR_ID, mapId);
		parametersMap.put(UUID, uuid);
		
		when(persistenceFactories.getFactory(any())).thenReturn(new MitScoringFactory());
		
		ReflectionTestUtils.invokeMethod(factoriesPopulator, "mitScoringBuilder", payload, parametersMap);
	}

	@Test
	public void smartsDecisioningBuilderTest() {
		String mapId = "53d362ac-b5d8-4a5a-a499-d304be1ef18d_RESPONSE";
		String uuid = "123456";
		parametersMap.put(SERVICE_ACTIVATOR_ID, mapId);
		parametersMap.put(UUID, uuid);

		ReflectionTestUtils.setField(factoriesPopulator, "decisionDecisioningParameter", "Variables_Scores.SCORE");
		ReflectionTestUtils.setField(factoriesPopulator, "reasonsDecisioningParameter", "Reasons");
		ReflectionTestUtils.setField(factoriesPopulator, "descriptionDecisioningParameter", "Description");
		
		when(persistenceFactories.getFactory(any())).thenReturn(new SmartsDecisioningFactory());
		
		ReflectionTestUtils.invokeMethod(factoriesPopulator, "smartsDecisioningBuilder", payload, parametersMap);
	}
	
	@Test
	public void igDataSourceBuilderTest() {
		String mapId = "8c185b2e-16a1-45ca-b9a0-97020c2a290f_RESPONSE";
		String uuid = "123456";
		String customerReferenceIdentifier = "TEST";
		parametersMap.put(SERVICE_ACTIVATOR_ID, mapId);
		parametersMap.put(UUID, uuid);
		parametersMap.put("customerReferenceIdentifier", customerReferenceIdentifier);

		ReflectionTestUtils.setField(factoriesPopulator, "dataSourceListIgParameter", "ccb, equifax-chi-kpidummy, equifax-cl-household");
		
		when(persistenceFactories.getFactory(any())).thenReturn(new IgDataSourceAccessFactory());
		
		ReflectionTestUtils.invokeMethod(factoriesPopulator, "igDataSourceBuilder", payload, parametersMap);
	}

	@Test
	public void eventTypeEvaluatorTest() {
		String microServiceName = PersistenceDomain.ANAV.toString();
		ReflectionTestUtils.invokeMethod(factoriesPopulator, "eventTypeEvaluator", microServiceName, true);
		ReflectionTestUtils.invokeMethod(factoriesPopulator, "eventTypeEvaluator", microServiceName, false);

		microServiceName = PersistenceDomain.SMARTS.toString();
		ReflectionTestUtils.invokeMethod(factoriesPopulator, "eventTypeEvaluator", microServiceName, true);
		ReflectionTestUtils.invokeMethod(factoriesPopulator, "eventTypeEvaluator", microServiceName, false);

		microServiceName = PersistenceDomain.MIT.toString();
		ReflectionTestUtils.invokeMethod(factoriesPopulator, "eventTypeEvaluator", microServiceName, true);
		ReflectionTestUtils.invokeMethod(factoriesPopulator, "eventTypeEvaluator", microServiceName, false);
	}

	@Test
	public void messageBuilderTest() {
		parametersMap.put(EXECUTION_TIME, PersistenceDomain.BEFORE.toString());
		parametersMap.put(MICROSERVICE_NAME, PersistenceDomain.MIT.toString());
		parametersMap.put("serviceActivatorId", "dd6686f4-67d1-40f2-9809-57f7096fd10b");

		when(persistenceFactories.getFactory(any())).thenReturn(new MessagesFactory());

		ReflectionTestUtils.invokeMethod(factoriesPopulator, "messageBuilder", payload, new SystemEvent(), parametersMap,true,true,"IG");
	}

	@Test
	public void parametersLoaderTest() {
		//ReflectionTestUtils.setField(factoriesPopulator, "orchestrationProperties", orchestrationProperties);
		when(orchestrationProperties.getIg()).thenReturn(true);	
		
		String json= "{\r\n" +
				"	\"CLIENTIMPLEMENTATION-IG\": {\r\n" + 
				"		\"country\": \"cl\",\r\n" + 
				"		\"service.ig.dataSourceList\": \"ccb\",\r\n" + 
				"		\"service.smarts.decision\": \"\",\r\n" + 
				"		\"service.smarts.description\": \"\",\r\n" + 
				"		\"service.smarts.reasons\": \"\"\r\n" + 
				"	}\r\n" + 
				"}";
		Map request = null;
		try {
			request = new ObjectMapper().readValue(json, Map.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		when(orchestrationProperties.getOrchestration()).thenReturn(request);
		
		test.parametersLoader(headers);
		
	}
	
	
	
	

}
