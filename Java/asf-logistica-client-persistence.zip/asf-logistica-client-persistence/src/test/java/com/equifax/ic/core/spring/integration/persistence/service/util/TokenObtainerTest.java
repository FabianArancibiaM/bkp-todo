package com.equifax.ic.core.spring.integration.persistence.service.util;

import com.equifax.ic.core.spring.integration.persistence.exception.UnauthorizedException;
import com.equifax.ic.core.spring.integration.persistence.util.TokenObtained;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
public class TokenObtainerTest {
    TokenObtained tokenObtainer;
    RestTemplate restTemplateMock;
    Map header;
    Map response;
    ResponseEntity<Map> responseEntity;

    @Before
    public void setup() throws IOException {
        tokenObtainer = new TokenObtained();
        restTemplateMock = Mockito.mock(RestTemplate.class);
        header = new HashMap();
        response = new HashMap();

        header.put("authorization", "Basic dGVzdDp0ZXN0");
        response.put("access_token", "mockValue");

        responseEntity = new ResponseEntity(response, HttpStatus.OK);

        ReflectionTestUtils.setField(tokenObtainer, "oauthUrl", "http://mockUrl/mockPath");
        ReflectionTestUtils.setField(tokenObtainer, "oauthClientId2", "clientIdMock");
        ReflectionTestUtils.setField(tokenObtainer, "oauthClientSecret", "secretMock");
        ReflectionTestUtils.setField(tokenObtainer, "oauthGrantType", "password");
        ReflectionTestUtils.setField(tokenObtainer, "oauthReadProfile", "sa.readprofile");
        ReflectionTestUtils.setField(tokenObtainer, "oauthEditProfile", "sa.editprofile");
        ReflectionTestUtils.setField(tokenObtainer, "restTemplateCustom", restTemplateMock);
    }

    @Test
    public void getToken() {
        Mockito.when(restTemplateMock.exchange(Mockito.eq("http://mockUrl/mockPath"), Mockito.eq(HttpMethod.POST),
                Mockito.any(HttpEntity.class), Matchers.<Class<Map>>any())).thenReturn(responseEntity);
        tokenObtainer.getToken(header);
    }

    @Test(expected = UnauthorizedException.class)
    public void getTokenWithoutAuthorization() {
        tokenObtainer.getToken(new HashMap<>());
    }
}
