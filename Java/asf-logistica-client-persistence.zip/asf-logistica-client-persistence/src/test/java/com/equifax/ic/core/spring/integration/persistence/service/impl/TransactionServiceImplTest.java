package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.TransactionDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.Transaction;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class TransactionServiceImplTest {
    TransactionDao dataSourceBlobDao = Mockito.mock(TransactionDao.class);
    TransactionServiceImpl basicDataSourceBlobService = new TransactionServiceImpl();
    @Before
    public void init(){
        ReflectionTestUtils.setField(basicDataSourceBlobService,"transactionDao",dataSourceBlobDao);
    }

    @Test
    public void methodClass2(){
        Mockito.when(dataSourceBlobDao.save(new Transaction())).thenReturn(null);
        basicDataSourceBlobService.insertTransaction(new Transaction());
    }
    @Test
    public void methodClass3(){
        Mockito.when(dataSourceBlobDao.findOne(1L)).thenReturn(null);
        basicDataSourceBlobService.getTransactionById(1L);
    }
    @Test
    public void methodClass4() throws IOException {
        Transaction b =new Transaction();
        b.setId(1L);
        Mockito.when(dataSourceBlobDao.save(b)).thenReturn(null);
        Mockito.when(basicDataSourceBlobService.getTransactionById(b.getId())).thenReturn(new Transaction());
        basicDataSourceBlobService.updateTransaction(b);
    }
    @Test
    public void methodClass5(){
        Mockito.when(dataSourceBlobDao.findByUUID("")).thenReturn(null);
        basicDataSourceBlobService.findTransactionById("");
    }
}
