package com.equifax.ic.core.spring.integration.persistence.service.aop;

import com.equifax.ic.core.spring.integration.persistence.aop.TokenObtainedExecutor;
import com.equifax.ic.core.spring.integration.persistence.util.TokenObtained;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.aop.ProxyMethodInvocation;
import org.springframework.aop.aspectj.MethodInvocationProceedingJoinPoint;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.Map;

public class TokenObtainedExecutorTest {
    TokenObtained tokenObtained = Mockito.mock(TokenObtained.class);
    @Test(expected = NullPointerException.class)
    public void aroundExecuteOrchestrationExecutionTest() throws Throwable {
        TokenObtainedExecutor token = new TokenObtainedExecutor();
        ProceedingJoinPoint proceedingJoinPoint = new MethodInvocationProceedingJoinPoint(Mockito.mock(ProxyMethodInvocation.class));
        ReflectionTestUtils.setField(token,"tokenObtained",tokenObtained);
        Map<String, Object> headers = new HashMap<>();
        token.aroundExecuteOrchestrationExecution(proceedingJoinPoint,"",headers);
    }
}
