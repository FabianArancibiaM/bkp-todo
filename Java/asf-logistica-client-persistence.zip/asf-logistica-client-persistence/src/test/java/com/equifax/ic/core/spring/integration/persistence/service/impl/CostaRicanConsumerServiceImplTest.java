package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.CostaRicanConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.CostaRicanConsumer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class CostaRicanConsumerServiceImplTest {
    CostaRicanConsumerDao argentinianConsumerDao = Mockito.mock(CostaRicanConsumerDao.class);
    CostaRicanConsumerServiceImpl argentinianConsumerService = new CostaRicanConsumerServiceImpl();
    @Before
    public void init(){
        ReflectionTestUtils.setField(argentinianConsumerService,"costaRicanConsumerDao",argentinianConsumerDao);
    }
    @Test
    public void methodClass4() throws IOException {
        CostaRicanConsumer b =new CostaRicanConsumer();
        Mockito.when(argentinianConsumerDao.save(b)).thenReturn(null);
        argentinianConsumerService.insertCostaRicanConsumer(b);
    }
}
