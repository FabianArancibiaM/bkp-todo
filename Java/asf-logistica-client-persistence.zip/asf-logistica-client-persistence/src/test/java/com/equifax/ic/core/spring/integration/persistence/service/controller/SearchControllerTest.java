package com.equifax.ic.core.spring.integration.persistence.service.controller;

import com.equifax.ic.core.clientapi.service.OrchestrationExecutionService;
import com.equifax.ic.core.clientapi.service.SearchDeployService;
import com.equifax.ic.core.spring.integration.persistence.controller.SearchController;
import com.equifax.ic.core.spring.integration.persistence.pojo.SearchCriteria;
import com.equifax.ic.core.spring.integration.persistence.search.SearchTransactionService;
import com.equifax.ic.core.spring.integration.persistence.service.SearchCriteriaService;
import com.fasterxml.jackson.databind.JsonNode;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class SearchControllerTest {
    final SearchController customTransactionController = new SearchController();
    SearchCriteriaService searchCriteriaService= Mockito.mock(SearchCriteriaService.class);
    final Map header = new HashMap<>();
    String request = null;
    private SearchTransactionService searchTransactionService= Mockito.mock(SearchTransactionService.class);
    private final OrchestrationExecutionService orchestrationExecutionService = Mockito.mock(OrchestrationExecutionService.class);
    private final SearchDeployService searchDeployService = Mockito.mock(SearchDeployService.class);
    String json = "{\"applicants\" : {\"primaryConsumer\" : {\"personalInformation\" : {\"transactionId\": \"112680000000060040\",\"initDate\":\"2020-01-01\",\"endDate\":\"2020-01-27\",\"name\" : [{\"identifier\" : \"current\"}],\"chileanRut\" : \"189077505\",\n" +
            "\"chileanSerialNumber\" : \"A022912537\",\"addresses\" : [{\"identifier\" : \"current\"}],\"customerReferenceIdentifier\" : \"ASF-LOGISTICA\",\"additionalAttribute\" : {\"usu_digito_sol\" : \"4\",\"usu_serie_sol\" : \"17457382\",\n" +
            "\"usu_mto_linea_solicitada\" : \"1.000.000\",\"usu_canal\" : \"003\",\"usu_direccion\" : \"Balmaceda 456\",\"usu_region\" : \"011\",\"usu_comuna\" : \"135\",\n" +
            "\"usu_email\" : \"guille@gmail.com\",\"usu_fono\" : \"5622265898\",\"usu_refbco_cuenta\" : \"165426365455\",\"usu_refbco_banco\" : \"005\",\"usu_refbco_suc\" : \"004\"}}}}}";
    @Before
    public void setUp() throws IOException {
        request = json;
        header.put("authorization", "Basic bGF0YW1wbGF0Zm9ybXRyaWJlc3RzOmxhdGFtcGxhdGZvcm10cmliZXN0cy4yMDE5");
        ReflectionTestUtils.setField(customTransactionController, "searchTransactionService", searchTransactionService);
        ReflectionTestUtils.setField(customTransactionController, "searchCriteriaService", searchCriteriaService);
    }
    @Test
    public void executeTransaction() throws IOException {
        Mockito.when(searchTransactionService.findTransactionByTransactionId(Mockito.mock(JsonNode.class))).thenReturn(new Object());
        customTransactionController.executeTransaction(request, header);
    }
    @Test
    public void executeTransactionFiltro() throws IOException {
        Mockito.when(searchCriteriaService.findByCriteria(Mockito.mock(JsonNode.class))).thenReturn(new LinkedList<>());
        customTransactionController.executeTransactionFiltro(request, header);
    }
}
