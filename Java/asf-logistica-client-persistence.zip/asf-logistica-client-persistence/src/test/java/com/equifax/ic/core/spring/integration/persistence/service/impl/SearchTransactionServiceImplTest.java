package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.search.impl.SearchTransactionServiceImpl;
import com.equifax.ic.core.spring.integration.persistence.service.IgService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SearchTransactionServiceImplTest {

    private SearchTransactionServiceImpl service = new SearchTransactionServiceImpl();
    private IgService igService= Mockito.mock(IgService.class);
    Object[] obj;
    String json = "{\"applicants\" : {\"primaryConsumer\" : {\n" +
            "\"personalInformation\" : {\"fromDate\":\"01-01-2020\",\n" +
            "\"untilDate\":\"20-01-2020\",\"chileanRut\" : \"174573824\",\n" +
            "\"decision\":\"Rechazar\",\"transactionId\": \"112680000000060055\"}}}}";
    String bbdd = "{" +
            "  \"clientOrchestrationStatus\" : \"completed\",\n" +
            " \"applicants\" : {\"primaryConsumer\" : {\"ccb\" : {\"ccb\" : {\n" +
            "\"uuid\" : \"93d1dc13-a526-4666-859e-abcb3c6ed6d2\",\"transactionInfo\" : {\"documentNumber\" : \"189077505\",\"serialNumber\" : \"A022912537\",\"fatherSurname\" : \"QUEZADA\",\n" +
            "\"motherSurname\" : \"MORA\",\"name\" : \"CARLA NICOL\",\"uuidTransaction\" : \"\",\"username\" : \"monitor.iplabel\",\"date\" : \"none\",\"hour\" : \"none\"},\n" +
            "\"expg04Section\" : {\"attributes\" : [ {\"variableName\" : \"DIC_REGION_18\",\"variableType\" : \"N\",\"correlative\" : \"005\",\"value\" : \"METROPOLITANA DE SANTIAGO\",\"decimalNumber\" : \"00\"}, {\n" +
            "\"variableName\" : \"DIC_DIRCOMUNA_18\",\"variableType\" : \"D\",\"correlative\" : \"012\",\"value\" : \"PUDAHUEL\",\"decimalNumber\" : \"00\"}]}}},\n" +
            "\"personalInformation\" : {\"name\" : [ {\"identifier\" : \"current\"} ],\"chileanRut\" : \"189077505\",\"chileanSerialNumber\" : \"A022912537\",\n" +
            "\"addresses\" : [ {\"identifier\" : \"current\"} ],\"customerReferenceIdentifier\" : \"ASF-LOGISTICA\",\n" +
            "\"additionalAttribute\" : {\"usu_digito_sol\" : \"4\",\"usu_serie_sol\" : \"17457382\",\"usu_mto_linea_solicitada\" : \"1.000.000\",\"usu_canal\" : \"003\",\"usu_direccion\" : \"Balmaceda 456\",\n" +
            "\"usu_region\" : \"011\",\"usu_comuna\" : \"135\",\"usu_email\" : \"guille@gmail.com\",\"usu_fono\" : \"5622265898\",\"usu_refbco_cuenta\" : \"165426365455\",\"usu_refbco_banco\" : \"005\",\"usu_refbco_suc\" : \"004\"}},\n" +
            "\"decisions\" : [ {\"smart-decisionId\" : [ {\"SCORE\" : 571,\"RUT\" : \"18907750\",\"DV\" : \"5\",\"REJECTCODE\" : \"SIN ACTIVIDAD ECONOMICA, \",\n" +
            "\"REASONCODE\" : \"R001, \",\"GLOSADECISION\" : \"Rechazar\",\"GLOSAADICIONAL\" : \"\",\"LINEASUGERIDA\" : 0,\"LINEAAPROBADA\" : 0,\"LINEAMAXIMASUGERIDA\" : 0,\"RAZONSOCIAL\" : \"\",\n" +
            "\"CANAL\" : \"Food Service\",\"CONDICIONAPROBADA\" : \"\",\"COMUNA\" : \"135\",\"REGION\" : \"011\",\"VECES_IVA\" : 0.0,\"VECES_RENTA\" : 0.0,\"PORC\" : 0.0} ]\n" +
            "      } ],\"transactionId\" : \"112680000000070043\",\"status\" : \"completed\"}},\n" +
            "  \"clientOrchestrationUUID\" : \"a6b64e53-a014-4bbe-8eb5-e489fc3a4c2f\",\n" +
            "  \"clientOrchestrationDateCreated\" : \"2020-01-28T19:05:13.946+0000\",\n" +
            "  \"clientOrchestrationDateModified\" : null\n" +
            "}";
    byte[] b;
    @Before
    public void init(){
        ReflectionTestUtils.setField(service, "igService", igService);
        b = bbdd.getBytes(StandardCharsets.UTF_8);
        obj = new Object[8];
        obj[0]="asd";
        obj[1]="asd";
        obj[2]=new Date();
        obj[3]="asd";
        obj[4]="asd";
        obj[5]=b;
        obj[6]="3";
        obj[7]="3";

    }
    @Test
    public void findTransactionByTransactionIdTest() throws IOException {
        String transactionId = "112680000000060040";
        obj[1]=b;
        Mockito.when(igService.getTransactionId(transactionId)).thenReturn(obj);
        JsonNode jRequest = (new ObjectMapper()).readTree(json);
        service.findTransactionByTransactionId(jRequest);
    }
}
