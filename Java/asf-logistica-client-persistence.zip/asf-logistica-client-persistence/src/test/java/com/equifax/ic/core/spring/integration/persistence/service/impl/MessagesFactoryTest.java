package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.factory.impl.MessagesFactory;
import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

public class MessagesFactoryTest {

    private MessagesFactory messagesFactory;
    private ObjectMapper objectMapper;
    private List<Messages> messagesList;

    @Before
    public void setUp() throws Exception {
        messagesFactory = new MessagesFactory();
        objectMapper = new ObjectMapper();
        messagesList = new ArrayList<>();
    }

    @Test
    public void logMessages() {
        messagesFactory.logMessages(null, null, null);
    }

    @Test
    public void getList() {
        ReflectionTestUtils.setField(this.messagesFactory, "messagesList", this.messagesList);
        ReflectionTestUtils.setField(this.messagesFactory, "objectMapper", this.objectMapper);
        messagesFactory.getList();
    }

    @Test
    public void setMessagesList() {
        ReflectionTestUtils.setField(this.messagesFactory, "messagesList", this.messagesList);
        ReflectionTestUtils.setField(this.messagesFactory, "objectMapper", this.objectMapper);
        messagesFactory.setMessagesList(null);
    }

    @Test
    public void fillSystemEventIds() {
        messagesFactory.fillSystemEventIds();
    }
}