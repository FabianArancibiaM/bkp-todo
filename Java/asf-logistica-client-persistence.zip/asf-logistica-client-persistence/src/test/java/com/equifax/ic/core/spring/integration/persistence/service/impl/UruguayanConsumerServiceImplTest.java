package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.UruguayanConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.UruguayanConsumer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class UruguayanConsumerServiceImplTest {
    UruguayanConsumerDao argentinianConsumerDao = Mockito.mock(UruguayanConsumerDao.class);
    UruguayanConsumerServiceImpl argentinianConsumerService = new UruguayanConsumerServiceImpl();
    @Before
    public void init(){
        ReflectionTestUtils.setField(argentinianConsumerService,"uruguayanConsumerDao",argentinianConsumerDao);
    }
    @Test
    public void methodClass4() throws IOException {
        UruguayanConsumer b =new UruguayanConsumer();
        Mockito.when(argentinianConsumerDao.save(b)).thenReturn(null);
        argentinianConsumerService.insertUruguayanConsumer(b);
    }
}
