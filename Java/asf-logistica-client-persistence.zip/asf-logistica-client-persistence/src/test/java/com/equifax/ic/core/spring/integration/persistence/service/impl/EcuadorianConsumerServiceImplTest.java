package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.EcuadorianConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.EcuadorianConsumer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class EcuadorianConsumerServiceImplTest {
    EcuadorianConsumerDao argentinianConsumerDao = Mockito.mock(EcuadorianConsumerDao.class);
    EcuadorianConsumerServiceImpl argentinianConsumerService = new EcuadorianConsumerServiceImpl();
    @Before
    public void init(){
        ReflectionTestUtils.setField(argentinianConsumerService,"ecuadorianConsumerDao",argentinianConsumerDao);
    }
    @Test
    public void methodClass4() throws IOException {
        EcuadorianConsumer b =new EcuadorianConsumer();
        Mockito.when(argentinianConsumerDao.save(b)).thenReturn(null);
        argentinianConsumerService.insertEcuadorianConsumer(b);
    }
}
