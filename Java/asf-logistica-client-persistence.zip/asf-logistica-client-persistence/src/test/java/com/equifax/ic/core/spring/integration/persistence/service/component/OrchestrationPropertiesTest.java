package com.equifax.ic.core.spring.integration.persistence.service.component;

import com.equifax.ic.core.spring.integration.persistence.component.OrchestrationProperties;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class OrchestrationPropertiesTest {

    @Test
    public void classTest(){
        OrchestrationProperties orch = new OrchestrationProperties();
        Map<String, Map<String, String>> orchestration = new HashMap<>();
        Map<String, Map<String, Map<String, String>>> client = new HashMap<>();
        orch.setClient(client);
        orch.getClient();
        orch.setOrchestration(orchestration);
        orch.getOrchestration();
        Map<String, Object> persistence = new HashMap<>();
        persistence.put("ci",null);
        persistence.put("ig",null);
        persistence.put("smarts",null);
        persistence.put("mit",null);
        orch.setPersistence(persistence);
        orch.getPersistence();
        orch.setServicesTimeout(null);
        orch.getServicesTimeout();
        orch.getCi();
        orch.getIg();
        orch.getMit();
        orch.getSmarts();
    }
}
