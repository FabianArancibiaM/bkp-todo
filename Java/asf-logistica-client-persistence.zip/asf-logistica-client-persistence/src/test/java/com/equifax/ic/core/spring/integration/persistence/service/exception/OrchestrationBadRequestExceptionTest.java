package com.equifax.ic.core.spring.integration.persistence.service.exception;

import com.equifax.ic.core.spring.integration.persistence.exception.OrchestrationBadRequestException;
import org.junit.Test;

public class OrchestrationBadRequestExceptionTest {
    @Test
    public void methodClass(){
        OrchestrationBadRequestException ex2 = new OrchestrationBadRequestException(new Throwable());
        OrchestrationBadRequestException ex3 = new OrchestrationBadRequestException("",new Throwable());
        OrchestrationBadRequestException ex4 = new OrchestrationBadRequestException("",new Throwable(),true,true);
    }
}
