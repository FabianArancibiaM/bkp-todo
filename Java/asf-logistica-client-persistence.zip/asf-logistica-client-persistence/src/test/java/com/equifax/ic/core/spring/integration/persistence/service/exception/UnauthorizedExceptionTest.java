package com.equifax.ic.core.spring.integration.persistence.service.exception;

import com.equifax.ic.core.spring.integration.persistence.exception.UnauthorizedException;
import org.junit.Test;

public class UnauthorizedExceptionTest {
    @Test
    public void methodClass(){
        UnauthorizedException ex = new UnauthorizedException();
        UnauthorizedException ex2 = new UnauthorizedException(new Throwable());
        UnauthorizedException ex3 = new UnauthorizedException("",new Throwable());
        UnauthorizedException ex4 = new UnauthorizedException("",new Throwable(),true,true);
    }
}
