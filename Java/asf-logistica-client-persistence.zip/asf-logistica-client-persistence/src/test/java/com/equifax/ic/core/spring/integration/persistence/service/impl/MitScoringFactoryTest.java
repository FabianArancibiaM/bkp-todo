package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.factory.impl.MitScoringFactory;
import com.equifax.ic.core.spring.integration.persistence.pojo.MitPojo;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MitScoringFactoryTest {

    private MitScoringFactory mitScoringFactory;
    private List<MitPojo> mitPojoList = new ArrayList<>();

    @Before
    public void setUp() throws Exception {
        mitScoringFactory = new MitScoringFactory();
    }

    @Test
    public void logMitScoring() {
        mitScoringFactory.logMitScoring(0, "", "", "");
    }

    @Test
    public void getList() {
        ReflectionTestUtils.setField(this.mitScoringFactory, "mitPojoList", this.mitPojoList);
        mitScoringFactory.getList();
    }

    @Test
    public void setMitScoringList() {
        ReflectionTestUtils.setField(this.mitScoringFactory, "mitPojoList", this.mitPojoList);
        mitScoringFactory.setMitScoringList(new LinkedList<>());
    }
}