package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.HonduranConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.HonduranConsumer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

public class HonduranConsumerServiceImplTest {
    HonduranConsumerDao argentinianConsumerDao = Mockito.mock(HonduranConsumerDao.class);
    HonduranConsumerServiceImpl argentinianConsumerService = new HonduranConsumerServiceImpl();
    @Before
    public void init(){
        ReflectionTestUtils.setField(argentinianConsumerService,"honduranConsumerDao",argentinianConsumerDao);
    }
    @Test
    public void methodClass4() throws IOException {
        HonduranConsumer b =new HonduranConsumer();
        Mockito.when(argentinianConsumerDao.save(b)).thenReturn(null);
        argentinianConsumerService.insertHonduranConsumer(b);
    }
}
