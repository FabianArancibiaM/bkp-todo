package com.equifax.ic.core.spring.integration.persistence.service.config;

import com.equifax.ic.core.spring.integration.persistence.config.PersistenceConfiguration;
import com.equifax.ic.core.spring.integration.persistence.service.impl.*;
import org.junit.Before;
import org.junit.Test;

public class PersistenceConfigurationTest {

    private PersistenceConfiguration persistenceConfiguration;

    @Before
    public void setUp() throws Exception {
        persistenceConfiguration = new PersistenceConfiguration();
    }

    @Test
    public void persistenceFactories() {
        persistenceConfiguration.factoriesContainer(new BasicSystemEventService(), new BasicMessagesService(),
                new BasicIgService(), new BasicMitService(), new BasicSmartsService(), new BasicAnavService());
    }
}