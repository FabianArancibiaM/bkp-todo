package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.IgDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.IgPojo;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BasicIgServiceTest {

    private BasicIgService basicIgService;
    private IgDao igDao;

    @Before
    public void setUp(){

        basicIgService = new BasicIgService();
        igDao = mock(IgDao.class);
    }

    @Test
    public void getAllIg() {
        ReflectionTestUtils.setField(this.basicIgService,"igDao", this.igDao);
        when(igDao.findAll()).thenReturn(new LinkedList<>());
        basicIgService.getAllIg();
    }

    @Test
    public void getIgById() {
        ReflectionTestUtils.setField(this.basicIgService,"igDao", this.igDao);
        when(igDao.findOne(Mockito.anyLong())).thenReturn(new IgPojo());
        basicIgService.getIgById((Mockito.anyLong()));
    }

    @Test
    public void insertIg() {
        ReflectionTestUtils.setField(this.basicIgService,"igDao", this.igDao);
        when(igDao.save(Mockito.any(IgPojo.class))).thenReturn(new IgPojo());
        basicIgService.insertIg(new IgPojo());
    }

    @Test
    public void updateIg() {
        ReflectionTestUtils.setField(this.basicIgService,"igDao", this.igDao);
        when(igDao.save(Mockito.any(IgPojo.class))).thenReturn(new IgPojo());
        when(basicIgService.getIgById(Mockito.anyLong())).thenReturn(new IgPojo());
        try {
            basicIgService.updateIg((new IgPojo()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void insertList() {
        List<IgPojo> igDecisioningList = new ArrayList();
        igDecisioningList.add(new IgPojo());

        ReflectionTestUtils.setField(this.basicIgService,"igDao", this.igDao);
        when(igDao.save(Mockito.any(IgPojo.class))).thenReturn(new IgPojo());
        basicIgService.insertList(igDecisioningList);
    }
    @Test
    public void getTransactionIdTest() throws IOException {
        ReflectionTestUtils.setField(this.basicIgService,"igDao", this.igDao);
        when(igDao.findTransaction("")).thenReturn(new ArrayList<>());
        basicIgService.getTransactionId("");
    }
}