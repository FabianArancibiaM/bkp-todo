package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.PeruvianConsumer;

public interface PeruvianConsumerService {
	
	void insertPeruvianConsumer(PeruvianConsumer peruvianConsumerService);

}
