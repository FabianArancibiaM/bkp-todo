package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.ChileanConsumer;
import org.springframework.data.repository.CrudRepository;

public interface ChileanConsumerDao extends CrudRepository<ChileanConsumer, Long>{
	
}
