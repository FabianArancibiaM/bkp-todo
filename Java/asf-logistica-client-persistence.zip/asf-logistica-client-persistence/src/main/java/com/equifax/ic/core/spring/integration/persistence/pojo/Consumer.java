package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;

@Entity(name = "Consumer")
@Table(name = "CONSUMER")
public class Consumer {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "CONSUMER_SEQ", allocationSize = 1)
	private Long id;

	@Column(name = "AGE")
	private int age;

	@Column(name = "FIRSTNAME")
	private String firstName;

	@Column(name = "LASTNAME")
	private String lastName;

	@Column(name = "APPLICANTIDENTIFIER")
	private String applicationIdentifier;

	@Column(name = "UUID")
	private String uuid;

	@Column(name = "COUNTRY")
	private String country;
	
    @OneToOne(mappedBy = "consumer")
    private ArgentinianConsumer argentinianConsumer;
    
    @OneToOne(mappedBy = "consumer")
    private UruguayanConsumer uruguayanConsumer;
    
    public ArgentinianConsumer getArgentinianConsumer() {
		return argentinianConsumer;
	}

	public void setArgentinianConsumer(ArgentinianConsumer argentinianConsumer) {
		this.argentinianConsumer = argentinianConsumer;
	}

	public UruguayanConsumer getUruguayanConsumer() {
		return uruguayanConsumer;
	}

	public void setUruguayanConsumer(UruguayanConsumer uruguayanConsumer) {
		this.uruguayanConsumer = uruguayanConsumer;
	}

	public ChileanConsumer getChileanConsumer() {
		return chileanConsumer;
	}

	public void setChileanConsumer(ChileanConsumer chileanConsumer) {
		this.chileanConsumer = chileanConsumer;
	}

	public PeruvianConsumer getPeruvianConsumer() {
		return peruvianConsumer;
	}

	public void setPeruvianConsumer(PeruvianConsumer peruvianConsumer) {
		this.peruvianConsumer = peruvianConsumer;
	}

	@OneToOne(mappedBy = "consumer")
    private ChileanConsumer chileanConsumer;
    
    @OneToOne(mappedBy = "consumer")
    private PeruvianConsumer peruvianConsumer;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getApplicationIdentifier() {
		return applicationIdentifier;
	}

	public void setApplicationIdentifier(String applicationIdentifier) {
		this.applicationIdentifier = applicationIdentifier;
	}

}