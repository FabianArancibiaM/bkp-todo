package com.equifax.ic.core.spring.integration.persistence.util;

import com.equifax.ic.core.spring.integration.persistence.exception.UnauthorizedException;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class TokenObtained {

    public static final Logger LOGGER = LoggerFactory.getLogger(TokenObtained.class);

    private static final String AUTHORIZATION = "authorization";

    @Value("${ic.security.oauth2.tokenEndpoint}")
    private String oauthUrl;
    @Value("${ic.security.oauth2.clientId2}")
    private String oauthClientId2;
    @Value("${ic.security.oauth2.clientSecret}")
    private String oauthClientSecret;
    @Value("${ic.security.oauth2.resourceDetails.grantType}")
    private String oauthGrantType;
    @Value("${ic.security.oauth2.scope.readProfile}")
    private String oauthReadProfile;
    @Value("${ic.security.oauth2.scope.editProfile}")
    private String oauthEditProfile;

    // Bearer Token
    @Value("${ic.security.oauth2.clientId}")
    private String oauthClientId;
    @Value("${ic.security.oauth2.discoveryURL}")
    private String discoveryURL;
    @Value("${ic.security.oauth2.disableCertificationVerification}")
    private String disableCertificationVerification;
    @Value("${ic.security.oauth2.hostNameVerifier}")
    private String hostNameVerifier;

    @Autowired
    RestTemplate restTemplateCustom;

    public void getToken(Map<String, Object> header) throws UnauthorizedException {

        LOGGER.info("Obtaining token from OAuth...");
        if (header.get(AUTHORIZATION) == null || !header.get(AUTHORIZATION).toString().contains("Basic ")) {
            throw new UnauthorizedException("Header without authorization values");
        }
        String basicCredentials = header.get(AUTHORIZATION).toString().replace("Basic ", "");

        Base64 encoder = new Base64();
        byte[] authorizationBytes = encoder.decode(basicCredentials);
        String authorizationDecoded = new String(authorizationBytes, Charset.forName("UTF-8"));
        String[] authorizationArray = authorizationDecoded.split(":");
        Map mapToken = this.getLoginWithTokenAuth(authorizationArray[0], authorizationArray[1]).getBody();
        Object accessToken = mapToken.get("access_token");

        if (accessToken == null) {
            throw new UnauthorizedException("Failed to obtain bearer token from OAuth. Please, see logs for more information");
        }

        String finalToken = "Bearer " + accessToken.toString();
        header.replace(AUTHORIZATION, finalToken);

        LOGGER.info("Token from OAuth obtained");
    }

    private ResponseEntity<Map> getLoginWithTokenAuth(String username, String pass) throws UnauthorizedException {

        try {
            LOGGER.info("Before pull Login in Oauth");
            HttpEntity<?> httpEntity = setDetailsToRequestOauth(username, pass);
            ResponseEntity<Map> exchange = restTemplateCustom
                    .exchange(
                            this.oauthUrl,
                            HttpMethod.POST,
                            httpEntity,
                            Map.class
                    );
            LOGGER.info("After pull Login in Oauth");
            return exchange;
        } catch (HttpClientErrorException e) {
            System.err.println(e.getLocalizedMessage());
            throw new UnauthorizedException("Bad credentials (Error getting token in OAuth service).");
        }
    }

    private HttpEntity<?> setDetailsToRequestOauth(String username, String password) {
        HttpHeaders headers = new HttpHeaders();
        String clientOAuth = this.oauthClientId2.concat(":".concat(this.oauthClientSecret));
        byte[] encodeBase64 = Base64.encodeBase64(clientOAuth.getBytes(StandardCharsets.UTF_8));
        headers.add(AUTHORIZATION, String.format("Basic %s", new String(encodeBase64, StandardCharsets.UTF_8)));
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> requestBodyParams = new LinkedMultiValueMap();
        requestBodyParams.add("username", username);
        requestBodyParams.add("password", password);
        requestBodyParams.add("grant_type", this.oauthGrantType);
        requestBodyParams.add("scope", this.oauthReadProfile + " " + this.oauthEditProfile);
        return new HttpEntity(requestBodyParams, headers);
    }
}
