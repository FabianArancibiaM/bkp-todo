package com.equifax.ic.core.spring.integration.persistence.service.impl;


import com.equifax.ic.core.spring.integration.persistence.dao.TransactionDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.Transaction;
import com.equifax.ic.core.spring.integration.persistence.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionDao transactionDao;

	@Override
	@Transactional
	public void insertTransaction(Transaction transaction) {
		transactionDao.save(transaction);
	}

	@Override
	public Transaction getTransactionById(Long id) {
		return transactionDao.findOne(id);
	}

	@Transactional
	public Transaction findTransactionById(String transactionId) {
		return transactionDao.findByUUID(transactionId);
	}

	@Transactional
	public Transaction updateTransaction(Transaction transaction) throws IOException {
		if(getTransactionById(transaction.getId()) == null){
			throw new IOException("Transaction does not exist");
		}
		return transactionDao.save(transaction);
	}
	
}
