package com.equifax.ic.core.spring.integration.persistence.controller;

import com.equifax.ic.core.clientapi.domain.OrchestrationExecutionResponse;
import com.equifax.ic.core.clientapi.domain.Transaction;
import com.equifax.ic.core.clientapi.domain.TransactionContext;
import com.equifax.ic.core.clientapi.rest.event.EventUtils;
import com.equifax.ic.core.clientapi.service.OrchestrationExecutionService;
import com.equifax.ic.core.clientapi.service.SearchDeployService;
import com.equifax.ic.core.spring.integration.persistence.exception.InternalErrorException;
import com.equifax.ic.infrastructure.event.domain.Event;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

@RestController
@Api(
        value = "Transaction Execution",
        tags = {"TransactionExecution"}
)
public class CustomTransactionController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CustomTransactionController.class);

    @Autowired
    private String gatewayPath;

    @Autowired
    private OrchestrationExecutionService orchestrationExecutionService;

    @Autowired
    private SearchDeployService searchDeployService;

    @Value("${cpt.searchTransactionDeployEnabled}")
    private String searchTransactionDeployEnabled;

    @RequestMapping(
            value = {"/api/consumer"},
            method = {RequestMethod.POST},
            consumes = {"application/vnd.com.equifax.backbone.service.orchestration.rest.request.v1+json"},
            produces = {"application/vnd.com.equifax.backbone.service.orchestration.rest.response.v1+json"}
    )
    @ApiOperation("Execute Transaction")
    @ApiResponses({@ApiResponse(
            code = 400,
            message = "Bad Request"
    ), @ApiResponse(
            code = 500,
            message = "Server Error"
    )})
    public ResponseEntity<Object> executeTransaction(@RequestBody String request, @RequestHeader Map<String, Object> headers) throws IOException {
        String[] gatewayPathArray = gatewayPath.split("_");
        if (gatewayPathArray.length < 4) {
            LOGGER.error("Problems loading gateway for endpoint CO Conversion");
            throw new InternalErrorException("Problems loading gateway for endpoint CO Conversion");
        }
        //LOGGER.debug("Calling Transaction execution with request: {}.", request);
        LOGGER.debug("Transaction for Organization {}, Configuration {}, Baseline UUID {} and Orchestration {}.",
                new Object[]{gatewayPathArray[0], gatewayPathArray[1], gatewayPathArray[2], gatewayPathArray[3]});
        this.verifyParameters(gatewayPathArray[0], gatewayPathArray[1], gatewayPathArray[2], gatewayPathArray[3]);
        this.setupHeaders(headers, gatewayPathArray[0], gatewayPathArray[1], gatewayPathArray[2], gatewayPathArray[3], "Submission");
        return this.executeOrchestrationExecution(request, headers);
    }

    private void verifyParameters(String organization, String configuration, String baseline, String orchestration) {
        Assert.hasText(organization, "Organization is required");
        Assert.hasText(configuration, "Configuration is required");
        Assert.hasText(baseline, "Baseline is required");
        Assert.hasText(orchestration, "Orchestration is required");
    }

    private void setupHeaders(Map<String, Object> header, String organization, String configuration, String baseline, String orchestration, String operation) {
        String transactionId = this.generateNewUUID();
        String correlationId = this.generateNewUUID();
        String submissionId = this.generateNewUUID();
        header.put("transactionContext", this.createTransactionContext(organization, configuration, baseline, orchestration, transactionId, correlationId));
        header.put("action", operation);
        this.setupTransactionHeaders(header, transactionId, correlationId, submissionId);
    }

    private String generateNewUUID() {
        return UUID.randomUUID().toString();
    }

    private TransactionContext createTransactionContext(String organization, String configuration, String baseline, String orchestration, String transactionId, String correlationId) {
        TransactionContext transactionContext = new TransactionContext();
        transactionContext.addProperty("organizationCode", organization);
        transactionContext.addProperty("configurationId", configuration);
        transactionContext.addProperty("baselineId", baseline);
        transactionContext.addProperty("orchestration", orchestration);
        transactionContext.addProperty("transactionId", transactionId);
        transactionContext.addProperty("correlationId", correlationId);
        transactionContext.addProperty("dateCreated", new Date());
        return transactionContext;
    }

    private void setupTransactionHeaders(Map<String, Object> header, String transactionId, String correlationId, String submissionId) {
        header.put("correlationId", correlationId);
        header.put("transactionId", transactionId);
        header.put("submissionId", submissionId);
    }

    private ResponseEntity<Object> executeOrchestrationExecution(String request, Map<String, Object> headers) throws IOException {
        OrchestrationExecutionResponse orchestrationExecutionResponse = null;
        Event event = EventUtils.initializeEvent("Submission");

        try {
            orchestrationExecutionResponse = this.orchestrationExecutionService.submit(this.createPayload(request), headers);
            if (this.searchTransactionDeployEnabled.equals("true")) {
                this.searchDeployService.executeTransactionSearchDeploy((Transaction) orchestrationExecutionResponse.getResponse(), headers);
            }
        } catch (Exception var9) {
            EventUtils.setExceptionAttributesForEvent(event, var9);
            throw var9;
        } finally {
            EventUtils.finalizeEvent(event, orchestrationExecutionResponse, headers);
            EventUtils.produceEvent(event);
            cleanUpContext();
        }

        return new ResponseEntity(orchestrationExecutionResponse.getResponse(), orchestrationExecutionResponse.getHttpStatus());
    }

    private Map<String, Object> createPayload(String request) throws IOException {
        Map<String, Object> payload = Maps.newHashMap();
        payload.put("INITIAL_REQUEST", this.parseRequest(request));
        return payload;
    }

    private JsonNode parseRequest(String request) throws IOException {
        return (new ObjectMapper()).readTree(request);
    }

    private static void cleanUpContext() {
        if (MDC.get("UUID") != null) {
            MDC.remove("UUID");
        }
    }

    public void setGatewayPath(String gatewayPath) {
        this.gatewayPath = gatewayPath;
    }

    public void setOrchestrationExecutionService(OrchestrationExecutionService orchestrationExecutionService) {
        this.orchestrationExecutionService = orchestrationExecutionService;
    }

    public void setSearchDeployService(SearchDeployService searchDeployService) {
        this.searchDeployService = searchDeployService;
    }

    public void setSearchTransactionDeployEnabled(String searchTransactionDeployEnabled) {
        this.searchTransactionDeployEnabled = searchTransactionDeployEnabled;
    }
}
