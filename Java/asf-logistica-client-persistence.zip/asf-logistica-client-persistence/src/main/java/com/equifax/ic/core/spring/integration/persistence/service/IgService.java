package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.IgPojo;

import java.io.IOException;
import java.util.Date;
import java.util.List;

public interface IgService extends FactoryService {	

    List<IgPojo> getAllIg();

    IgPojo getIgById(final Long id);

    void insertIg(IgPojo ig);

    IgPojo updateIg(IgPojo ig) throws IOException;

    Object[] getTransactionId(String transactionId) throws IOException;

}
