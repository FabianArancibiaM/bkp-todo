package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.CostaRicanConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.CostaRicanConsumer;
import com.equifax.ic.core.spring.integration.persistence.service.CostaRicanConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class CostaRicanConsumerServiceImpl implements CostaRicanConsumerService {
	
	@Autowired
	private CostaRicanConsumerDao costaRicanConsumerDao;

	@Override
	@Transactional
	public void insertCostaRicanConsumer(CostaRicanConsumer consumer) {
		costaRicanConsumerDao.save(consumer);

	}

}