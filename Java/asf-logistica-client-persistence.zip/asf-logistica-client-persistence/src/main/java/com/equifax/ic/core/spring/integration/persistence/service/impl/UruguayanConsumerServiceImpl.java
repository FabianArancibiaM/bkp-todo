package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.UruguayanConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.UruguayanConsumer;
import com.equifax.ic.core.spring.integration.persistence.service.UruguayanConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UruguayanConsumerServiceImpl implements UruguayanConsumerService {

	@Autowired
	private UruguayanConsumerDao uruguayanConsumerDao;
	
	@Override
	@Transactional
	public void insertUruguayanConsumer(UruguayanConsumer uruguayanConsumer) {
		
		uruguayanConsumerDao.save(uruguayanConsumer);
		
	}

}
