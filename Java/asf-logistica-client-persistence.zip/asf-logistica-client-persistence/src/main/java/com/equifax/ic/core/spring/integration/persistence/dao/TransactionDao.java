package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.Transaction;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface TransactionDao extends CrudRepository<Transaction, Long>{
	
	@Query(value = "SELECT t FROM Transaction t WHERE t.uuid = :uuid")
    public Transaction findByUUID(@Param("uuid") String uuid);
}

