package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "SMARTSDECISIONING")
public class SmartsPojo {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    @SequenceGenerator(name = "SEQ", sequenceName = "SMARTSDECISIONING_SEQ", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "IDENTIFIER")
    private String identifier;

    @Column(name = "UUID")
    private String uuid;

    @Column(name = "DECISION")
    private String decision;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "REASONS")
    private String reasons;

    @Column(name = "OVERRIDE")
    private Integer override;

    @Column(name = "TYPE")
    private String type;

    @Column(name = "DATECREATED")
    private Date dateCreated;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReasons() {
        return reasons;
    }

    public void setReasons(String reasons) {
        this.reasons = reasons;
    }

    public Integer getOverride() {
        return override;
    }

    public void setOverride(Integer override) {
        this.override = override;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

}