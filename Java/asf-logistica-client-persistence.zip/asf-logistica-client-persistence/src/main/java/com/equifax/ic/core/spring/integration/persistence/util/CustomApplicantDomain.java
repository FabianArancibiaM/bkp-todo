package com.equifax.ic.core.spring.integration.persistence.util;

public enum CustomApplicantDomain {
    CLIENTORCHESTRATIONUUID("clientOrchestrationUUID"),
    CLIENTORCHESTRATIONDATECREATED("clientOrchestrationDateCreated"),
    CLIENTORCHESTRATIONSTATUS("clientOrchestrationStatus"),
    CLIENTORCHESTRATIONDATEMODIFIED("clientOrchestrationDateModified");

    private final String value;

    CustomApplicantDomain(String s) {
        this.value = s;
    }

    public String getValue() {
        return this.value;
    }
}
