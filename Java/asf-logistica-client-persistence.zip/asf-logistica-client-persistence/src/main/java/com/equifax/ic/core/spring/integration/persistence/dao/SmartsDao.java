package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.SmartsPojo;
import org.springframework.data.repository.CrudRepository;

public interface SmartsDao extends CrudRepository<SmartsPojo, Long> {
}
