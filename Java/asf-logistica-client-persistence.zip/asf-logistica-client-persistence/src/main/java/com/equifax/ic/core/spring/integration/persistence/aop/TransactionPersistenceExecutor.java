package com.equifax.ic.core.spring.integration.persistence.aop;


import com.equifax.ic.core.spring.integration.persistence.component.MicroServicesIdCollector;
import com.equifax.ic.core.spring.integration.persistence.component.RequestValidator;
import com.equifax.ic.core.spring.integration.persistence.component.TransactionPersistence;
import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.factory.PersistenceFactories;
import com.equifax.ic.core.spring.integration.persistence.pojo.Transaction;
import com.equifax.ic.core.spring.integration.persistence.service.FactoryService;
import com.equifax.ic.core.spring.integration.persistence.service.TransactionService;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantDomain;
import com.equifax.ic.core.spring.integration.persistence.util.CustomApplicantDomain;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * <p>
 * This class is responsible for execution of TransactionPersistence methods. Aspect is used to do that.
 * Also, enrich the final response with additional information using the same pointcuts.
 * </p>
 * 
 * @author Alan Sandoval axs831
 * @since 31-08-2018 1.0
 */

@Aspect
public class TransactionPersistenceExecutor {

	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionPersistenceExecutor.class);

	@Value("${server.context-path}")
    String contextPath;

	@Autowired
	private String gatewayPath;

	@Autowired
	TransactionPersistence transactionPersistence;

	@Autowired
    TransactionService transactionService;

	@Autowired
	MicroServicesIdCollector microServicesIdCollector;

	@Autowired
    Map<Class<? extends Factory>, FactoryService> factoriesContainer;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	HttpServletRequest httpServletRequest;

	@Resource(name = "customRequestValidator")
	private RequestValidator requestValidator;


	@SuppressWarnings("unchecked")
	//@Around("execution(private org.springframework.http.ResponseEntity com.equifax.ic.core.clientapi.rest.controller.TransactionController.executeOrchestrationExecution(String, Map<String, Object>)) && args(request, headers)")
	@Around("execution(private org.springframework.http.ResponseEntity com.equifax.ic.core.spring.integration.persistence.controller.CustomTransactionController.executeOrchestrationExecution(String, Map<String, Object>)) && args(request, headers)")
	public ResponseEntity<Object> aroundExecuteOrchestrationExecution(ProceedingJoinPoint joinPoint, String request, Map<String, Object> headers) throws Throwable {

		LOGGER.info("Method 'executeOrchestrationExecution' of 'TransactionController' class intercepted with Aspect, BEFORE its execution");

		LOGGER.info("Validating request...");
		requestValidator.validateRequest(request);

		Map<String, Object> payload = createPayload(request);
		headers.put("microServicesIdCollector", microServicesIdCollector);
		headers.put("persistenceFactories", new PersistenceFactories(factoriesContainer));
		persistCiRequestInvoker(payload, headers);
		ResponseEntity<Object> response = (ResponseEntity<Object>) joinPoint.proceed();

		LOGGER.info("Method 'executeOrchestrationExecution' of 'TransactionController' class intercepted with Aspect, AFTER its execution");
		if (response.getStatusCode().is2xxSuccessful()){

			Transaction currentTransaction = getTransaction(headers);
			if (currentTransaction != null){

				Map<String, Object> finalResponseEnriched;
				Object finalResponse = response.getBody();
				if (finalResponse instanceof Map){
					finalResponseEnriched = finalResponseEnricher((Map<String, Object>) finalResponse, currentTransaction);
				} else {
					finalResponseEnriched = finalResponseEnricher(objectMapper.convertValue(finalResponse, Map.class), currentTransaction);
				}

				persistCiResponseInvoker(finalResponseEnriched, headers, currentTransaction);

				return new ResponseEntity(finalResponseEnriched, response.getStatusCode());

			} else {
				throw new IOException(String.format("Transaction id '%s' was not found in DB. CI response persistence failed", (String) headers.get(ApplicantDomain.TRANSACTION_ID_KEY.getValue())));
			}
		} else {
			return response;
		}

	}

	private Map<String, Object> createPayload(String request) throws IOException {
		Map<String, Object> payload = Maps.newHashMap();
		JsonNode payloadJson = (new ObjectMapper()).readTree(request);
		payload.put("INITIAL_REQUEST", payloadJson);
		return payload;
	}

	private void persistCiRequestInvoker(Map<String, Object> payload, Map<String, Object> headers) throws IOException {
		String[] gatewayPathArray = gatewayPath.split("_");
		try{
			LOGGER.info("Getting the Client Implementation-Orchestration end point...");
			//String clientImplementationEndPoint = httpServletRequest.getRequestURI();
			String clientImplementationEndPoint = "/" + contextPath + "/api/transaction/" + gatewayPathArray[0] + "/" + gatewayPathArray[1] + "/" + gatewayPathArray[2] + "/" + gatewayPathArray[3];
			LOGGER.info("Put Client Implementation-Orchestration end point inside the headers  ...");
			headers.put("clientImplementationEndPoint",clientImplementationEndPoint);
			LOGGER.info("Calling TransactionPersistence.persistCiRequest()...");
			transactionPersistence.persistCiRequest(payload, headers);
			LOGGER.info("TransactionPersistence.persistCiRequest() executed correctly");
		} catch (Exception e) {
			throw new IOException(e);
		}
	}

	private void persistCiResponseInvoker(Map<String, Object> payload, Map<String, Object> headers, Transaction transaction) throws IOException {
		try{
			LOGGER.info("Calling TransactionPersistence.persistCiResponse()...");
			transactionPersistence.persistCiResponse(payload, headers, transaction);
			LOGGER.info("TransactionPersistence.persistCiResponse() executed correctly");

		} catch (Exception e) {
			throw new IOException(e);
		}
	}

	private Map<String, Object> finalResponseEnricher(Map<String, Object> payload, Transaction transaction) {

		LOGGER.info("Enriching final response with additional info...");

		Map<String, Object> finalResponse = new LinkedHashMap<>();

		finalResponse.put(ApplicantDomain.CLIENTIMPLEMENTATIONSTATUS.getValue(), ApplicantDomain.COMPLETED.getValue());
		finalResponse.putAll(payload);
		finalResponse.put(ApplicantDomain.CLIENTIMPLEMENTATIONUUID.getValue(), transaction.getUuid());
		finalResponse.put(ApplicantDomain.CLIENTIMPLEMENTATIONDATECREATED.getValue(), transaction.getDateCreated());
		finalResponse.put(ApplicantDomain.CLIENTIMPLEMENTATIONDATEMODIFIED.getValue(), transaction.getDateModified());
		return finalResponse;
	}

	private Transaction getTransaction(Map<String, Object> headers){
		String transactionId = (String) headers.get(ApplicantDomain.TRANSACTION_ID_KEY.getValue());
		return transactionService.findTransactionById(transactionId);
	}

}
