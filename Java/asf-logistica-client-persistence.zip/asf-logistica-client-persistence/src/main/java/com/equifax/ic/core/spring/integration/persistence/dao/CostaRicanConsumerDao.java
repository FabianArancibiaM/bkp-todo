package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.CostaRicanConsumer;
import org.springframework.data.repository.CrudRepository;

public interface CostaRicanConsumerDao extends CrudRepository<CostaRicanConsumer, Long> {

}