package com.equifax.ic.core.spring.integration.persistence.util;

/**
 * Use this enum to iterate over consumers supported by CI.
 * 
 * @author Alan Sandoval axs831
 * @since 14-08-2018 1.0
 */
public enum ApplicantEnumerator {

	PRIMARY_CONSUMER("primaryConsumer"), SECONDARY_CONSUMER("secondaryConsumer"), THIRD_CONSUMER("thirdConsumer"),
	FOURTH_CONSUMER("fourthConsumer"), FIFTH_CONSUMER("fifthConsumer"), SIXTH_CONSUMER("sixthConsumer"),
	SEVENTH_CONSUMER("seventhConsumer"), EIGHTH_CONSUMER("eighthConsumer"), NINTH_CONSUMER("ninthConsumer"),
	TENTH_CONSUMER("tenthConsumer");

	private String value;

	private ApplicantEnumerator(String s) {
		value = s;
	}

	public String getValue() {
		return value;
	}

	public static ApplicantEnumerator fromString(String text) {
		for (ApplicantEnumerator b : ApplicantEnumerator.values()) {
			if (b.value.equalsIgnoreCase(text)) {
				return b;
			}
		}
		throw new IllegalArgumentException("No constant with text " + text + " found");
	}
}
