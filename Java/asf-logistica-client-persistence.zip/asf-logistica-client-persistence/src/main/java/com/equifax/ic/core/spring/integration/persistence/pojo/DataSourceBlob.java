package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;

@Entity
@Table(name = "DATASOURCEBLOB")
public class DataSourceBlob {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    @SequenceGenerator(name = "SEQ", sequenceName = "DATASOURCEBLOB_SEQ", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "RESPONSE_BLOB")
    private byte[] responseBlob;

    @Column(name = "DATASOURCE_NAME")
    private String dataSourceName;

    @Column(name = "DATASOURCE_UUID")
    private String dataSourceUuid;


    @ManyToOne(cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_IGDATASOURCEACCESS", nullable = false)
    private IgPojo idIgDataSourceAccess;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public byte[] getResponseBlob() {
        return responseBlob;
    }

    public void setResponseBlob(byte[] responseBlob) {
        this.responseBlob = responseBlob;
    }

    public String getDataSourceName() {
        return dataSourceName;
    }

    public void setDataSourceName(String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }

    public String getDataSourceUuid() {
        return dataSourceUuid;
    }

    public void setDataSourceUuid(String dataSourceUuid) {
        this.dataSourceUuid = dataSourceUuid;
    }

    public IgPojo getIdIgDataSourceAccess() {
        return idIgDataSourceAccess;
    }

    public void setIdIgDataSourceAccess(IgPojo idIgDataSourceAccess) {
        this.idIgDataSourceAccess = idIgDataSourceAccess;
    }
}
