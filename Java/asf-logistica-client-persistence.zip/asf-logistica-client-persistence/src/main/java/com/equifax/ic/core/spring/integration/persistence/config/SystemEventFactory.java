package com.equifax.ic.core.spring.integration.persistence.config;

import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SystemEventFactory implements Factory{
	
	private List<SystemEvent> systemEventList = new ArrayList<>();
	
	public SystemEvent logSystemEvent(Date dateCreated, String description, Long duration, String uuid, String applicationIdentifier) {

		SystemEvent systemEvent = new SystemEvent();
		systemEvent.setDateCreated(dateCreated);
		systemEvent.setDescription(description);
		systemEvent.setDuration(duration);
		systemEvent.setUuid(uuid);
		systemEvent.setApplicantIdentifier(applicationIdentifier);
		addSystemEvent(systemEvent);

		return systemEvent;
	}

	@Override
	public List<SystemEvent> getList() {
		return systemEventList;
	}

	public void setSystemEventList(List<SystemEvent> systemEventList) {
		this.systemEventList = systemEventList;
	}

	private void addSystemEvent(SystemEvent systemEvent) {
		getList().add(systemEvent);
	}
}
