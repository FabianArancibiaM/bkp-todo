package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.HonduranConsumer;
import org.springframework.data.repository.CrudRepository;

public interface HonduranConsumerDao extends CrudRepository<HonduranConsumer, Long> {

}