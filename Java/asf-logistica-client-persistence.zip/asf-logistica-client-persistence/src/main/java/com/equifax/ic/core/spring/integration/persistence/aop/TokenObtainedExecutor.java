package com.equifax.ic.core.spring.integration.persistence.aop;

import com.equifax.ic.core.spring.integration.persistence.util.TokenObtained;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

import java.util.Map;

//@Aspect
public class TokenObtainedExecutor {
    //private static final Logger LOGGER = LoggerFactory.getLogger(TokenObtainedExecutor.class);

    //@Autowired
    TokenObtained tokenObtained;

    //@Around("execution(private org.springframework.http.ResponseEntity com.equifax.ic.core.spring.integration.persistence.controller.CustomTransactionController.executeOrchestrationExecution(String, Map<String, Object>)) && args(request, headers)")
    public ResponseEntity<Object> aroundExecuteOrchestrationExecution(ProceedingJoinPoint joinPoint, String request, Map<String, Object> headers) throws Throwable {
        return getObjectResponseEntity(joinPoint, headers);
    }

    private ResponseEntity<Object> getObjectResponseEntity(ProceedingJoinPoint joinPoint, Map<String, Object> headers) throws Throwable {
        tokenObtained.getToken(headers);
        return (ResponseEntity<Object>) joinPoint.proceed();
    }
}
