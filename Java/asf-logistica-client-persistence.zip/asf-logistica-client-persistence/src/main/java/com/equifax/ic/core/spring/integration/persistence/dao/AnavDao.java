package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.AnavPojo;
import org.springframework.data.repository.CrudRepository;


public interface AnavDao extends CrudRepository<AnavPojo, Long> {
}
