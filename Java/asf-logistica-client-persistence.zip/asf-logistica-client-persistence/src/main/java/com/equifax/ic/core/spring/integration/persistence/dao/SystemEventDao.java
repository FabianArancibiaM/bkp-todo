package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;
import org.springframework.data.repository.CrudRepository;

public interface SystemEventDao extends CrudRepository<SystemEvent, Long> {

    SystemEvent findByUuidAndDescription(String uuid, String description);

}
