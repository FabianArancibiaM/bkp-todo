package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;

@Entity
@Table(name = "CHILEANCONSUMER")
public class ChileanConsumer {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "CHILEANCONSUMER_SEQ", allocationSize = 1)
	private Long id;

	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ID_CONSUMER")
	private Consumer consumer;

	@Column(name = "CHILEANRUT")
	private String chileanRut;

	@Column(name = "CHILEANSERIALNUMBER")
	private String chileanSerialNumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Consumer getConsumer() {
		return consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

	public String getChileanRut() {
		return chileanRut;
	}

	public void setChileanRut(String chileanRut) {
		this.chileanRut = chileanRut;
	}

	public String getChileanSerialNumber() {
		return chileanSerialNumber;
	}

	public void setChileanSerialNumber(String chileanSerialNumber) {
		this.chileanSerialNumber = chileanSerialNumber;
	}

}