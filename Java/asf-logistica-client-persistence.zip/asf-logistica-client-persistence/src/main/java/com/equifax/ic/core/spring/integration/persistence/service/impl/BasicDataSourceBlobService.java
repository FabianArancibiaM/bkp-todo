package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.DataSourceBlobDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.DataSourceBlob;
import com.equifax.ic.core.spring.integration.persistence.service.DataSourceBlobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.List;

@Service
public class BasicDataSourceBlobService implements DataSourceBlobService {

    @Autowired
    private DataSourceBlobDao dataSourceBlobDao;

    @Override
    @Transactional(readOnly = true)
    public List<DataSourceBlob> getAllDataSourceBlob() {
        return (List<DataSourceBlob>) dataSourceBlobDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public DataSourceBlob getDataSourceBlobById(Long id) {
        return dataSourceBlobDao.findOne(id);
    }

    @Override
    @Transactional
    public void insertDataSourceBlob(DataSourceBlob dataSourceBlob) {
        dataSourceBlobDao.save(dataSourceBlob);
    }

    @Override
    @Transactional
    public DataSourceBlob updateDataSourceBlob(DataSourceBlob dataSourceBlob) throws IOException {
        if(getDataSourceBlobById(dataSourceBlob.getId()) == null){
            throw new IOException("DataSourceBlob does not exist");
        }
        return dataSourceBlobDao.save(dataSourceBlob);
    }
}
