package com.equifax.ic.core.spring.integration.persistence.handler;

import com.equifax.ic.core.clientapi.rest.exception.OrchestrationExecutionExceptionHandler;
import com.equifax.ic.core.spring.integration.persistence.exception.InternalErrorException;
import com.equifax.ic.core.spring.integration.persistence.exception.UnauthorizedException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class CustomExceptionHandler extends OrchestrationExecutionExceptionHandler {
    public CustomExceptionHandler() {
        //Constructor
    }

    @ExceptionHandler({UnauthorizedException.class})
    public ResponseEntity<Object> handleUnauthorizedExceptionHandler(Exception e, WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        return this.handleExceptionInternal(e, e.getMessage(), headers, HttpStatus.UNAUTHORIZED, request);
    }

    @ExceptionHandler({InternalErrorException.class})
    public ResponseEntity<Object> handleInternalErrorExceptionHandler(Exception e, WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        return this.handleExceptionInternal(e, e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }
}
