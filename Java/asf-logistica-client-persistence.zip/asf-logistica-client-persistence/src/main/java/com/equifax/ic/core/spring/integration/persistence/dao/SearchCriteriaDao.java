package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.SearchCriteria;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface SearchCriteriaDao extends CrudRepository<SearchCriteria, Long>, JpaSpecificationExecutor<SearchCriteria> {
}
