package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;

import java.util.List;

public interface MessagesService extends FactoryService {

	public List<Messages> getAllMessages();

	public Messages getMessageById(final Long id);
	
	public void saveNewMessage(Messages message);
	
	public Messages updateMessage(Messages message) throws Exception;
	
}
