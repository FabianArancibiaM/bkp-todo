package com.equifax.ic.core.spring.integration.persistence.aop;

import com.equifax.ic.core.spring.integration.persistence.component.FactoriesPopulator;
import com.equifax.ic.core.spring.integration.persistence.component.MicroServicesIdCollector;
import com.equifax.ic.core.spring.integration.persistence.util.PersistenceDomain;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.history.MessageHistory;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;


/**
 * <p>
 * This class is responsible for collecting all the events in the Client Implementation that will be persist later. Aspect is used to do that.
 * </p>
 * 
 * @author Alan Sandoval axs831
 * @since 10-08-2018 1.0
 */

@Aspect
public class ServiceActivatorInterceptor {
	
	@Autowired
	private FactoriesPopulator factoriesPopulator;

	@Autowired
	private MicroServicesIdCollector microServicesIdCollector;

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceActivatorInterceptor.class);
	
	private static final String HISTORY = "history";

	@Before("execution(public Map<String, Object> com.equifax.ic.core.clienteip.service.impl.BasicRestServiceActivator.invoke(Map<String, Object>, Map<String, Object>)) && args(payload, headers)")
	public void beforeMicroServiceExecution(Map<String, Object> payload, Map<String, Object> headers) throws Exception {	

		LOGGER.info("Method 'invoke' of 'BasicRestServiceActivator' class intercepted with Aspect, BEFORE its execution");
		factoriesPopulator.systemEventsBuilder(payload, headers, parametersBuilder(headers, PersistenceDomain.BEFORE.toString()));
	}
	
	@AfterReturning("execution(public Map<String, Object> com.equifax.ic.core.clienteip.service.impl.BasicRestServiceActivator.invoke(Map<String, Object>, Map<String, Object>)) && args(payload, headers)")
	public void afterMicroServiceExecution(Map<String, Object> payload, Map<String, Object> headers) throws Exception {

		LOGGER.info("Method 'invoke' of 'BasicRestServiceActivator' class intercepted with Aspect, AFTER its execution");
		factoriesPopulator.systemEventsBuilder(payload, headers, parametersBuilder(headers, PersistenceDomain.AFTER.toString()));
	}
	
	private Map<String, Object> parametersBuilder(Map<String, Object> headers, String executionTime) throws Exception {

		Map<String, Object> parametersMap = new HashMap<>();
		String currentServiceActivatorId = getCurrentServiceActivatorId(headers);
		String microServiceName = microServicesIdCollector.getServiceName(currentServiceActivatorId);

		Assert.notNull(microServiceName, String.format("Service Activator %s was not found in any application context. ", currentServiceActivatorId));

		parametersMap.put("microServiceName", microServiceName);
		parametersMap.put("serviceActivatorId", currentServiceActivatorId);
		parametersMap.put("executionTime", executionTime);
		parametersMap.put("persistenceFactories", headers.get("persistenceFactories"));
		
		return parametersMap;
	}

	private String getCurrentServiceActivatorId(Map<String, Object> headers) throws Exception {
		if (headers.containsKey(HISTORY) && headers.get(HISTORY) != null) {
			MessageHistory messageHistory = (MessageHistory) headers.get(HISTORY);
			return messageHistory.get(messageHistory.size() - 1).getProperty("name");
		} else {
			throw new Exception("Missing property in headers. Please, add the line '<ns3:message-history/>' "
					+ "to every XML orchestration configuration file to enable persistence correctly");
		}
	}

}
