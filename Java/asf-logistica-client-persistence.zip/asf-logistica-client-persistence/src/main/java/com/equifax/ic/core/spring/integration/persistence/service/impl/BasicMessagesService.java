package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.MessagesDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import com.equifax.ic.core.spring.integration.persistence.service.MessagesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class BasicMessagesService implements MessagesService{

	@Autowired
	private MessagesDao messagesDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Messages> getAllMessages() {
		return (List<Messages>) messagesDao.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Messages getMessageById(Long id) {
		return messagesDao.findOne(id);
	}

	@Override
	@Transactional
	public void saveNewMessage(Messages message) {
		messagesDao.save(message);
	}

	@Override
	@Transactional
	public Messages updateMessage(Messages message) throws Exception {
		if(getMessageById(message.getId()) == null) {
			throw new Exception("The message does not exist");
		}
		return messagesDao.save(message);
	}
	
	@Override
	@Transactional
	public void insertList(List<?> messagesList) {
		for (Object message : messagesList)
			messagesDao.save((Messages) message);
	}

}
