package com.equifax.ic.core.spring.integration.persistence.component;

import com.equifax.ic.core.spring.integration.persistence.util.PersistenceDomain;
import com.equifax.ic.product.clientconfig.domain.impl.ServiceActivator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static com.equifax.ic.core.clientapi.domain.utils.Constants.*;
import static java.lang.String.format;

public class MicroServicesIdCollector {

    @Autowired
    private ApplicationContext appContext;

    private static final Logger LOGGER = LoggerFactory.getLogger(MicroServicesIdCollector.class);

    private static final String IG_ID = "insightgateway";
    private static final String ANAV_ID = "anav-engine";
    private static final String SMARTS_ID = "rules-editor-connector";
    private static final String MIT_ID = "mit-model-execution-server-rest";

    private Map<String, Object> microServicesMap = new HashMap<>();

    public Map<String, Object> getMicroServicesMap() {
        return microServicesMap;
    }

    @SuppressWarnings("unchecked")
    public String getServiceName(String serviceActivatorId) {

        for (Map.Entry<String, Object> currentMicroServiceListEntry : microServicesMap.entrySet()) {
            Set<String> currentMicroServiceList = (Set<String>) currentMicroServiceListEntry.getValue();
            for(String id : currentMicroServiceList) {
                if(id.equals(serviceActivatorId)) {
                    return currentMicroServiceListEntry.getKey();
                }
            }
        }

        return null;
    }

    @PostConstruct
    private void microServicesMapBuilder() {

        Set<String> igServiceActivatorList = new HashSet<>();
        Set<String> anavServiceActivatorList = new HashSet<>();
        Set<String> mitServiceActivatorList = new HashSet<>();
        Set<String> smartsServiceActivatorList = new HashSet<>();

        microServicesMap.put(PersistenceDomain.IG.toString(), igServiceActivatorList);
        microServicesMap.put(PersistenceDomain.ANAV.toString(), anavServiceActivatorList);
        microServicesMap.put(PersistenceDomain.MIT.toString(), mitServiceActivatorList);
        microServicesMap.put(PersistenceDomain.SMARTS.toString(), smartsServiceActivatorList);

        try {
            Map<String, ApplicationContext> appContextsMap = getApplicationContextsMap();

            for (Map.Entry<String, ApplicationContext> appContextMapEntry : appContextsMap.entrySet()) {
                ApplicationContext currentAppContext = appContextMapEntry.getValue();

                Map<String, ServiceActivator> servicesActivatorsMap = currentAppContext.getBeansOfType(ServiceActivator.class);

                for (Map.Entry<String, ServiceActivator> servicesActivatorsMapEntry : servicesActivatorsMap.entrySet()) {
                    ServiceActivator currentServiceActivator = servicesActivatorsMapEntry.getValue();
                    String microServiceId = currentServiceActivator.getApplicationId();

                    if (IG_ID.equals(microServiceId)) {
                        igServiceActivatorList.add(currentServiceActivator.getConfigurationElementId());
                    } else if (ANAV_ID.equals(microServiceId)) {
                        anavServiceActivatorList.add(currentServiceActivator.getConfigurationElementId());
                    } else if (SMARTS_ID.equals(microServiceId)) {
                        smartsServiceActivatorList.add(currentServiceActivator.getConfigurationElementId());
                    } else if (MIT_ID.equals(microServiceId)) {
                        mitServiceActivatorList.add(currentServiceActivator.getConfigurationElementId());
                    }
                }

            }

        } catch (Exception e) {
            LOGGER.error("Failed to fill the MicroServicesMap from the application context", e);
        }
    }

    @SuppressWarnings("unchecked")
    protected Map<String, ApplicationContext> getApplicationContextsMap() throws Exception {

        try {
            Object orchestrationContextMapLoader = appContext.getBean("orchestrationContextMapLoader");
            // Using reflection to invoke the method and avoid importing the package client-service and a circular dependency between packages
            Method method = orchestrationContextMapLoader.getClass().getDeclaredMethod("getOrchestrationContexts");
            return (Map<String, ApplicationContext>) method.invoke(orchestrationContextMapLoader);

        } catch (Exception e) {
            LOGGER.error("There was a problem obtaining the ApplicationContextsMap from OrchestrationContextMapLoader bean", e);
            throw new Exception("Error obtaining the ApplicationContextsMap from OrchestrationContextMapLoader bean");
        }
    }

    private String getContextKey(Map<String, Object> transactionContext) {
        return format("%s_%s_%s_%s",
                extractProperty(transactionContext, ORGANIZATION_KEY),
                extractProperty(transactionContext, CONFIGURATION_KEY),
                extractProperty(transactionContext, BASELINE_KEY),
                extractProperty(transactionContext, ORCHESTRATION_KEY));
    }

    private String extractProperty(Map<String, Object> transactionContext, String key) {
        Assert.notNull(transactionContext.get(key), format("%s on transaction context is required", key));
        return (String) transactionContext.get(key);
    }
}
