package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.DataSourceBlob;

import java.io.IOException;
import java.util.List;

public interface DataSourceBlobService {

    List<DataSourceBlob> getAllDataSourceBlob();

    DataSourceBlob getDataSourceBlobById(final Long id);

    void insertDataSourceBlob(DataSourceBlob dataSourceBlob);

    DataSourceBlob updateDataSourceBlob(DataSourceBlob dataSourceBlob) throws IOException;
}
