package com.equifax.ic.core.spring.integration.persistence.search;

import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;

public interface SearchTransactionService {
    Object findTransactionByTransactionId(JsonNode request) throws IOException;
}
