package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;

import java.util.List;

public interface SystemEventService extends FactoryService{

	public List<SystemEvent> getAllSystemEvents();

	public SystemEvent getSystemEventById(final Long id);
	
	public void saveNewSystemEvent(SystemEvent systemEvent);
	
	public SystemEvent updateSystemEvent(SystemEvent systemEvent) throws Exception;

	public SystemEvent findByUuidAndDescription(String uuid, String description);
}
