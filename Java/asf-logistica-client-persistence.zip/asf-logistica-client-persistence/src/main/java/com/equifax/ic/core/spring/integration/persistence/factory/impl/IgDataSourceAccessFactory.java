package com.equifax.ic.core.spring.integration.persistence.factory.impl;

import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.pojo.DataSourceBlob;
import com.equifax.ic.core.spring.integration.persistence.pojo.IgPojo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class IgDataSourceAccessFactory implements Factory {

    private List<IgPojo> igPojoList = new ArrayList<>();

    public void logIgDataSource(String transactionId, String orchestrationCode, String uuid, String applicantIdentifier, Set<DataSourceBlob> dataSourceBlobSet) {
        IgPojo igPojo = new IgPojo();
        igPojo.setTransactionId(transactionId);
        igPojo.setOrchestration(orchestrationCode);
        igPojo.setUuid(uuid);
        igPojo.setApplicantIdentifier(applicantIdentifier);
        igPojo.setDataSourceBlob(dataSourceBlobSet);
        
        if(!dataSourceBlobSet.isEmpty()) {
        	for(DataSourceBlob blob : dataSourceBlobSet) {
        		blob.setIdIgDataSourceAccess(igPojo);
        	}
        }
        addIgDataSourceAccess(igPojo);
    }

    @Override
    public List<IgPojo> getList() {
        return igPojoList;
    }

    public void setIgList(List<IgPojo> igPojoList) {
        this.igPojoList = igPojoList;
    }

    private void addIgDataSourceAccess(IgPojo igPojo){
        getList().add(igPojo);
    }

}
