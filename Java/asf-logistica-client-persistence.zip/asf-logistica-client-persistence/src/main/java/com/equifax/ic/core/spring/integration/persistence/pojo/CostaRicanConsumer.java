package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;

@Entity
@Table(name = "COSTARICANCONSUMER")
public class CostaRicanConsumer {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "COSTARICANCONSUMER_SEQ")
	private Long id;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ID_CONSUMER")
	private Consumer consumer;
	
	@Column(name = "IDENTIFICATION_NUMBER")
	private String identificationNumber;
	
	public Long getId() {
		return id;
	}

	public String getIdentificationNumber() {
		return identificationNumber;
	}

	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Consumer getConsumer() {
		return consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}
	
}
