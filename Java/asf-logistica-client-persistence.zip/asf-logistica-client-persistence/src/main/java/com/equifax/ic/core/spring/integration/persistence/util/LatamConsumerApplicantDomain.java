package com.equifax.ic.core.spring.integration.persistence.util;

public enum LatamConsumerApplicantDomain {

	PERUVIAN_TYPE("peruIdType"), PERUVIAN_NUMBER("peruIdNumber"), CHILEAN_RUT("chileanRut"),
	CHILEAN_SERIAL_NUMBER("chileanSerialNumber"), ARGENTINIAN_DNI("dni"), ARGENTINIAN_REFERENCE("reference"),
	CHILE_KEY("cl"), PERU_KEY("per"), ARGENTINA_KEY("arg"), URUGUAYAN_DOCUMENTO("documento"),
	URUGUAYAN_FICHA("ficha"), URUGUAY_KEY("ury"),
	COSTARICAN_KEY("cr"), HONDURAN_KEY("hn"), SALVADORAN_KEY("sv"),
	COSTARICAN_ID(""),
	HONDURAN_ID(""),
	SALVADORAN_ID(""),
	TRANSACTION_CONTEXT("transactionContext"), ORCHESTRATION("orchestration"), COUNTRY("country"),
	ECUADOR_KEY("ecu"),
	ECUADORIAN_DOCUMENTTYPE("tipoDocumento"),
	ECUADORIAN_DOCUMENTNUMBER("numeroDocumento");

	private String value;

	private LatamConsumerApplicantDomain(String s) {
		value = s;
	}

	public String getValue() {
		if (this.value.isEmpty()){
			return "identificationNumber";
		}
		return value;
	}
}
