package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.Transaction;

import java.io.IOException;

public interface TransactionService {
	
	void insertTransaction(Transaction transaction);

	Transaction getTransactionById(final Long id);

	Transaction findTransactionById(String transactionId);

	Transaction updateTransaction(Transaction transaction) throws IOException;
}
