package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.HonduranConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.HonduranConsumer;
import com.equifax.ic.core.spring.integration.persistence.service.HonduranConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class HonduranConsumerServiceImpl implements HonduranConsumerService {
	
	@Autowired
	private HonduranConsumerDao honduranConsumerDao;

	@Override
	@Transactional
	public void insertHonduranConsumer(HonduranConsumer consumer) {
		honduranConsumerDao.save(consumer);

	}

}