package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.HonduranConsumer;

public interface HonduranConsumerService {
	
	void insertHonduranConsumer(HonduranConsumer consumer);

}