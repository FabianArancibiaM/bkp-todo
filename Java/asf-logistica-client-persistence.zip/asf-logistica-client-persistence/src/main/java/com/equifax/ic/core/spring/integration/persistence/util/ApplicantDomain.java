package com.equifax.ic.core.spring.integration.persistence.util;

public enum ApplicantDomain {

	APPLICANTS("applicants"), GENDER("gender"), PERSONAL_INFORMATION("personalInformation"), ADDRESSES("addresses"), 
	NAME("name"), LASTNAME("lastName"), IDENTIFIER("identifier"), FIRSTNAME("firstName"), ADDITIONALATTRIBUTE("additionalAttribute"), 
	INITIAL_REQUEST_KEY("INITIAL_REQUEST"), TRANSACTION_ID_KEY("transactionId"), ERROR("error"), COMPLETED("completed"), 
	INPROGRESS("inprogress"), CUSTOMER_REFERENCE_IDENTIFIER("customerReferenceIdentifier"), CLIENTIMPLEMENTATIONUUID("clientImplementationUUID"),
	CLIENTIMPLEMENTATIONDATECREATED("clientImplementationDateCreated"), CLIENTIMPLEMENTATIONSTATUS("clientImplementationStatus"),
	CLIENTIMPLEMENTATIONDATEMODIFIED("clientImplementationDateModified"), STATUS("status"), DATECREATED("dateCreated"), DATEMODIFIED("dateModified"),
	SERVICE("service"), USERNAME("userName"), SMARTS("smarts"), IG("ig"), MIT("mit");

	private String value;

	private ApplicantDomain(String s) {
		value = s;
	}

	public String getValue() {
		return value;
	}
}