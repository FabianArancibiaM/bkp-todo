package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.IgDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.IgPojo;
import com.equifax.ic.core.spring.integration.persistence.service.IgService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.Date;
import java.util.List;

@Service
public class BasicIgService implements IgService {
    private static final Logger LOGGER = LoggerFactory.getLogger(BasicIgService.class);
    @Autowired
    private IgDao igDao;

    @Override
    @Transactional(readOnly = true)
    public List<IgPojo> getAllIg() {
        return (List<IgPojo>) igDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public IgPojo getIgById(Long id) {
        return igDao.findOne(id);
    }

    @Override
    @Transactional
    public void insertIg(IgPojo ig) {
        igDao.save(ig);
    }

    @Override
    @Transactional
    public IgPojo updateIg(IgPojo ig) throws IOException {
        if(getIgById(ig.getId()) == null){
            throw new IOException("Ig does not exist");
        }
        return igDao.save(ig);
    }

    @Override
    public Object[] getTransactionId(String transactionId) throws IOException {
        try {
            List<Object[]> listObj = igDao.findTransaction(transactionId);
            if (!listObj.isEmpty()){
                return (Object[])listObj.get(0);
            }
            return null;
        }catch (Exception ex){
            LOGGER.error(ex.getMessage());
            throw new IOException("Error when searching for the transaction");
        }
    }
    @Override
	public void insertList(List<?> igDataSourceList) {
		for (Object igDataSource : igDataSourceList)
			igDao.save((IgPojo) igDataSource);
		
	}
}
