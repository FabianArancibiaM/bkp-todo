package com.equifax.ic.core.spring.integration.persistence.service;

import java.util.List;

/**
 * <p>
 * </p>
 * 
 * @author Alan Sandoval axs831
 * @since 16-08-2018 1.0
 */
public interface FactoryService {

	void insertList(List<?> list);
	
}
