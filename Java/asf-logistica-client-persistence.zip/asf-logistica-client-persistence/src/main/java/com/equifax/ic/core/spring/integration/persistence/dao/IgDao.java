package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.IgPojo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Date;
import java.util.List;

public interface IgDao extends CrudRepository<IgPojo, Long> {

    @Query(value = "select p.transactionId, m.messageBlob " +
            "from IgPojo p, SystemEvent s, Messages m,  Transaction t, SmartsPojo sm, Consumer co " +
            "where p.uuid=s.uuid and p.transactionId= ?1 and m.eventType='CI-RESPONSE' " +
            "and s.description='Transaction completion' and t.uuid=s.uuid and sm.uuid=s.uuid and co.uuid=s.uuid " +
            "and m.idSystemEvent=s.id")
    List<Object[]> findTransaction(String transactionId);
}
