package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.ArgentinianConsumer;

public interface ArgentinianConsumerService {

	void insertArgentinianConsumer(ArgentinianConsumer argentinianConsumer);

}
