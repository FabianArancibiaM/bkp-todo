package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.SearchCriteria;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import java.util.List;

public interface SearchCriteriaService {
    List<SearchCriteria> findByCriteria(JsonNode request) throws IOException;
}
