package com.equifax.ic.core.spring.integration.persistence.config;

import com.equifax.ic.core.spring.integration.persistence.aop.ServiceActivatorInterceptor;
import com.equifax.ic.core.spring.integration.persistence.aop.TokenObtainedExecutor;
import com.equifax.ic.core.spring.integration.persistence.aop.TransactionPersistenceExecutor;
import com.equifax.ic.core.spring.integration.persistence.component.MicroServicesIdCollector;
import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.factory.impl.*;
import com.equifax.ic.core.spring.integration.persistence.service.*;
import org.aspectj.lang.Aspects;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.client.RestTemplate;

import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
@ComponentScan("com.equifax.ic.core.spring.integration.persistence")
@EntityScan(basePackages = "com.equifax.ic.core.spring.integration.persistence.pojo")
@EnableJpaRepositories(basePackages = "com.equifax.ic.core.spring.integration.persistence.dao")
@EnableAspectJAutoProxy
public class PersistenceConfiguration {

	@Bean
	public Map<Class<? extends Factory>, FactoryService> factoriesContainer(SystemEventService systemEventService, MessagesService messagesService,
                                                                            IgService igService, MitService mitService, SmartsService smartsService, AnavService anavService) {

		Map<Class<? extends Factory>, FactoryService> factoriesMap = new LinkedHashMap<>();

		// Include in this list every factory class you want to register in PersistenceFactories bean
		factoriesMap.put(SystemEventFactory.class, systemEventService);
		factoriesMap.put(MessagesFactory.class, messagesService);
		factoriesMap.put(IgDataSourceAccessFactory.class, igService);
		factoriesMap.put(AnavAttributeAccessFactory.class, anavService);
		factoriesMap.put(MitScoringFactory.class, mitService);
		factoriesMap.put(SmartsDecisioningFactory.class, smartsService);
		return factoriesMap;
	}
	
	@Bean
	public ServiceActivatorInterceptor serviceActivatorInterceptor() {
		return Aspects.aspectOf(ServiceActivatorInterceptor.class);
	}

	@Bean
	public TransactionPersistenceExecutor transactionPersistenceExecutor() {
		return Aspects.aspectOf(TransactionPersistenceExecutor.class);
	}

	@Bean
	public MicroServicesIdCollector microServicesIdCollector() {
		return new MicroServicesIdCollector();
	}

	//@Bean
	public TokenObtainedExecutor decisionPortalExecutor() {
		return Aspects.aspectOf(TokenObtainedExecutor.class);
	}

	@Bean("restTemplateCustom")
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Value("${client.orchestration.ASFLOGISTICA.xmlParameters.components.gateway.id}")
	private String gatewayPath;

	@Bean
	public String gatewayPath(){
		return this.gatewayPath;
	}
}
