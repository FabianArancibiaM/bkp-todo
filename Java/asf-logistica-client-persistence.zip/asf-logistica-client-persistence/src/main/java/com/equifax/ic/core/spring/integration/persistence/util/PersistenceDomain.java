package com.equifax.ic.core.spring.integration.persistence.util;

public enum PersistenceDomain {

	IG, ANAV, MIT, SMARTS, BEFORE, AFTER

}
