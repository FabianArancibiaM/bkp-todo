package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.ChileanConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.ChileanConsumer;
import com.equifax.ic.core.spring.integration.persistence.service.ChileanConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ChileanConsumerServiceImpl implements ChileanConsumerService {

	@Autowired
	private ChileanConsumerDao chileanConsumerDao;
	
	@Override
	@Transactional
	public void insertChileanConsumer(ChileanConsumer chileanConsumer) {

		chileanConsumerDao.save(chileanConsumer);
		
	}

}
