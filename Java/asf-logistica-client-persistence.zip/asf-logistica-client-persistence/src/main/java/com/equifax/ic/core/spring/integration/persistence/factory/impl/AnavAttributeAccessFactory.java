package com.equifax.ic.core.spring.integration.persistence.factory.impl;

import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.pojo.AnavPojo;

import java.util.ArrayList;
import java.util.List;

public class AnavAttributeAccessFactory implements Factory {

    private List<AnavPojo> anavPojoList = new ArrayList<>();

    public void logAnavAttributeAccess(String projectName, String baseline, String uuid, String applicantIdentifier) {
        AnavPojo anavPojo = new AnavPojo();
        anavPojo.setProjectName(projectName);
        anavPojo.setBaseline(baseline);
        anavPojo.setUuid(uuid);
        anavPojo.setApplicantIdentifier(applicantIdentifier);
        addAnavAttributeAccess(anavPojo);
    }

    @Override
    public List<AnavPojo> getList() {
        return anavPojoList;
    }

    public void setAnavList(List<AnavPojo> anavPojoList) {
        this.anavPojoList = anavPojoList;
    }

    private void addAnavAttributeAccess(AnavPojo anavPojo){
        getList().add(anavPojo);
    }
}
