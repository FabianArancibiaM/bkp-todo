package com.equifax.ic.core.spring.integration.persistence.factory;

import java.util.List;

public interface Factory {
    List getList();
}
