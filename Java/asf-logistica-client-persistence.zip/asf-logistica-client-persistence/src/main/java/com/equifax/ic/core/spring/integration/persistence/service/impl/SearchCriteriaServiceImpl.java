package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.SearchCriteriaDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.CriteriaBody;
import com.equifax.ic.core.spring.integration.persistence.pojo.SearchCriteria;
import com.equifax.ic.core.spring.integration.persistence.search.impl.SearchTransactionServiceImpl;
import com.equifax.ic.core.spring.integration.persistence.service.SearchCriteriaService;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantDomain;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantEnumerator;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Component
public class SearchCriteriaServiceImpl implements SearchCriteriaService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SearchTransactionServiceImpl.class);

    @Autowired
    private SearchCriteriaDao criteriaDao;

    @Override
    public List<SearchCriteria> findByCriteria(JsonNode request) throws IOException {
        JsonNode filtro = request
                .get(ApplicantDomain.APPLICANTS.getValue())
                .get(ApplicantEnumerator.PRIMARY_CONSUMER.getValue())
                .get(ApplicantDomain.PERSONAL_INFORMATION.getValue());
        try{
            String transactionId = "";
            if (filtro.get("transactionId")!=null && !filtro.get("transactionId").textValue().isEmpty()){
                transactionId = filtro.get("transactionId").textValue();
            }
            String chileanRut = "";
            if (filtro.get("chileanRut")!=null && !filtro.get("chileanRut").textValue().isEmpty()){
                chileanRut = filtro.get("chileanRut").textValue();
            }
            String decision = "";
            if (filtro.get("decision")!=null && !filtro.get("decision").textValue().isEmpty()){
                decision = filtro.get("decision").textValue();
            }
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
            Date desde=null;
            if (filtro.get("fromDate")!=null && isValidDate(filtro.get("fromDate").textValue())){
                desde = dateFormat.parse(filtro.get("fromDate").textValue()+" 00:00:00");
            }
            Date hasta = null;
            if (filtro.get("untilDate")!=null && isValidDate(filtro.get("untilDate").textValue())){
                hasta = dateFormat.parse(filtro.get("untilDate").textValue()+" 23:59:59");
            }
            CriteriaBody criteriaBody = new CriteriaBody(desde,hasta,chileanRut,decision,transactionId);
            return criteriaDao.findAll((root, query, criteriaBuilder) -> getPredicate(criteriaBody,
                    root, criteriaBuilder));
        }catch (Exception e){
            LOGGER.error(e.getMessage());
            throw new IOException(e.getMessage());
        }
    }

    private boolean isValidDate(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        boolean status = true;

        try {
            dateFormat.parse(date);
        } catch (ParseException e) {
            status = false;
        }
        return status;
    }

    @Transactional("searchTransactionManager")


    public Predicate getPredicate(CriteriaBody criteriaBody, Root<SearchCriteria> root, CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();

        if (criteriaBody.getTransactionId() != null && !criteriaBody.getTransactionId().isEmpty()) {
            predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("transactionId"), criteriaBody.getTransactionId())));
        }

        if (criteriaBody.getDecision() != null && criteriaBody.getDecision().length() > 0) {
            predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("decision"), criteriaBody.getDecision())));
        }
        Calendar calendar = Calendar.getInstance();
        if (criteriaBody.getDesde() != null && criteriaBody.getHasta() != null) {
            predicates.add(criteriaBuilder.and(criteriaBuilder.between(root.get("dateCreated"), criteriaBody.getDesde(), criteriaBody.getHasta())));
        }else if(criteriaBody.getDesde() != null){
            calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR)+1);
            calendar.set(Calendar.HOUR, 23);
            calendar.set(Calendar.MINUTE, 59);
            calendar.set(Calendar.SECOND, 59);
            predicates.add(criteriaBuilder.and(criteriaBuilder.between(root.get("dateCreated"), criteriaBody.getDesde(), calendar.getTime())));
        }else if(criteriaBody.getHasta() != null){
            calendar.set(Calendar.YEAR, 1900);
            predicates.add(criteriaBuilder.and(criteriaBuilder.between(root.get("dateCreated"), calendar.getTime(),  criteriaBody.getHasta())));
        }

        if (criteriaBody.getRut() != null && criteriaBody.getRut().length() > 0) {
            predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("chileanRut"), criteriaBody.getRut())));
        }

        return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
    }
}
