package com.equifax.ic.core.spring.integration.persistence.factory;

import com.equifax.ic.core.spring.integration.persistence.service.FactoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;


/**
 * <p>
 * This class will store all factory classes in the Client Implementation
 * </p>
 * 
 * @author Alan Sandoval axs831
 * @since 14-08-2018 1.0
 */

public class PersistenceFactories {

	private static final Logger LOGGER = LoggerFactory.getLogger(PersistenceFactories.class);
	
	private Map<Factory, FactoryService> factoriesMap;

	public PersistenceFactories(Map<Class<? extends Factory>, FactoryService> factoriesMap) throws InstantiationException, IllegalAccessException {

		this.factoriesMap = createFactoryInstances(factoriesMap);
	}

	private Map<Factory, FactoryService> createFactoryInstances(Map<Class<? extends Factory>, FactoryService> factoriesMap) throws IllegalAccessException, InstantiationException {
		Map<Factory, FactoryService> finalFactoriesMap = new LinkedHashMap<>();
		for (Map.Entry<Class<? extends Factory>, FactoryService> entry : factoriesMap.entrySet()) {
			finalFactoriesMap.put(entry.getKey().newInstance(), entry.getValue());
		}
		return finalFactoriesMap;
	}



	
	public Map<Factory, FactoryService> getFactoriesMap(){
		return factoriesMap;
	}
	
	public Factory getFactory(Class<?> basicFactoryClass) {
		for (Map.Entry<Factory, FactoryService> factoryEntry : factoriesMap.entrySet()){
			if (factoryEntry.getKey().getClass().equals(basicFactoryClass)){
				return factoryEntry.getKey();
			}
		}
		LOGGER.warn("Factory '{}' is not registered in PersistenceFactories bean. Returning null...", basicFactoryClass);
		return null;
	}
	
	public void flushFactories(){
		LOGGER.info("Flushing factories...");
		try {
			for (Map.Entry<Factory, FactoryService> factoryEntry : factoriesMap.entrySet()){
				Factory currentFactory = factoryEntry.getKey();
				if (!currentFactory.getList().isEmpty()){
					
					//LOGGER.info("Flushing {}...", currentFactory.getClass().getSimpleName());
					
					factoryEntry.getValue().insertList(currentFactory.getList());
					
					//LOGGER.info("{} flushing completed", currentFactory.getClass().getSimpleName());
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error flushing factories. Please, see logs to find the specific error", e);
		}
		
		LOGGER.info("Factories flushing completed sucessfully");
	}
}
