package com.equifax.ic.core.spring.integration.persistence.pojo;

import java.util.Date;

public class CriteriaBody {
    private Date desde;
    private Date hasta;
    private String rut;
    private String decision;
    private String transactionId;

    public CriteriaBody(final Date desde, final Date hasta, final String rut,
                        final String decision, final String transactionId) {
        this.desde = desde;
        this.hasta = hasta;
        this.rut = rut;
        this.decision = decision;
        this.transactionId = transactionId;
    }

    public Date getDesde() {
        return desde;
    }

    public Date getHasta() {
        return hasta;
    }

    public String getRut() {
        return rut;
    }

    public String getDecision() {
        return decision;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public static class CriteriaBodyBuilder{
        private Date desde;
        private Date hasta;
        private String rut;
        private String decision;
        private String transactionId;

        public CriteriaBodyBuilder() {
        }

        public CriteriaBodyBuilder desde(Date desde) {
            this.desde = desde;
            return this;
        }

        public CriteriaBodyBuilder hasta(Date hasta) {
            this.hasta = hasta;
            return this;
        }

        public CriteriaBodyBuilder rut(String rut) {
            this.rut = rut;
            return this;
        }

        public CriteriaBodyBuilder decision(String decision) {
            this.decision = decision;
            return this;
        }

        public CriteriaBodyBuilder transactionId(String transactionId) {
            this.transactionId = transactionId;
            return this;
        }
        public CriteriaBody createCriteriaBody() {
            return new CriteriaBody(
                    desde,
                    hasta,
                    rut,
                    decision,
                    transactionId);
        }
    }
}
