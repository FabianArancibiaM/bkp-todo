package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.ArgentinianConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.ArgentinianConsumer;
import com.equifax.ic.core.spring.integration.persistence.service.ArgentinianConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ArgentinianConsumerServiceImpl implements ArgentinianConsumerService {

	@Autowired
	private ArgentinianConsumerDao argentinianConsumerDao;
	
	@Override
	@Transactional
	public void insertArgentinianConsumer(ArgentinianConsumer argentinianConsumer) {
		
		argentinianConsumerDao.save(argentinianConsumer);
	
	}

}
