package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;

@Entity
@Table(name = "MESSAGES")
public class Messages {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "MESSAGES_SEQ", allocationSize = 1)
	@Column(name = "ID")
	private Long id;
	
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(name = "MESSAGEBLOB")
	private byte[] messageBlob;
	
	@Column(name = "EVENTTYPE")
	private String eventType;
	
	@Column(name = "ID_SYSTEMEVENT")
	private Long idSystemEvent;
	
	@Transient
	private SystemEvent systemEvent;

	public SystemEvent getSystemEvent() {
		return systemEvent;
	}

	public void setSystemEvent(SystemEvent systemEvent) {
		this.systemEvent = systemEvent;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public byte[] getMessageBlob() {
		return messageBlob;
	}

	public void setMessageBlob(byte[] messageBlob) {
		this.messageBlob = messageBlob;
	}
	
	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public Long getIdSystemEvent() {
		return idSystemEvent;
	}

	public void setIdSystemEvent(Long idSystemEvent) {
		this.idSystemEvent = idSystemEvent;
	}
	
}
