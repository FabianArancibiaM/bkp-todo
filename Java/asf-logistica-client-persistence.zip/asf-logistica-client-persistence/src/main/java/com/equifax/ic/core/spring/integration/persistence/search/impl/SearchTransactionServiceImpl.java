package com.equifax.ic.core.spring.integration.persistence.search.impl;

import com.equifax.ic.core.spring.integration.persistence.search.SearchTransactionService;
import com.equifax.ic.core.spring.integration.persistence.service.IgService;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantDomain;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantEnumerator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class SearchTransactionServiceImpl implements SearchTransactionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SearchTransactionServiceImpl.class);

    @Autowired
    private IgService igService;

    @Override
    public Object findTransactionByTransactionId(JsonNode request) throws IOException {
        String transactionId = ((((
                request.get(ApplicantDomain.APPLICANTS.getValue()))
                .get(ApplicantEnumerator.PRIMARY_CONSUMER.getValue()))
                .get(ApplicantDomain.PERSONAL_INFORMATION.getValue()))
                .get(ApplicantDomain.TRANSACTION_ID_KEY.getValue())).asText();
        try{
            if (transactionId!=null && !transactionId.isEmpty()){
                Object[] obj = igService.getTransactionId(transactionId);
                if (obj!=null){
                    return  new ObjectMapper().readValue(new String((byte[]) obj[1]),JsonNode.class);
                }
            }
            return "No information";
        }catch (Exception ex){
            throw new IOException(ex.getMessage());
        }
    }


}
