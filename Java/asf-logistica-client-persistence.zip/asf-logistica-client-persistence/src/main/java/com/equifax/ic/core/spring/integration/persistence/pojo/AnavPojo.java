package com.equifax.ic.core.spring.integration.persistence.pojo;


import javax.persistence.*;

@Entity
@Table(name = "ANAVATTRIBUTEACCESS")
public class AnavPojo {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    @SequenceGenerator(name = "SEQ", sequenceName = "ANAVATTRIBUTEACCESS_SEQ", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "PROJECTNAME")
    private String projectName;

    @Column(name = "BASELINE")
    private String baseline;

    @Column(name = "UUID")
    private String uuid;

    @Column(name = "APPLICANTIDENTIFIER")
    private String applicantIdentifier;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getBaseline() {
        return baseline;
    }

    public void setBaseline(String baseline) {
        this.baseline = baseline;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getApplicantIdentifier() {
        return applicantIdentifier;
    }

    public void setApplicantIdentifier(String applicantIdentifier) {
        this.applicantIdentifier = applicantIdentifier;
    }
}