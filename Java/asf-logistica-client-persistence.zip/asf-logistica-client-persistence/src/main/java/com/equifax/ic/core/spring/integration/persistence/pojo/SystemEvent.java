package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "SYSTEMEVENT")
public class SystemEvent {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "SYSTEMEVENT_SEQ", allocationSize = 1)
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "CLASSPRODUCER")
	private String classProducer;
	
	@Column(name = "DATECREATED")
	private Date dateCreated;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "DURATION")
	private Long duration;
	
	@Column(name = "UUID")
	private String uuid;
	
	@Column(name = "APPLICANTIDENTIFIER")
	private String applicantIdentifier;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClassProducer() {
		return classProducer;
	}

	public void setClassProducer(String classProducer) {
		this.classProducer = classProducer;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getDuration() {
		return duration;
	}

	public void setDuration(Long duration) {
		this.duration = duration;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getApplicantIdentifier() {
		return applicantIdentifier;
	}

	public void setApplicantIdentifier(String applicantIdentifier) {
		this.applicantIdentifier = applicantIdentifier;
	}
	
}
