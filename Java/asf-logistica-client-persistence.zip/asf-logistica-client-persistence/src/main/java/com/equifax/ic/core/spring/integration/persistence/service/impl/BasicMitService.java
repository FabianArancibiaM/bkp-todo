package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.MitDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.MitPojo;
import com.equifax.ic.core.spring.integration.persistence.service.MitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.List;

@Service
public class BasicMitService implements MitService {

    @Autowired
    private MitDao mitDao;

    @Override
    @Transactional(readOnly = true)
    public List<MitPojo> getAllMit() {
        return (List<MitPojo>) mitDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public MitPojo getMitById(Long id) {
        return mitDao.findOne(id);
    }

    @Override
    @Transactional
    public void insertMit(MitPojo mit) {
        mitDao.save(mit);
    }

    @Override
    @Transactional
    public MitPojo updateMit(MitPojo mit) throws IOException {
        if(getMitById(mit.getId()) == null){
            throw new IOException("Mit does not exist");
        }
        return mitDao.save(mit);
    }

	@Override
	@Transactional
	public void insertList(List<?> mitScoringList) {
		for (Object mitScoring : mitScoringList)
			mitDao.save((MitPojo) mitScoring);
		
	}
    
    
}
