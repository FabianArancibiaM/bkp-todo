package com.equifax.ic.core.spring.integration.persistence.controller;

import com.equifax.ic.core.spring.integration.persistence.search.SearchTransactionService;
import com.equifax.ic.core.spring.integration.persistence.service.SearchCriteriaService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Map;

@RestController
@Api(
        value = "Search Execution",
        tags = {"SearchExecution"}
)
public class SearchController {

    @Autowired
    private SearchTransactionService searchTransactionService;

    @Autowired
    private SearchCriteriaService searchCriteriaService;

    @RequestMapping(
            value = {"/api/search/transactionSearch"},
            method = {RequestMethod.POST},
            consumes = {"application/vnd.com.equifax.backbone.service.orchestration.rest.request.v1+json"},
            produces = {"application/vnd.com.equifax.backbone.service.orchestration.rest.response.v1+json"}
    )
    @ApiOperation("Execute Transaction")
    @ApiResponses({@ApiResponse(
            code = 400,
            message = "Bad Request"
    ), @ApiResponse(
            code = 500,
            message = "Server Error"
    )})
    public ResponseEntity<Object> executeTransaction(@RequestBody(required = true) String request, @RequestHeader Map<String, Object> headers) throws IOException {
        try{
            JsonNode jRequest = (new ObjectMapper()).readTree(request);
            Object obj = searchTransactionService.findTransactionByTransactionId(jRequest);
            return new ResponseEntity<>(obj,HttpStatus.OK);
        }catch (Exception var9){
            throw var9;
        }
    }
    @RequestMapping(
            value = {"/api/search/transactionList"},
            method = {RequestMethod.POST},
            consumes = {"application/vnd.com.equifax.backbone.service.orchestration.rest.request.v1+json"},
            produces = {"application/vnd.com.equifax.backbone.service.orchestration.rest.response.v1+json"}
    )
    @ApiOperation("Execute Transaction")
    @ApiResponses({@ApiResponse(
            code = 400,
            message = "Bad Request"
    ), @ApiResponse(
            code = 500,
            message = "Server Error"
    )})
    public ResponseEntity<Object> executeTransactionFiltro(@RequestBody(required = true) String request, @RequestHeader Map<String, Object> headers) throws IOException {
        try{
            JsonNode jRequest = (new ObjectMapper()).readTree(request);
            Object obj = searchCriteriaService.findByCriteria(jRequest);
            return new ResponseEntity<>(obj,HttpStatus.OK);
        }catch (Exception var9){
            throw var9;
        }
    }
}
