package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "SEARCHCRITERIA")
public class SearchCriteria {
    @Id
    @Column(name = "TRANSACTIONID", columnDefinition = "VARCHAR2")
    private String transactionId;

    @Column(name = "DATECREATED", columnDefinition = "TIMESTAMP")
    private Timestamp dateCreated;
/*
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "MESSAGEBLOB")
    private byte[] messageBlob;
*/
    @Column(name = "TRANSACTIONSTATE")
    private String transactionState;

    @Column(name = "CREATEDBYUSERID")
    private String sendBy;

    @Column(name = "CHILEANRUT")
    private String chileanRut;

    @Column(name = "DECISION")
    private String decision;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Timestamp getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Timestamp dateCreated) {
        this.dateCreated = dateCreated;
    }



    public String getTransactionState() {
        return transactionState;
    }

    public void setTransactionState(String transactionState) {
        this.transactionState = transactionState;
    }

    public String getSendBy() {
        return sendBy;
    }

    public void setSendBy(String sendBy) {
        this.sendBy = sendBy;
    }

    public String getChileanRut() {
        return chileanRut;
    }

    public void setChileanRut(String chileanRut) {
        this.chileanRut = chileanRut;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }
}
