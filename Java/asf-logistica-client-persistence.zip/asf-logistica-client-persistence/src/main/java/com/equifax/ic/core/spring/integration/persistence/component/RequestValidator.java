package com.equifax.ic.core.spring.integration.persistence.component;

import alexh.weak.Dynamic;
import com.equifax.ic.core.spring.integration.persistence.exception.OrchestrationBadRequestException;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantEnumerator;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class RequestValidator {

    private static final String APPLICANTS = "applicants";

    public RequestValidator() {
        //Constructor
    }
    
    public static void validateRequest(String request) throws Exception {

        Map map = new ObjectMapper().readValue(request, Map.class);

        int ordinalApplicantEnumeratorRepresentationSum[] = new int[1];
        int iterationSum[] = new int[1];
        iterationSum[0] = -1;

        if (!Dynamic.from(map).get(APPLICANTS).isPresent())
            throw new OrchestrationBadRequestException("applicants key in the json request is not present");

        Dynamic.from(map).get(APPLICANTS).asMap().forEach((key, value) -> {

            ApplicantEnumerator applicantEnumerator = ApplicantEnumerator.fromString(key.toString());

            iterationSum[0]++;
            ordinalApplicantEnumeratorRepresentationSum[0] += applicantEnumerator.ordinal();

            if (!Dynamic.from(map).get(APPLICANTS).get(applicantEnumerator.getValue()).get("personalInformation").isPresent())
                throw new OrchestrationBadRequestException(applicantEnumerator.getValue() + " personalInformation is not present");

        });

        if (recursiveSum(iterationSum[0]) != ordinalApplicantEnumeratorRepresentationSum[0])
            throw new OrchestrationBadRequestException("Consumers are badly ordered");
    }

    private static int recursiveSum(int n) {
        if (n == 0) //base case A
            return 0;
        if (n == 1) //base case B
            return 1;
        else
            return n + recursiveSum(n - 1);
    }

}
