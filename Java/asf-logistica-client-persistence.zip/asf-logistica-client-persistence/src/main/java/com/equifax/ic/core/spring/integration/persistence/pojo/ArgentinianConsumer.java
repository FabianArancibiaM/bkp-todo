package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;

@Entity(name = "ArgentinianConsumer")
@Table(name = "ARGENTINIANCONSUMER")
public class ArgentinianConsumer {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "ARGENTINIANCONSUMER_SEQ", allocationSize = 1)
	private Long id;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ID_CONSUMER")
	private Consumer consumer;

	@Column(name = "DNI")
	private String dni;

	@Column(name = "NAME")
	private String name;

	@Column(name = "REFERENCE")
	private String reference;
	
	@Column(name = "GENDER")
	private String gender;

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Consumer getConsumer() {
		return consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

}
