package com.equifax.ic.core.spring.integration.persistence.component;

import com.equifax.ic.core.spring.integration.persistence.aop.ServiceActivatorInterceptor;
import com.equifax.ic.core.spring.integration.persistence.config.SystemEventFactory;
import com.equifax.ic.core.spring.integration.persistence.factory.PersistenceFactories;
import com.equifax.ic.core.spring.integration.persistence.factory.impl.*;
import com.equifax.ic.core.spring.integration.persistence.pojo.DataSourceBlob;
import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantDomain;
import com.equifax.ic.core.spring.integration.persistence.util.EventTypeEnumerator;
import com.equifax.ic.core.spring.integration.persistence.util.LatamConsumerApplicantDomain;
import com.equifax.ic.core.spring.integration.persistence.util.PersistenceDomain;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.*;
import java.util.Map.Entry;

/**
 * <p>
 * This bean is responsible to fill with data all factories involved in Client Implementation. This bean is called by {@link ServiceActivatorInterceptor}.
 * </p>
 *
 * @author Alan Sandoval axs831
 * @since 15-08-2018 1.0
 */
@Component
public class FactoriesPopulator {

    private static final Logger LOGGER = LoggerFactory.getLogger(FactoriesPopulator.class);
    private static final String EXECUTION_TIME = "executionTime";
    private static final String MICROSERVICE_NAME = "microServiceName";
    private static final String PERSISTENCE_FACTORIES = "persistenceFactories";
    private static final String SERVICE_ACTIVATOR_ID = "serviceActivatorId";
    private static final String UUID = "uuid";
    private static final String APPLICANT_FIELD = "applicantField";

    private Boolean persistenceIg, persistenceSmartsDataSegr, persistenceMitDataSegr, persistenceSmartsMessage, persistenceMitMessage;
    
    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private OrchestrationProperties orchestrationProperties;

    private String dataSourceListIgParameter;
    private String decisionDecisioningParameter;
    private String descriptionDecisioningParameter;
    private String reasonsDecisioningParameter;

    @SuppressWarnings("unchecked")
    public void systemEventsBuilder(Map<String, Object> payload, Map<String, Object> headers, Map<String, Object> parametersMap) {

        try {
            String customerReferenceIdentifier = (String) ((Map<String, Object>) headers
                    .get(LatamConsumerApplicantDomain.TRANSACTION_CONTEXT.getValue()))
                    .get(LatamConsumerApplicantDomain.ORCHESTRATION.getValue());
            String description;
            String uuid = (String) headers.get("transactionId");

            String applicantIdentifier;
            if (headers.containsKey(APPLICANT_FIELD)){
                applicantIdentifier = headers.get(APPLICANT_FIELD).toString();
            } else {
                applicantIdentifier = "transaction";
            }
            parametersMap.put(APPLICANT_FIELD, applicantIdentifier);
            parametersMap.put("uuid", uuid);
            parametersMap.put("customerReferenceIdentifier", customerReferenceIdentifier);

            if (PersistenceDomain.AFTER.toString().equals(parametersMap.get(EXECUTION_TIME))) {
                description = String.format("After %s pull", parametersMap.get(MICROSERVICE_NAME));
            } else {
                description = String.format("Before %s pull", parametersMap.get(MICROSERVICE_NAME));
            }

            SystemEvent currentSystemEvent;
            PersistenceFactories persistenceFactories = (PersistenceFactories) parametersMap.get(PERSISTENCE_FACTORIES);
            
            currentSystemEvent = ((SystemEventFactory) persistenceFactories.getFactory(SystemEventFactory.class))
                    .logSystemEvent(new Date(), description, null, uuid, applicantIdentifier);
            LOGGER.info("New systemEvent added to factory");

            parametersLoader(headers);
            
            persistenceMicroServices(payload, currentSystemEvent, parametersMap);
            //messageBuilder(payload, currentSystemEvent, parametersMap);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            LOGGER.warn("There is a problem processing SystemEvents in systemEventBuilder method. SystemEvents will be not persisted. {}", e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public void parametersLoader(Map<String, Object> headers) {
        LOGGER.info("Loading parameters from yml...");
        
        Object persistenceParametersIg = orchestrationProperties.getIg();
        Map<String, Boolean> persistenceParametersSmarts = orchestrationProperties.getSmarts();
        Map<String, Boolean> persistenceParametersMit = orchestrationProperties.getMit();
		
        persistenceIg = (Boolean) persistenceParametersIg;
		
		persistenceSmartsDataSegr = persistenceParametersSmarts.get("datasegr");
		persistenceSmartsMessage = persistenceParametersSmarts.get("message");
		
		persistenceMitDataSegr = persistenceParametersMit.get("datasegr");
		persistenceMitMessage = persistenceParametersMit.get("message");
        
		Map<String, Map<String, String>> orchestrationsParameters = orchestrationProperties.getOrchestration();

        String orchestrationName = (String) ((Map<String, Object>) headers.get(LatamConsumerApplicantDomain.TRANSACTION_CONTEXT.getValue()))
                .get(LatamConsumerApplicantDomain.ORCHESTRATION.getValue());

        String basePath = String.format("client.orchestration.%s", orchestrationName);
        String errorMessage = "%s.%s was not found in YML file";

        Map<String, String> currentOrchestrationParameters = orchestrationsParameters.get(orchestrationName);
        Assert.notNull(currentOrchestrationParameters, String.format("%s was not found in YML file", basePath));

        String decisionPath = "service.smarts.decision";
        Assert.notNull(currentOrchestrationParameters.get(decisionPath), String.format(errorMessage, basePath, decisionPath));
        decisionDecisioningParameter = currentOrchestrationParameters.get(decisionPath);

        String descriptionPath = "service.smarts.description";
        Assert.notNull(currentOrchestrationParameters.get(descriptionPath), String.format(errorMessage, basePath, descriptionPath));
        descriptionDecisioningParameter = currentOrchestrationParameters.get(descriptionPath);

        String reasonsPath = "service.smarts.reasons";
        Assert.notNull(currentOrchestrationParameters.get(reasonsPath), String.format(errorMessage, basePath, reasonsPath));
        reasonsDecisioningParameter = currentOrchestrationParameters.get(reasonsPath);

        String dataSourceListPath = "service.ig.dataSourceList";
        Assert.notNull(currentOrchestrationParameters.get(dataSourceListPath), String.format(errorMessage, basePath, dataSourceListPath));
        dataSourceListIgParameter = currentOrchestrationParameters.get(dataSourceListPath);
    }

    private void messageBuilder(Map<String, Object> payload, SystemEvent currentSystemEvent, Map<String, Object> parametersMap, Boolean persistenceMicroService, Boolean persistenceMessage, String microServiceName) {
        String eventType;
        //String microServiceName = parametersMap.get(MICROSERVICE_NAME).toString();
        String mapId = parametersMap.get(SERVICE_ACTIVATOR_ID).toString();
        
        if (!PersistenceDomain.IG.toString().equals(microServiceName)) {
            if (PersistenceDomain.BEFORE.toString().equals(parametersMap.get(EXECUTION_TIME).toString())) {
                mapId = mapId + "_REQUEST";
                parametersMap.put(SERVICE_ACTIVATOR_ID, mapId);
                eventType = eventTypeEvaluator(microServiceName, true);
            } else {
                mapId = mapId + "_RESPONSE";
                parametersMap.put(SERVICE_ACTIVATOR_ID, mapId);
                eventType = eventTypeEvaluator(microServiceName, false);
                persistenceMicroServiceBuilder(persistenceMicroService,microServiceName, payload, parametersMap);
            }

            if (payload.containsKey(mapId)) {
                if (!EventTypeEnumerator.SMARTS_REQUEST.getValue().equals(eventType) && persistenceMessage) {
                    JsonNode messageNode = (JsonNode) payload.get(mapId);
                    PersistenceFactories persistenceFactories = (PersistenceFactories) parametersMap.get(PERSISTENCE_FACTORIES);
                    ((MessagesFactory) persistenceFactories.getFactory(MessagesFactory.class)).logMessages(messageNode, eventType, currentSystemEvent);
                    LOGGER.info("New message added to factory");
                }
            } else {
                LOGGER.warn("There was a problem adding the response message '{}' in MessagesFactory, therefore, this message will be not persisted", mapId);
            }
        } else if (PersistenceDomain.AFTER.toString().equals(parametersMap.get(EXECUTION_TIME).toString())) {
            mapId = mapId + "_RESPONSE";
            parametersMap.put(SERVICE_ACTIVATOR_ID, mapId);
            persistenceMicroServiceIgData(persistenceMicroService,payload, parametersMap);
        }
    }

    private void persistenceMicroServiceIgData(Boolean persistenceMicroService, Map<String, Object> payload, Map<String, Object> parametersMap) {
        if(persistenceMicroService) {
            igDataSourceBuilder(payload, parametersMap);
        }
    }

    private void persistenceMicroServiceBuilder(Boolean persistenceMicroService, String microServiceName, Map<String, Object> payload, Map<String, Object> parametersMap) {
        if(persistenceMicroService) {
            microServiceBuilderExecutor(microServiceName, payload, parametersMap);
        }
    }

    private void microServiceBuilderExecutor(String microServiceName, Map<String, Object> payload, Map<String, Object> parametersMap) {
        if (PersistenceDomain.ANAV.toString().equals(microServiceName)) {
            anavAttributeAccessBuilder(payload, parametersMap);
        }
        if (PersistenceDomain.MIT.toString().equals(microServiceName)) {
            mitScoringBuilder(payload, parametersMap);
        }
        if (PersistenceDomain.SMARTS.toString().equals(microServiceName)) {
            smartsDecisioningBuilder(payload, parametersMap);
        }
    }

    private String eventTypeEvaluator(String microServiceName, boolean isRequest) {
        String eventType = null;
        if (isRequest) {
            if (PersistenceDomain.ANAV.toString().equals(microServiceName)) {
                eventType = EventTypeEnumerator.ANAV_REQUEST.getValue();
            } else if (PersistenceDomain.MIT.toString().equals(microServiceName)) {
                eventType = EventTypeEnumerator.MIT_REQUEST.getValue();
            } else if (PersistenceDomain.SMARTS.toString().equals(microServiceName)) {
                eventType = EventTypeEnumerator.SMARTS_REQUEST.getValue();
            }
        } else {
            if (PersistenceDomain.ANAV.toString().equals(microServiceName)) {
                eventType = EventTypeEnumerator.ANAV_RESPONSE.getValue();
            } else if (PersistenceDomain.MIT.toString().equals(microServiceName)) {
                eventType = EventTypeEnumerator.MIT_RESPONSE.getValue();
            } else if (PersistenceDomain.SMARTS.toString().equals(microServiceName)) {
                eventType = EventTypeEnumerator.SMARTS_RESPONSE.getValue();
            }
        }
        return eventType;
    }


    private void igDataSourceBuilder(Map<String, Object> payload, Map<String, Object> parametersMap) {

        String mapId = parametersMap.get(SERVICE_ACTIVATOR_ID).toString();
        String uuid = parametersMap.get(UUID).toString();
        String customerReferenceIdentifier = parametersMap.get("customerReferenceIdentifier").toString();
        try {
            if (payload.containsKey(mapId)) {
                if (!dataSourceListIgParameter.isEmpty()) {

                    JsonNode igDataSourceNode = (JsonNode) payload.get(mapId);
                    String transactionId = igDataSourceNode.get("transactionId").asText();

                    Iterator<Entry<String, JsonNode>> applicantsNode = igDataSourceNode.get(ApplicantDomain.APPLICANTS.getValue()).fields();

                    while (applicantsNode.hasNext()) {
                        Entry<String, JsonNode> currentApplicantNode = applicantsNode.next();
                        String applicantIdentifier = currentApplicantNode.getKey();
                        String[] dataSourcesArray = dataSourceListIgParameter.split(",");

                        Set<DataSourceBlob> dataSourceBlobSet = dataSourceBlobBuilder(dataSourcesArray, currentApplicantNode);

                        PersistenceFactories persistenceFactories = (PersistenceFactories) parametersMap.get(PERSISTENCE_FACTORIES);
                        ((IgDataSourceAccessFactory) persistenceFactories.getFactory(IgDataSourceAccessFactory.class)).logIgDataSource(transactionId, customerReferenceIdentifier, uuid, applicantIdentifier, dataSourceBlobSet);
                        LOGGER.info("New igDataSourceAccess and message from IG added to factory");
                    }
                } else {
                    throw new NoSuchElementException("'dataSourceList' parameter for IG in YML file is empty. Please, fill it with dataSources names for persistence service");
                }
            } else {
                throw new NoSuchElementException("mapId for IG is missing");
            }
        } catch (Exception e) {
            LOGGER.error("There was a problem adding the IG response '{}' in IgDataSourceFactory, therefore, this registry will be not persisted. {}", mapId, e.getMessage());
        }

    }

    private Set<DataSourceBlob> dataSourceBlobBuilder(String[] dataSourcesArray, Entry<String, JsonNode> currentApplicantNode) throws Exception {
        Set<DataSourceBlob> dataSourceBlobSet = new HashSet<>();
        for (String dataSource : dataSourcesArray) {
            DataSourceBlob dataSourceBlob = new DataSourceBlob();
            dataSourceBlob.setDataSourceName(dataSource.trim());
            JsonNode dataSourceJson = currentApplicantNode.getValue().get(dataSource.trim());
            if (dataSourceJson == null) {
                LOGGER.warn("Datasource {} was not found in message. Please, verify the names in YML file", dataSource);
                continue;
            }
            dataSourceBlob.setResponseBlob(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(dataSourceJson));
            if (currentApplicantNode.getValue().get(dataSource.trim()).findValue("uuid") != null) {
                dataSourceBlob.setDataSourceUuid(currentApplicantNode.getValue().get(dataSource.trim()).findValue("uuid").asText());
            }
            dataSourceBlobSet.add(dataSourceBlob);
        }
        return dataSourceBlobSet;
    }

    private void mitScoringBuilder(Map<String, Object> payload, Map<String, Object> parametersMap) {

        String mapId = parametersMap.get(SERVICE_ACTIVATOR_ID).toString();
        String uuid = parametersMap.get(UUID).toString();

        try {
            if (payload.containsKey(mapId)) {
                JsonNode mitScoringNode = (JsonNode) payload.get(mapId);
                int finalScore = 0;
                String modelId = mitScoringNode.get("modelId").asText();
                Iterator<JsonNode> outputsList = mitScoringNode.get("outputs").elements();

                while (outputsList.hasNext()) {
                    JsonNode entry = outputsList.next();
                    if (("final score").equals(entry.get("name").asText())) {
                        finalScore = entry.get("value").asInt();
                    }
                }

                String applicantIdentifier = parametersMap.get(APPLICANT_FIELD).toString();
                PersistenceFactories persistenceFactories = (PersistenceFactories) parametersMap.get(PERSISTENCE_FACTORIES);
                ((MitScoringFactory) persistenceFactories.getFactory(MitScoringFactory.class))
                        .logMitScoring(finalScore, modelId, uuid, applicantIdentifier);
                LOGGER.info("New mitScoring added to factory");
            } else {
                throw new NoSuchElementException();
            }
        } catch (Exception e) {
            LOGGER.error("There was a problem adding the MIT response '{}' in MitScoringFactory, therefore, this registry will be not persisted", mapId);
        }
    }

    private void anavAttributeAccessBuilder(Map<String, Object> payload, Map<String, Object> parametersMap) {

        String mapId = parametersMap.get(SERVICE_ACTIVATOR_ID).toString();
        String uuid = parametersMap.get(UUID).toString();

        try {
            if (payload.containsKey(mapId)) {
                JsonNode anavAttributeAccess = (JsonNode) payload.get(mapId);
                String applicantIdentifier = parametersMap.get(APPLICANT_FIELD).toString();
                String projectName = anavAttributeAccess.get("identifier").get("organization").asText();
                String baseline = anavAttributeAccess.get("identifier").get("selector").asText();

                PersistenceFactories persistenceFactories = (PersistenceFactories) parametersMap.get(PERSISTENCE_FACTORIES);
                ((AnavAttributeAccessFactory) persistenceFactories.getFactory(AnavAttributeAccessFactory.class))
                        .logAnavAttributeAccess(projectName, baseline, uuid, applicantIdentifier);
                LOGGER.info("New anavAtttributeAccess added to factory");
            } else {
                throw new NoSuchElementException();
            }
        } catch (Exception e) {
            LOGGER.error("There was a problem adding the ANAV response '{}' in AnavAttributeAccessFactory, therefore, this registry will be not persisted", mapId);
        }
    }

    private void smartsDecisioningBuilder(Map<String, Object> payload, Map<String, Object> parametersMap) {

        String mapId = parametersMap.get(SERVICE_ACTIVATOR_ID).toString();
        String uuid = parametersMap.get(UUID).toString();

        try {
            if (payload.containsKey(mapId)) {
                String decision;
                String description;
                String reasons;
                String applicantIdentifier = parametersMap.get(APPLICANT_FIELD).toString();
                String[] decisionDecisioningParameterArray = decisionDecisioningParameter.split(",");
                String[] descriptionDecisioningParameterArray = descriptionDecisioningParameter.split(",");
                String[] reasonsDecisioningParameterArray = reasonsDecisioningParameter.split(",");

                JsonNode smartsDecisioningNode = ((ArrayNode) payload.get(mapId)).get(0);

                for (int i = 0; i < decisionDecisioningParameterArray.length; i++) {

                    //decision = getSmartsPropertyFromNode(decisionDecisioningParameterArray[i], smartsDecisioningNode);

                    if (i >= descriptionDecisioningParameterArray.length) {
                        description = getSmartsPropertyFromNode(descriptionDecisioningParameterArray[0], smartsDecisioningNode);
                    } else {
                        description = getSmartsPropertyFromNode(descriptionDecisioningParameterArray[i], smartsDecisioningNode);
                    }

                    if (i >= reasonsDecisioningParameterArray.length) {
                        reasons = getSmartsPropertyFromNode(reasonsDecisioningParameterArray[0], smartsDecisioningNode);
                    } else {
                        reasons = getSmartsPropertyFromNode(reasonsDecisioningParameterArray[i], smartsDecisioningNode);
                    }
                    decision = asignarDecision(smartsDecisioningNode,"GLOSADECISION");

                    PersistenceFactories persistenceFactories = (PersistenceFactories) parametersMap.get(PERSISTENCE_FACTORIES);
                    ((SmartsDecisioningFactory) persistenceFactories.getFactory(SmartsDecisioningFactory.class))
                            .logSmartsDecisioning(applicantIdentifier, uuid, decision, description, reasons, null, "automatic", new Date());
                    LOGGER.info("New smartsDecisioning added to factory");
                }

            } else {
                throw new NoSuchElementException();
            }
        } catch (Exception e) {
            LOGGER.error("There was a problem adding the SMARTS response '{}' in SmartsDecisioningFactory, therefore, this registry will be not persisted", mapId);
            LOGGER.error(e.getMessage());
        }
    }

    private String asignarDecision(JsonNode smartsDecisioningNode, String glosadecision) {
        if (smartsDecisioningNode!=null){
            return getAtrib(smartsDecisioningNode,glosadecision);
        }
        return "";
    }

    private String getAtrib(JsonNode smartsDecisioningNode, String variable){
        try{
            return smartsDecisioningNode.get("Salida").get(variable).textValue();
        }catch (Exception e){
            return null;
        }
    }

    private String getSmartsPropertyFromNode(String smartsParameter, JsonNode smartsDecisioningNode) throws Exception {
        if(!smartsParameter.isEmpty()) {
            String responseValue;
            if (smartsParameter.indexOf('.') >= 0) {
                smartsParameter = String.format("/%s", smartsParameter.replace('.', '/').trim());
                responseValue = smartsDecisioningNode.at(smartsParameter.trim()).asText();
            } else {
                responseValue = smartsDecisioningNode.path(smartsParameter.trim()).asText();
            }

            if (responseValue == null) {
                throw new Exception(String.format("SMARTS parameter '%s' doesn't exist in SMARTS response", smartsParameter));
            }
            return responseValue;
        } else {
            return null;
        }
    }
    
    public void persistenceMicroServices(Map<String, Object> payload, SystemEvent currentSystemEvent, Map<String, Object> parametersMap) {
    	String microServiceName = parametersMap.get(MICROSERVICE_NAME).toString();
    	
    	if(PersistenceDomain.IG.toString().equals(microServiceName)) {
    		messageBuilder(payload, currentSystemEvent, parametersMap, persistenceIg, true, microServiceName);
    	}else if(PersistenceDomain.MIT.toString().equals(microServiceName)) {
    		messageBuilder(payload, currentSystemEvent, parametersMap, persistenceMitDataSegr, persistenceMitMessage, microServiceName);
    	}else if(PersistenceDomain.SMARTS.toString().equals(microServiceName)) {
    		messageBuilder(payload, currentSystemEvent, parametersMap, persistenceSmartsDataSegr, persistenceSmartsMessage, microServiceName);
    	}else if(PersistenceDomain.ANAV.toString().equals(microServiceName)) {
    		messageBuilder(payload, currentSystemEvent, parametersMap, true, true, microServiceName);
    	}
    }
    
    
}
