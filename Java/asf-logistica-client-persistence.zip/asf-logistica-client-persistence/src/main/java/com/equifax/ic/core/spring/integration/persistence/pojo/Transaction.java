package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;
import java.util.Date;

@Entity(name = "Transaction")
@Table(name = "TRANSACTION")
public class Transaction {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "TRANSACTION_SEQ", allocationSize = 1)
	private Long id;
	
	@Column(name = "UUID")
	private String uuid;
	
	@Column(name = "DATECREATED")
	private Date dateCreated;
	
	@Column(name = "DATEMODIFIED")
	private Date dateModified;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "CUSTOMERREFERENCEIDENTIFIER")
	private String customerReferenceIdentifier;

	@Column(name = "USUARIO")
	private String usuario;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public Date getDateModified() {
		return dateModified;
	}

	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCustomerReferenceIdentifier() {
		return customerReferenceIdentifier;
	}

	public void setCustomerReferenceIdentifier(String customerReferenceIdentifier) {
		this.customerReferenceIdentifier = customerReferenceIdentifier;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
}
