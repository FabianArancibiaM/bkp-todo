package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.UruguayanConsumer;
import org.springframework.data.repository.CrudRepository;

public interface UruguayanConsumerDao extends CrudRepository<UruguayanConsumer, Long> {
	
}
