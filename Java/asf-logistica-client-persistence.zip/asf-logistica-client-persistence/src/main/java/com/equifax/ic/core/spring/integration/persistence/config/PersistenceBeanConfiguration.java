package com.equifax.ic.core.spring.integration.persistence.config;

import com.equifax.ic.core.spring.integration.persistence.component.RequestValidator;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;

@SpringBootConfiguration
public class PersistenceBeanConfiguration {

    @Bean(name = "customRequestValidator")
    public RequestValidator requestValidator() {
        return new RequestValidator();
    }
}
