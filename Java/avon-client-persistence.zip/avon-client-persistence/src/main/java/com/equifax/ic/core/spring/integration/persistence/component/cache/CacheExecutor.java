package com.equifax.ic.core.spring.integration.persistence.component.cache;

import com.equifax.ic.core.spring.integration.persistence.exception.OrchestrationCacheException;
import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import com.equifax.ic.core.spring.integration.persistence.service.MessagesService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

/**
 * <p>
 * This class should be invoked by {@link CacheEvaluator} and will extract the message from the original transaction
 * related to the chileanRut consulted, avoiding to execute the normal workflow (IG > TransformerIG > Smarts... etc).
 * </p>
 *
 * @author Alan Sandoval axs831
 * @since 30-07-2019 1.0
 */

public class CacheExecutor {

    private static final String TRANSACTION_ID_FOR_CACHE = "transactionIdForCache";

    private MessagesService messagesService;

    private ObjectMapper objectMapper;

    public JsonNode executeCache(Map<String, Object> headers) {

        if (headers.containsKey(TRANSACTION_ID_FOR_CACHE) && headers.get(TRANSACTION_ID_FOR_CACHE) != null) {
            try {
                String transactionId = headers.get(TRANSACTION_ID_FOR_CACHE).toString();
                Messages message = messagesService.getMessageResponseByTransactionId(transactionId);
                if (message == null) {
                    throw new OrchestrationCacheException(String.format("Message blob was not found for transaction id %s. Cache failed", transactionId));
                }

                return objectMapper.readTree(message.getMessageBlob());
            } catch (Exception e) {
                throw new OrchestrationCacheException(String.format("Cannot return message from original transaction. Cache failed. Root message error: %s", e.getMessage()));
            }
        } else {
            throw new OrchestrationCacheException("Transaction id for cache was not found in headers. Cache failed");
        }
    }

    public MessagesService getMessagesService() {
        return messagesService;
    }

    public void setMessagesService(MessagesService messagesService) {
        this.messagesService = messagesService;
    }

    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }
}
