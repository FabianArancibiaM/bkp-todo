package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.repository.CrudRepository;

import com.equifax.ic.core.spring.integration.persistence.pojo.ArgentinianConsumer;

public interface ArgentinianConsumerDao extends CrudRepository<ArgentinianConsumer, Long> {
	
}
