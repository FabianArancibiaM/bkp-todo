package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.repository.CrudRepository;

import com.equifax.ic.core.spring.integration.persistence.pojo.PeruvianConsumer;

public interface PeruvianConsumerDao extends CrudRepository<PeruvianConsumer, Long> {

}
