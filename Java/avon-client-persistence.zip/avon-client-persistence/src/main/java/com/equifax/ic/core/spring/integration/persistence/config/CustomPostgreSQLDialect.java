package com.equifax.ic.core.spring.integration.persistence.config;

import org.hibernate.dialect.PostgreSQL82Dialect;
import org.hibernate.type.descriptor.sql.BinaryTypeDescriptor;
import org.hibernate.type.descriptor.sql.SqlTypeDescriptor;

import java.sql.Types;

// This customized PostgreSQL dialect allows the full bi-compatibility between Oracle and PostgreSQL without having to
// remap POJOs annotations/types/properties or related data.

public class CustomPostgreSQLDialect extends PostgreSQL82Dialect{
    public CustomPostgreSQLDialect()
    {
        super();
        registerColumnType(Types.BLOB, "bytea");
    }

    @Override
    public SqlTypeDescriptor remapSqlTypeDescriptor(SqlTypeDescriptor sqlTypeDescriptor) {
        if (sqlTypeDescriptor.getSqlType() == Types.BLOB) {
            return BinaryTypeDescriptor.INSTANCE;
        }
        return super.remapSqlTypeDescriptor(sqlTypeDescriptor);
    }
}
