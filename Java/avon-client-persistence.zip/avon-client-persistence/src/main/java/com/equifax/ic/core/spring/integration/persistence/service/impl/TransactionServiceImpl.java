package com.equifax.ic.core.spring.integration.persistence.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equifax.ic.core.spring.integration.persistence.dao.TransactionDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.Transaction;
import com.equifax.ic.core.spring.integration.persistence.service.TransactionService;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.Date;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionDao transactionDao;

	@Override
	@Transactional
	public void insertTransaction(Transaction transaction) {
		transactionDao.save(transaction);
	}

	@Override
	@Transactional(readOnly = true)
	public Transaction getTransactionById(Long id) {
		return transactionDao.findOne(id);
	}

	@Transactional(readOnly = true)
	public Transaction findTransactionById(String transactionId) {
		return transactionDao.findByUUID(transactionId);
	}

	@Transactional
	public Transaction updateTransaction(Transaction transaction) throws IOException {
		if(getTransactionById(transaction.getId()) == null){
			throw new IOException("Transaction does not exist");
		}
		return transactionDao.save(transaction);
	}

	@Override
	@Transactional(readOnly = true)
	public String findLastTransactionIdNotCachedBetweenDates(String chileanRut, Date fromDate, Date toDate) {
		return transactionDao.findLastTransactionIdNotCachedBetweenDates(chileanRut, fromDate, toDate);
	}

}
