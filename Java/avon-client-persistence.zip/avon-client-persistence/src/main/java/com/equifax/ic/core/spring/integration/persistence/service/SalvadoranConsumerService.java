package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.SalvadoranConsumer;

public interface SalvadoranConsumerService {
	
	void insertSalvadoranConsumer(SalvadoranConsumer consumer);

}