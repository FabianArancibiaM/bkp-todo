package com.equifax.ic.core.spring.integration.persistence.config;

import com.equifax.ic.core.spring.integration.persistence.aop.ServiceActivatorInterceptor;
import com.equifax.ic.core.spring.integration.persistence.aop.TransactionPersistenceExecutor;
import org.aspectj.lang.Aspects;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootConfiguration
@EnableAspectJAutoProxy
public class AspectConfiguration {

    @Bean
    public ServiceActivatorInterceptor serviceActivatorInterceptor() {
        return Aspects.aspectOf(ServiceActivatorInterceptor.class);
    }

    @Bean
    public TransactionPersistenceExecutor transactionPersistenceExecutor() {
        return Aspects.aspectOf(TransactionPersistenceExecutor.class);
    }

}
