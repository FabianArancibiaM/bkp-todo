package com.equifax.ic.core.spring.integration.persistence.service.impl;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.equifax.ic.core.spring.integration.persistence.dao.IgDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.IgPojo;
import com.equifax.ic.core.spring.integration.persistence.service.IgService;

@Service
public class BasicIgService implements IgService {
    @Autowired
    private IgDao igDao;

    @Override
    @Transactional(readOnly = true)
    public List<IgPojo> getAllIg() {
        return (List<IgPojo>) igDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public IgPojo getIgById(Long id) {
        return igDao.findOne(id);
    }

    @Override
    @Transactional
    public void insertIg(IgPojo ig) {
        igDao.save(ig);
    }

    @Override
    @Transactional
    public IgPojo updateIg(IgPojo ig) throws IOException {
        if(getIgById(ig.getId()) == null){
            throw new IOException("Ig does not exist");
        }
        return igDao.save(ig);
    }

	@Override
	public void insertList(List<?> igDataSourceList) {
		for (Object igDataSource : igDataSourceList)
			igDao.save((IgPojo) igDataSource);
		
	}
}
