package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.EcuadorianConsumer;
import org.springframework.data.repository.CrudRepository;

public interface EcuadorianConsumerDao extends CrudRepository<EcuadorianConsumer, Long> {
}
