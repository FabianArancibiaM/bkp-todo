package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.repository.CrudRepository;

import com.equifax.ic.core.spring.integration.persistence.pojo.SalvadoranConsumer;

public interface SalvadoranConsumerDao extends CrudRepository<SalvadoranConsumer, Long> {

}