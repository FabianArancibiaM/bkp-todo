package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.DataSourceBlob;
import org.springframework.data.repository.CrudRepository;

public interface DataSourceBlobDao extends CrudRepository<DataSourceBlob, Long> {
}
