package com.equifax.ic.core.spring.integration.persistence.service;

import java.util.List;

import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;

public interface MessagesService extends FactoryService{

	public List<Messages> getAllMessages();

	public Messages getMessageById(final Long id);
	
	public void saveNewMessage(Messages message);
	
	public Messages updateMessage(Messages message) throws Exception;

	public Messages getMessageResponseByTransactionId(String transactionId);
	
}
