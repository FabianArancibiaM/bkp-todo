package com.equifax.ic.core.spring.integration.persistence.component;

import com.equifax.ic.core.spring.integration.persistence.factory.PersistenceFactories;
import com.equifax.ic.core.spring.integration.persistence.factory.impl.MessagesFactory;
import com.equifax.ic.core.spring.integration.persistence.factory.impl.SystemEventFactory;
import com.equifax.ic.core.spring.integration.persistence.pojo.*;
import com.equifax.ic.core.spring.integration.persistence.service.*;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantDomain;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantEnumerator;
import com.equifax.ic.core.spring.integration.persistence.util.EventTypeEnumerator;
import com.equifax.ic.core.spring.integration.persistence.util.LatamConsumerApplicantDomain;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import javax.persistence.PersistenceException;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

@Component
public class TransactionPersistence {

	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionPersistence.class);
	private static final String PERSISTENCE_FACTORIES = "persistenceFactories";
	private static final String TRANSACTION_ID_FOR_CACHE = "transactionIdForCache";
	private static final String USERNAME_PATH = "/applicants/primaryConsumer/personalInformation/userName";

	private String country;
	private Boolean persistenceCiConsumer, persistenceCiMessage;

	@Autowired
	private PeruvianConsumerService peruvianConsumerService;

	@Autowired
  	private ChileanConsumerService chileanConsumerService;

	@Autowired
  	private ArgentinianConsumerService argentinianConsumerService;

	@Autowired
  	private UruguayanConsumerService uruguayanConsumerService;

	@Autowired
	private CostaRicanConsumerService costaRicanConsumerService;

	@Autowired
	private SalvadoranConsumerService salvadoranConsumerService;

	@Autowired
	private HonduranConsumerService honduranConsumerService;

	@Autowired
  	private EcuadorianConsumerService ecuadorianConsumerService;

	@Autowired
  	private TransactionService transactionService;

	@Autowired
  	private MessagesService messagesService;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private SystemEventService systemEventService;

	@Autowired
	private OrchestrationProperties orchestrationProperties;

	@Autowired
	private MicroServicesIdCollector microServicesIdCollector;

	@SuppressWarnings({ "unchecked" })
	@Transactional
	public void persistCiRequest(final Map<String, Object> payload, final Map<String, Object> headers)
			throws Exception {

		try {

			String orchestration = (String) ((Map<String, Object>) headers.get(LatamConsumerApplicantDomain.TRANSACTION_CONTEXT.getValue()))
					.get(LatamConsumerApplicantDomain.ORCHESTRATION.getValue());

			String organizationCode = this.getOrganizationCode(headers);

			parametersLoader(orchestration);

			Assert.notNull(headers.get(ApplicantDomain.TRANSACTION_ID_KEY.getValue()),"Transaction Id is required");

			String transactionId = (String) headers.get(ApplicantDomain.TRANSACTION_ID_KEY.getValue());
			String userName = extractUserName(payload);

			if(persistenceCiConsumer) {
            for (ApplicantEnumerator currentApplicant : ApplicantEnumerator.values()) {

                if ((((ObjectNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))
                        .get(ApplicantDomain.APPLICANTS.getValue())).get(currentApplicant.getValue()) != null) {

                    Consumer consumer = new Consumer();
                    consumer.setUuid(transactionId);
                    consumer.setCountry(this.country);

                    persistConsumerByCountry(this.country, consumer, payload, currentApplicant);
                    
                } else {
                    break;
                }
            }
			}

			Transaction transaction = new Transaction();
			transaction.setUuid((String) headers.get(ApplicantDomain.TRANSACTION_ID_KEY.getValue()));
			transaction.setCustomerReferenceIdentifier(organizationCode);
			transaction.setDateCreated(new Date());
			transaction.setStatus(ApplicantDomain.INPROGRESS.getValue());
			transaction.setUsuario(userName);
			transactionService.insertTransaction(transaction);
			LOGGER.info("Client implementation transaction persisted");

			SystemEvent systemEvent = new SystemEvent();
			systemEvent.setUuid(transactionId);
			systemEvent.setDescription("Transaction initiation");
			systemEvent.setDateCreated(new Date());
			systemEvent.setApplicantIdentifier("transaction");
			systemEventService.saveNewSystemEvent(systemEvent);
			LOGGER.info("SystemEvent for CI request persisted");


			Messages messages = new Messages();

			if(persistenceCiMessage) {

				messages.setMessageBlob((objectMapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))));
				messages.setIdSystemEvent(systemEvent.getId());
				messages.setEventType(EventTypeEnumerator.CI_REQUEST.getValue());
				messagesService.saveNewMessage(messages);
				LOGGER.info("Message for CI request persisted");

			}

		} catch (JsonProcessingException e) {
			LOGGER.error("Error saving request as json", e);
			throw new Exception("Error saving request as json");
		} catch (IllegalArgumentException e) {
			LOGGER.error(e.getMessage(), e);
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("Error persistence consumer", e);
			throw new Exception("Error persisting consumers");
		}
	}

	private void persistConsumerByCountry(String country, Consumer consumer, Map<String, Object> payload, ApplicantEnumerator currentApplicant) {
		
		if (LatamConsumerApplicantDomain.CHILE_KEY.getValue().equals(this.country)) {
            persistChileanConsumer(consumer, payload, currentApplicant);
        } else if (LatamConsumerApplicantDomain.PERU_KEY.getValue().equals(this.country)) {
            persistPeruvianConsumer(consumer, payload, currentApplicant);
        } else if (LatamConsumerApplicantDomain.ARGENTINA_KEY.getValue().equals(this.country)) {
            persistArgentinianConsumer(consumer, payload, currentApplicant);
        } else if (LatamConsumerApplicantDomain.URUGUAY_KEY.getValue().equals(this.country)) {
            persistUruguayanConsumer(consumer, payload, currentApplicant);
        }else if (LatamConsumerApplicantDomain.COSTARICAN_KEY.getValue().equals(this.country)) {
        	persistCostaRicanConsumer(consumer, payload, currentApplicant);
        } else if (LatamConsumerApplicantDomain.HONDURAN_KEY.getValue().equals(this.country)) {
        	persistHonduranConsumer(consumer, payload, currentApplicant);
        } else if (LatamConsumerApplicantDomain.SALVADORAN_KEY.getValue().equals(this.country)) {
        	persistSalvadoranConsumer(consumer, payload, currentApplicant);
        } else if (LatamConsumerApplicantDomain.ECUADOR_KEY.getValue().equals(this.country)) {
          persistEcuadorianConsumer(consumer, payload, currentApplicant);
        } else {
            LOGGER.warn("Consumer was not persisted. Please, check the value 'country' in YML file");
            throw new IllegalArgumentException(String.format("'%s' in YML file is not a valid country", country));
        }
	}

	private String getOrganizationCode(Map<String, Object> headers){
		String organizationCode = new String();
		try {
			organizationCode = Arrays.asList(headers.get("clientImplementationEndPoint").toString().split("\\s*/\\s*")).get(4);
			return organizationCode;
		} catch (Exception e) {
			LOGGER.error("Failed to find OrganizationCode from the CI request", e);
			throw new RuntimeException("Failed to find OrganizationCode from the CI request", e);
		}
	}


	@SuppressWarnings("unchecked")
	private void parametersLoader(String orchestration) {

		LOGGER.info("Loading parameters from yml...");
		Map<String, Map<String, String>> orchestrationsParameters = orchestrationProperties.getOrchestration();

		Map<String, Boolean> persistenceParameters = orchestrationProperties.getCi();
		persistenceCiConsumer = persistenceParameters.get("consumer");
		persistenceCiMessage = persistenceParameters.get("message");

		String basePath = String.format("client.orchestration.%s", orchestration);

		Map<String, String> currentOrchestrationParameters = orchestrationsParameters.get(orchestration);
		Assert.notNull(currentOrchestrationParameters, String.format("'%s' was not found in YML file", basePath));

		String countryPath = String.format("%s.country", basePath);
		String countryValue = currentOrchestrationParameters.get("country");
		Assert.notNull(countryValue, String.format("'%s' was not found in YML file", countryPath));

		if (countryValue.isEmpty()){
			throw new IllegalArgumentException(String.format("'%s' is empty. Country is required", countryPath));
		} else {
			country = countryValue;
		}

	}

	private void persistChileanConsumer(Consumer consumer, Map<String, Object> payload,
			ApplicantEnumerator currentApplicant) {

		ChileanConsumer chileanConsumer = new ChileanConsumer();

		ObjectNode applicant = (ObjectNode) (((ObjectNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))
				.get(ApplicantDomain.APPLICANTS.getValue())).get(currentApplicant.getValue());
		ObjectNode personalInformation = (ObjectNode) applicant.get(ApplicantDomain.PERSONAL_INFORMATION.getValue());

		String chileanRut = personalInformation.get(LatamConsumerApplicantDomain.CHILEAN_RUT.getValue()).asText();
		String chileanSerialNumber = (personalInformation
				.get(LatamConsumerApplicantDomain.CHILEAN_SERIAL_NUMBER.getValue()) == null) ? "A000000001"
						: personalInformation.get(LatamConsumerApplicantDomain.CHILEAN_SERIAL_NUMBER.getValue()).asText();

		consumer.setApplicationIdentifier(currentApplicant.getValue());

		chileanConsumer.setChileanRut(chileanRut);
		chileanConsumer.setChileanSerialNumber(chileanSerialNumber);
		chileanConsumer.setConsumer(consumer);
		chileanConsumerService.insertChileanConsumer(chileanConsumer);

		LOGGER.info("Chilean consumer persisted");

	}

	private void persistPeruvianConsumer(Consumer consumer, Map<String, Object> payload,
			ApplicantEnumerator currentApplicant) {

		PeruvianConsumer peruvianConsumer = new PeruvianConsumer();

		ObjectNode applicant = (ObjectNode) (((ObjectNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))
				.get(ApplicantDomain.APPLICANTS.getValue())).get(currentApplicant.getValue());

		ObjectNode personalInformation = (ObjectNode) applicant.get(ApplicantDomain.PERSONAL_INFORMATION.getValue());

		String peruIdType = personalInformation.get(LatamConsumerApplicantDomain.PERUVIAN_TYPE.getValue()).asText();
		String peruIdNumber = personalInformation.get(LatamConsumerApplicantDomain.PERUVIAN_NUMBER.getValue()).asText();
		consumer.setApplicationIdentifier(currentApplicant.getValue());

		peruvianConsumer.setPeruIdType(peruIdType);
		peruvianConsumer.setPeruIdNumber(peruIdNumber);
		peruvianConsumer.setConsumer(consumer);
		peruvianConsumerService.insertPeruvianConsumer(peruvianConsumer);

		LOGGER.info("Peruvian consumer persisted");
	}

	private void persistArgentinianConsumer(Consumer consumer, Map<String, Object> payload,
			ApplicantEnumerator currentApplicant) {

		ArgentinianConsumer argentinianConsumer = new ArgentinianConsumer();

		ObjectNode applicant = (ObjectNode) (((ObjectNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))
				.get(ApplicantDomain.APPLICANTS.getValue())).get(currentApplicant.getValue());

		ObjectNode personalInformation = (ObjectNode) applicant.get(ApplicantDomain.PERSONAL_INFORMATION.getValue());

		ObjectNode nameInformation = (ObjectNode) (personalInformation.get(ApplicantDomain.NAME.getValue())).get(0);

		String dni = personalInformation.get(LatamConsumerApplicantDomain.ARGENTINIAN_DNI.getValue()).asText();
		String reference = personalInformation.get(LatamConsumerApplicantDomain.ARGENTINIAN_REFERENCE.getValue()).asText();

		String gender = personalInformation.get(ApplicantDomain.GENDER.getValue()).asText();
		String firstName = nameInformation.get(ApplicantDomain.NAME.getValue()).asText();
		String lastName = nameInformation.get(ApplicantDomain.LASTNAME.getValue()).asText();

		consumer.setFirstName(firstName);
		consumer.setLastName(lastName);
		consumer.setApplicationIdentifier(currentApplicant.getValue());

		argentinianConsumer.setDni(dni);
		argentinianConsumer.setReference(reference);
		argentinianConsumer.setName(firstName);
		argentinianConsumer.setGender(gender);
		argentinianConsumer.setConsumer(consumer);

		argentinianConsumerService.insertArgentinianConsumer(argentinianConsumer);

		LOGGER.info("Argentinian consumer persisted");
	}

	private void persistUruguayanConsumer(Consumer consumer, Map<String, Object> payload,
			ApplicantEnumerator currentApplicant) {

		UruguayanConsumer uruguayanConsumer = new UruguayanConsumer();

		ObjectNode applicant = (ObjectNode) (((ObjectNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))
				.get(ApplicantDomain.APPLICANTS.getValue())).get(currentApplicant.getValue());

		ObjectNode personalInformation = (ObjectNode) applicant.get(ApplicantDomain.PERSONAL_INFORMATION.getValue());

		ObjectNode nameInformation = (ObjectNode) (personalInformation.get(ApplicantDomain.NAME.getValue())).get(0);

		String documento = personalInformation.get(LatamConsumerApplicantDomain.URUGUAYAN_DOCUMENTO.getValue()).asText();

		String ficha = personalInformation.get(LatamConsumerApplicantDomain.URUGUAYAN_FICHA.getValue()).asText();
		String firstName = nameInformation.get(ApplicantDomain.NAME.getValue()).asText();
		String lastName = nameInformation.get(ApplicantDomain.LASTNAME.getValue()).asText();

		consumer.setFirstName(firstName);
		consumer.setLastName(lastName);
		consumer.setApplicationIdentifier(currentApplicant.getValue());

		uruguayanConsumer.setDocumento(documento);
		uruguayanConsumer.setFicha(ficha);
		uruguayanConsumer.setName(firstName);
		uruguayanConsumer.setConsumer(consumer);

		uruguayanConsumerService.insertUruguayanConsumer(uruguayanConsumer);

		LOGGER.info("Uruguayan consumer persisted");

	}

	private void persistParaguayanConsumer(Consumer consumer, Map<String, Object> payload,
			ApplicantEnumerator currentApplicant) {
		// There is no properties defined in ParaguayanConsumer yet
	}

	@Transactional
	public void persistCostaRicanConsumer(Consumer consumer, Map<String, Object> payload,
			ApplicantEnumerator currentApplicant) {

		CostaRicanConsumer costaRicanConsumer = new CostaRicanConsumer();

		ObjectNode applicant = (ObjectNode) (((ObjectNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))
				.get(ApplicantDomain.APPLICANTS.getValue())).get(currentApplicant.getValue());
		ObjectNode personalInformation = (ObjectNode) applicant.get(ApplicantDomain.PERSONAL_INFORMATION.getValue());

		String identificationNumber = personalInformation.get(LatamConsumerApplicantDomain.COSTARICAN_ID.getValue()).asText();

		consumer.setApplicationIdentifier(currentApplicant.getValue());

		costaRicanConsumer.setIdentificationNumber(identificationNumber);
		costaRicanConsumer.setConsumer(consumer);
		costaRicanConsumerService.insertCostaRicanConsumer(costaRicanConsumer);

		LOGGER.info("Costa Rican consumer persisted");

	}

	@Transactional
	public void persistHonduranConsumer(Consumer consumer, Map<String, Object> payload,
			ApplicantEnumerator currentApplicant) {

		HonduranConsumer honduranConsumer = new HonduranConsumer();

		ObjectNode applicant = (ObjectNode) (((ObjectNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))
				.get(ApplicantDomain.APPLICANTS.getValue())).get(currentApplicant.getValue());
		ObjectNode personalInformation = (ObjectNode) applicant.get(ApplicantDomain.PERSONAL_INFORMATION.getValue());

		String identificationNumber = personalInformation.get(LatamConsumerApplicantDomain.HONDURAN_ID.getValue()).asText();

		consumer.setApplicationIdentifier(currentApplicant.getValue());

		honduranConsumer.setIdentificationNumber(identificationNumber);
		honduranConsumer.setConsumer(consumer);
		honduranConsumerService.insertHonduranConsumer(honduranConsumer);

		LOGGER.info("Honduran consumer persisted");

	}

	@Transactional
	public void persistSalvadoranConsumer(Consumer consumer, Map<String, Object> payload,
			ApplicantEnumerator currentApplicant) {

		SalvadoranConsumer salvadoranConsumer = new SalvadoranConsumer();

		ObjectNode applicant = (ObjectNode) (((ObjectNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))
				.get(ApplicantDomain.APPLICANTS.getValue())).get(currentApplicant.getValue());
		ObjectNode personalInformation = (ObjectNode) applicant.get(ApplicantDomain.PERSONAL_INFORMATION.getValue());

		String identificationNumber = personalInformation.get(LatamConsumerApplicantDomain.SALVADORAN_ID.getValue()).asText();

		consumer.setApplicationIdentifier(currentApplicant.getValue());

		salvadoranConsumer.setIdentificationNumber(identificationNumber);
		salvadoranConsumer.setConsumer(consumer);
		salvadoranConsumerService.insertSalvadoranConsumer(salvadoranConsumer);

		LOGGER.info("Salvadoran consumer persisted");

	}

	private void persistEcuadorianConsumer(Consumer consumer, Map<String, Object> payload,
                                           ApplicantEnumerator currentApplicant) {
        EcuadorianConsumer ecuadorianConsumer = new EcuadorianConsumer();
        ObjectNode applicant = (ObjectNode) (((ObjectNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()))
                .get(ApplicantDomain.APPLICANTS.getValue())).get(currentApplicant.getValue());
        ObjectNode personalInformation = (ObjectNode) applicant.get(ApplicantDomain.PERSONAL_INFORMATION.getValue());

        String tipoDocumento = personalInformation.get(LatamConsumerApplicantDomain.ECUADORIAN_DOCUMENTTYPE.getValue()).asText();
        String numeroDocumento = personalInformation.get(LatamConsumerApplicantDomain.ECUADORIAN_DOCUMENTNUMBER.getValue()).asText();
        consumer.setApplicationIdentifier(currentApplicant.getValue());

        ecuadorianConsumer.setTipoDocumento(tipoDocumento);
        ecuadorianConsumer.setNumeroDocumento(numeroDocumento);
        ecuadorianConsumer.setConsumer(consumer);
        ecuadorianConsumerService.insertEcuadorianConsumer(ecuadorianConsumer);

        LOGGER.info("Ecuadorian consumer persisted");
    }

	@SuppressWarnings("unchecked")
	@Transactional
	public void persistCiResponse(Map<String, Object> finalResponse, Map<String, Object> headers, Transaction transaction) throws Exception {

		String currentTransactionId = headers.get(ApplicantDomain.TRANSACTION_ID_KEY.getValue()).toString();
		PersistenceFactories persistenceFactories = (PersistenceFactories) headers.get(PERSISTENCE_FACTORIES);

			try {
				// Transaction update
				transaction.setStatus(ApplicantDomain.COMPLETED.getValue());
				transaction.setDateModified(new Date());
				transactionService.updateTransaction(transaction);
				//LOGGER.info("Transaction id '{}' updated in DB", currentTransactionId);

				// SystemEvent creation
				String description = "Transaction completion";
				String applicantIdentifier = "transaction";
				Long duration = null;
				SystemEvent transactionInitEvent = systemEventService.findByUuidAndDescription(currentTransactionId, "Transaction initiation");

				if(transactionInitEvent != null) {
					duration = new Date().getTime() - transactionInitEvent.getDateCreated().getTime();
				}

				SystemEvent finalSystemEvent = ((SystemEventFactory) persistenceFactories.getFactory(SystemEventFactory.class)).logSystemEvent(new Date(), description, duration, currentTransactionId, applicantIdentifier);

				// Message creation
				if(persistenceCiMessage) {
					JsonNode finalResponseJson = objectMapper.valueToTree(finalResponse);
					((MessagesFactory) persistenceFactories.getFactory(MessagesFactory.class)).logMessages(finalResponseJson, EventTypeEnumerator.CI_RESPONSE.getValue(), finalSystemEvent);
				}
				// Factories persistence
				persistenceFactories.flushFactories();

			} catch (Exception e) {
				LOGGER.error("Failed to persist CI response", e);
				throw e;
			}

	}

	@Transactional
	public void persistCachedTransaction(Map<String, Object> payload, Map<String, Object> headers) {
		if (headers.containsKey(TRANSACTION_ID_FOR_CACHE) && headers.get(TRANSACTION_ID_FOR_CACHE) != null) {

			String originalTransactionId = headers.get(TRANSACTION_ID_FOR_CACHE).toString();
			String organizationCode = this.getOrganizationCode(headers);

			String userName = extractUserName(payload);

			Transaction transaction = new Transaction();
			transaction.setUuid((String) headers.get(ApplicantDomain.TRANSACTION_ID_KEY.getValue()));
			transaction.setCustomerReferenceIdentifier(organizationCode);
			transaction.setDateCreated(new Date());
			transaction.setStatus(ApplicantDomain.COMPLETED.getValue());
			transaction.setCached(1);
			transaction.setOriginalUUID(originalTransactionId);
			transaction.setUsuario(userName);
			transactionService.insertTransaction(transaction);

			LOGGER.info("Cached client implementation transaction persisted");

		} else {
			throw new PersistenceException("Failed to persist cached transaction. Original transaction id was not found");
		}
	}

	private String extractUserName(Map<String, Object> payload) {
		if (payload.containsKey(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()) && payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue()) instanceof JsonNode) {
			JsonNode initialRequest = (JsonNode) payload.get(ApplicantDomain.INITIAL_REQUEST_KEY.getValue());
			return initialRequest.at(USERNAME_PATH).asText();
		}

		return null;
	}
	
}
