package com.equifax.ic.core.spring.integration.persistence.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.equifax.ic.core.spring.integration.persistence.dao.SystemEventDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;
import com.equifax.ic.core.spring.integration.persistence.service.SystemEventService;

@Service
public class BasicSystemEventService implements SystemEventService{

	@Autowired
	private SystemEventDao systemEventDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<SystemEvent> getAllSystemEvents() {
		return (List<SystemEvent>) systemEventDao.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public SystemEvent getSystemEventById(Long id) {
		return systemEventDao.findOne(id);
	}

	@Override
	@Transactional(readOnly = true)
	public SystemEvent findByUuidAndDescription(String uuid, String description) {
		return systemEventDao.findByUuidAndDescription(uuid, description);
	}

	@Override
	@Transactional
	public void saveNewSystemEvent(SystemEvent systemEvent) {
		systemEventDao.save(systemEvent);
	}

	@Override
	@Transactional
	public SystemEvent updateSystemEvent(SystemEvent systemEvent) throws Exception {
		if(getSystemEventById(systemEvent.getId()) == null) {
			throw new Exception("The systemEvent does not exist");
		}
		return systemEventDao.save(systemEvent);
	}

	@Override
	@Transactional
	public void insertList(List<?> systemEventList) {
		for (Object systemEvent : systemEventList)
			systemEventDao.save((SystemEvent) systemEvent);
	}

}
