package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.repository.CrudRepository;

import com.equifax.ic.core.spring.integration.persistence.pojo.HonduranConsumer;

public interface HonduranConsumerDao extends CrudRepository<HonduranConsumer, Long> {

}