package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.MitPojo;
import org.springframework.data.repository.CrudRepository;

public interface MitDao extends CrudRepository<MitPojo, Long> {
}
