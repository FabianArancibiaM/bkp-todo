package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;

@Entity
@Table(name = "MITSCORING")
public class MitPojo {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    @SequenceGenerator(name = "SEQ", sequenceName = "MITSCORING_SEQ", allocationSize = 1)
    private Long id;

    @Column(name = "FINALSCORE")
    private Integer finalscore;

    @Column(name = "MODELID")
    private String modelId;

    @Column(name = "UUID")
    private String uuid;

    @Column(name = "APPLICANTIDENTIFIER")
    private String applicantIdentifier;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getFinalscore() {
        return finalscore;
    }

    public void setFinalscore(Integer finalscore) {
        this.finalscore = finalscore;
    }

    public String getModelId() {
        return modelId;
    }

    public void setModelId(String modelId) {
        this.modelId = modelId;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getApplicantIdentifier() {
        return applicantIdentifier;
    }

    public void setApplicantIdentifier(String applicantIdentifier) {
        this.applicantIdentifier = applicantIdentifier;
    }
}
