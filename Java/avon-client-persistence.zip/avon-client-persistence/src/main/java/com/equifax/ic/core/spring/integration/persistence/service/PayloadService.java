package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.domain.Payload;

import java.util.List;
import java.util.Optional;

public interface PayloadService {

    void savePayload(Payload transaction);

    Optional<List<Payload>> getPayload(String transactionId);

}
