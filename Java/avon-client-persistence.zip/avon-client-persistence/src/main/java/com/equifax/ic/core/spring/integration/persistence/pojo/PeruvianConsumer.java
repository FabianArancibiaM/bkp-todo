package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "PERUVIANCONSUMER")
public class PeruvianConsumer {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "PERUVIANCONSUMER_SEQ", allocationSize = 1)
	private Long id;

	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ID_CONSUMER")
	private Consumer consumer;

	@Column(name = "PERUIDTYPE")
	private String peruIdType;

	@Column(name = "PERUIDNUMBER")
	private String peruIdNumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Consumer getConsumer() {
		return consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

	public String getPeruIdType() {
		return peruIdType;
	}

	public void setPeruIdType(String peruIdType) {
		this.peruIdType = peruIdType;
	}

	public String getPeruIdNumber() {
		return peruIdNumber;
	}

	public void setPeruIdNumber(String peruIdNumber) {
		this.peruIdNumber = peruIdNumber;
	}

}
