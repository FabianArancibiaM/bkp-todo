package com.equifax.ic.core.spring.integration.persistence.config;

import com.equifax.ic.core.spring.integration.persistence.component.MicroServicesIdCollector;
import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.factory.impl.*;
import com.equifax.ic.core.spring.integration.persistence.service.*;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import java.util.LinkedHashMap;
import java.util.Map;

@SpringBootConfiguration
@ComponentScan("com.equifax.ic.core.spring.integration.persistence")
public class ComponentConfiguration {

    @Bean
    public Map<Class<? extends Factory>, FactoryService> factoriesContainer(SystemEventService systemEventService, MessagesService messagesService,
                                                                            IgService igService, MitService mitService, SmartsService smartsService, AnavService anavService) {

        Map<Class<? extends Factory>, FactoryService> factoriesMap = new LinkedHashMap<>();

        // Include in this list every factory class you want to register in PersistenceFactories bean
        factoriesMap.put(SystemEventFactory.class, systemEventService);
        factoriesMap.put(MessagesFactory.class, messagesService);
        factoriesMap.put(IgDataSourceAccessFactory.class, igService);
        factoriesMap.put(AnavAttributeAccessFactory.class, anavService);
        factoriesMap.put(MitScoringFactory.class, mitService);
        factoriesMap.put(SmartsDecisioningFactory.class, smartsService);
        return factoriesMap;
    }

    @Bean
    public MicroServicesIdCollector microServicesIdCollector() {
        return new MicroServicesIdCollector();
    }
}
