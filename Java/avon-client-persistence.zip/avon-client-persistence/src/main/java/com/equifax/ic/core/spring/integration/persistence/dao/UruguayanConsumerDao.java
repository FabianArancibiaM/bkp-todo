package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.repository.CrudRepository;

import com.equifax.ic.core.spring.integration.persistence.pojo.UruguayanConsumer;

public interface UruguayanConsumerDao extends CrudRepository<UruguayanConsumer, Long> {
	
}
