package com.equifax.ic.core.spring.integration.persistence.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.equifax.ic.core.spring.integration.persistence.dao.EcuadorianConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.EcuadorianConsumer;
import com.equifax.ic.core.spring.integration.persistence.service.EcuadorianConsumerService;

@Service
public class EcuadorianConsumerServiceImpl implements EcuadorianConsumerService {

    @Autowired
    private EcuadorianConsumerDao ecuadorianConsumerDao;

    @Override
    @Transactional
    public void insertEcuadorianConsumer(EcuadorianConsumer ecuadorianConsumer) {
        ecuadorianConsumerDao.save(ecuadorianConsumer);
    }
}
