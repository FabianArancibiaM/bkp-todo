package com.equifax.ic.core.spring.integration.persistence.aop;

import com.equifax.ic.core.spring.integration.persistence.component.FactoriesPopulator;
import com.equifax.ic.core.spring.integration.persistence.component.MicroServicesIdCollector;
import com.equifax.ic.core.spring.integration.persistence.util.PersistenceDomain;
import com.equifax.ic.product.clientconfig.domain.impl.ServiceActivator;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.integration.history.MessageHistory;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;


/**
 * <p>
 * This class is responsible for collecting all the events in the Client Implementation that will be persist later. Aspect is used to do that.
 * </p>
 * 
 * @author Alan Sandoval axs831
 * @since 10-08-2018 1.0
 */

@Aspect
public class ServiceActivatorInterceptor {

	@Autowired
	private Environment environment;
	
	@Autowired
	private FactoriesPopulator factoriesPopulator;

	@Autowired
	private MicroServicesIdCollector microServicesIdCollector;

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceActivatorInterceptor.class);
	
	private static final String HISTORY = "history";

	@Before("execution(public Map<String, Object> com.equifax.ic.core.clienteip.service.impl.BasicRestServiceActivator.invoke(Map<String, Object>, Map<String, Object>)) && args(payload, headers)")
	public void beforeMicroServiceExecution(Map<String, Object> payload, Map<String, Object> headers) throws Exception {	

		LOGGER.info("Method 'invoke' of 'BasicRestServiceActivator' class intercepted with Aspect, BEFORE its execution");
		factoriesPopulator.systemEventsBuilder(payload, headers, parametersBuilder(headers, PersistenceDomain.BEFORE.toString()));
	}
	
	@AfterReturning("execution(public Map<String, Object> com.equifax.ic.core.clienteip.service.impl.BasicRestServiceActivator.invoke(Map<String, Object>, Map<String, Object>)) && args(payload, headers)")
	public void afterMicroServiceExecution(Map<String, Object> payload, Map<String, Object> headers) throws Exception {

		LOGGER.info("Method 'invoke' of 'BasicRestServiceActivator' class intercepted with Aspect, AFTER its execution");
		factoriesPopulator.systemEventsBuilder(payload, headers, parametersBuilder(headers, PersistenceDomain.AFTER.toString()));
	}

	@Around("execution(private String com.equifax.ic.core.clienteip.service.impl.BasicRestServiceActivator.getApplicationUrl(com.equifax.ic.product.clientconfig.domain.impl.ServiceActivator)) && args(serviceContext)")
	public String aroundGetApplicationUrl(ProceedingJoinPoint joinPoint, ServiceActivator serviceContext) throws Throwable {
		LOGGER.info("Method 'getApplicationUrl' of 'BasicRestServiceActivator' class intercepted with Aspect, AROUND its execution");

		Object responseUrl;
		String serviceId = serviceContext.getApplicationId();
		Boolean isCustomBaseURLEnabled = Boolean.valueOf(environment.getProperty("servicesLoadBalancerURL."
				.concat(serviceId).concat(".enabled")));

		if(isCustomBaseURLEnabled){
			String baseURL = environment.getProperty("servicesLoadBalancerURL."
					.concat(serviceId).concat(".baseUrl"));
			LOGGER.info("Custom LoadBalancer URL setting enabled for service: {}. Replacing base URL with: {}", serviceId, baseURL);

			if(baseURL.isEmpty()) {
				LOGGER.error("Custom LoadBalancer URL for service: {} is empty or not set up the YML configuration.", serviceId);
				throw new Exception("Custom LoadBalancer URL for service: ".concat(serviceId)
						.concat(" is empty or not set up on the YML configuration."));
			} else {
				responseUrl = baseURL.concat(serviceContext.getServicePath());
			}
		} else {
			LOGGER.info("Custom LoadBalancer URL setting disabled. Retrieving {} service URL from Eureka.", serviceId);
			responseUrl = joinPoint.proceed();
		}

		if(responseUrl instanceof Throwable) {
			throw (Throwable) responseUrl;
		} else {
			return (String) responseUrl;
		}
	}

	private Map<String, Object> parametersBuilder(Map<String, Object> headers, String executionTime) throws Exception {

		Map<String, Object> parametersMap = new HashMap<>();
		String currentServiceActivatorId = getCurrentServiceActivatorId(headers);
		String microServiceName = microServicesIdCollector.getServiceName(currentServiceActivatorId);

		Assert.notNull(microServiceName, String.format("Service Activator %s was not found in any application context. ", currentServiceActivatorId));

		parametersMap.put("microServiceName", microServiceName);
		parametersMap.put("serviceActivatorId", currentServiceActivatorId);
		parametersMap.put("executionTime", executionTime);
		parametersMap.put("persistenceFactories", headers.get("persistenceFactories"));
		
		return parametersMap;
	}

	private String getCurrentServiceActivatorId(Map<String, Object> headers) throws Exception {
		if (headers.containsKey(HISTORY) && headers.get(HISTORY) != null) {
			MessageHistory messageHistory = (MessageHistory) headers.get(HISTORY);
			return messageHistory.get(messageHistory.size() - 1).getProperty("name");
		} else {
			throw new Exception("Missing property in headers. Please, add the line '<ns3:message-history/>' "
					+ "to every XML orchestration configuration file to enable persistence correctly");
		}
	}

}
