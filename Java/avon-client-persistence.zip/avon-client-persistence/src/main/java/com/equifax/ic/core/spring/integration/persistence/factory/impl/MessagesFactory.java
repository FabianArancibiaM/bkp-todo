package com.equifax.ic.core.spring.integration.persistence.factory.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MessagesFactory implements Factory{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MessagesFactory.class);
	
	private final ObjectMapper objectMapper = new ObjectMapper();
	
	private List<Messages> messagesList = new ArrayList<>();
	
	public void logMessages(JsonNode messageNode, String eventType, SystemEvent systemEvent) {

		Messages message = new Messages();
		
		/* Message creation */
		try {
			message.setMessageBlob(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(messageNode));
		} catch (Exception e) {
			LOGGER.error("Failed to create message in MessagesFactory. Null blob will be persisted");
		}
		message.setEventType(eventType);
		message.setSystemEvent(systemEvent);
		addMessage(message);
	}

	@Override
	public List<Messages> getList() {
		fillSystemEventIds();
		return messagesList;
	}

	public void setMessagesList(List<Messages> messagesList) {
		this.messagesList = messagesList;
	}

	private void addMessage(Messages message) {
		getList().add(message);
	}
	
	public void fillSystemEventIds() {
		if(!messagesList.isEmpty()) {
			for(Messages message : messagesList) {
				message.setIdSystemEvent(message.getSystemEvent().getId());
			}
		}
	}
}
