package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.equifax.ic.core.spring.integration.persistence.pojo.Transaction;

import java.util.Date;

public interface TransactionDao extends CrudRepository<Transaction, Long>{
	
	@Query(value = "SELECT t FROM Transaction t WHERE t.uuid = :uuid")
    public Transaction findByUUID(@Param("uuid") String uuid);

    @Query(
            value = "SELECT * FROM (SELECT t.uuid FROM Transaction t, ChileanConsumer cs, Consumer c " +
                    "WHERE cs.id_consumer = c.id AND c.uuid = t.uuid AND cs.chileanRut = :chileanRut " +
                    "AND t.status = 'completed' AND t.cached = 0 AND t.dateCreated BETWEEN :fromDate " +
                    "AND :toDate ORDER BY t.dateCreated DESC) WHERE ROWNUM = 1",
            nativeQuery = true)
    public String findLastTransactionIdNotCachedBetweenDates(
            @Param("chileanRut") String chileanRut,
            @Param("fromDate") Date fromDate,
            @Param("toDate") Date toDate
    );
}

