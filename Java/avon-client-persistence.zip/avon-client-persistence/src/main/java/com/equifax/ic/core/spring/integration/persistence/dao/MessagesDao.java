package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import org.springframework.data.repository.query.Param;

public interface MessagesDao extends CrudRepository<Messages, Long> {

    @Query(
            value = "SELECT m.ID, m.MESSAGEBLOB, m.EVENTTYPE, m.ID_SYSTEMEVENT FROM Messages m, SystemEvent s " +
                    "WHERE s.ID = m.ID_SYSTEMEVENT AND s.DESCRIPTION = 'Transaction completion' AND s.UUID = :transactionId",
            nativeQuery = true)
    public Messages getMessageResponseByTransactionId(@Param("transactionId") String transactionId);
}
