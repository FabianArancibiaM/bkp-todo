package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.repository.CrudRepository;

import com.equifax.ic.core.spring.integration.persistence.pojo.CostaRicanConsumer;

public interface CostaRicanConsumerDao extends CrudRepository<CostaRicanConsumer, Long> {

}