package com.equifax.ic.core.spring.integration.persistence.component;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Configuration
@ConfigurationProperties
@Component
public class OrchestrationProperties {

    private Map<String, Map<String, Map<String, String>>> client;

    private Map<String, String> servicesTimeout;
   
    private Map<String, ?> persistence;

    public Map<String, Map<String, Map<String, String>>> getClient() {
        return client;
    }

    public void setClient(Map<String, Map<String, Map<String, String>>> client) {
        this.client = client;
    }

    public Map<String, String> getServicesTimeout() {
        return servicesTimeout;
    }

    public void setServicesTimeout(Map<String, String> servicesTimeout) {
        this.servicesTimeout = servicesTimeout;
    }

    public Map<String, Map<String, String>> getOrchestration() {
        return client.get("orchestration");
    }

    public void setOrchestration(Map<String, Map<String, String>> orchestration) {
        client.put("orchestration", orchestration);
    }

	public Map<String, ?> getPersistence() {
		return persistence;
	}

	public void setPersistence(Map<String, ?> persistence) {
		this.persistence = persistence;
	}

	public Map<String, Boolean> getCi() {
        return (Map<String, Boolean>) persistence.get("ci");
    }
	
    public Object getIg() {
        return persistence.get("ig");
    }
    
    public Map<String, Boolean> getSmarts() {
        return (Map<String, Boolean>) persistence.get("smarts");
    }
    
    public Map<String, Boolean> getMit() {
        return (Map<String, Boolean>) persistence.get("mit");
    }
    

}


