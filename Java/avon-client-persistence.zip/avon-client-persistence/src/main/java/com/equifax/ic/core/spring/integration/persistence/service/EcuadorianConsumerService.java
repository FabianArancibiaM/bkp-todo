package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.EcuadorianConsumer;

public interface EcuadorianConsumerService {
    void insertEcuadorianConsumer(EcuadorianConsumer ecuadorianConsumer);
}
