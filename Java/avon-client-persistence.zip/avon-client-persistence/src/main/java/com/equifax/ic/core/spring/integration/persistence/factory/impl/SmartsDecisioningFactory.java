package com.equifax.ic.core.spring.integration.persistence.factory.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.pojo.SmartsPojo;

public class SmartsDecisioningFactory implements Factory {
    
	private List<SmartsPojo> smartsPojoList = new ArrayList<>();

	public void logSmartsDecisioning(String identifier, String uuid, String decision, String description, String reasons, Integer override, String type, Date dateCreated) {
		SmartsPojo smartsPojo = new SmartsPojo();
		smartsPojo.setIdentifier(identifier);
		smartsPojo.setUuid(uuid);
		smartsPojo.setDecision(decision);
		smartsPojo.setDescription(description);
		smartsPojo.setReasons(reasons);
		smartsPojo.setOverride(override);
		smartsPojo.setType(type);
		smartsPojo.setDateCreated(dateCreated);
		addSmartsPojo(smartsPojo);
	}

	@Override
	public List<SmartsPojo> getList() {
		return smartsPojoList;
	}

	public void setSmartsPojoList(List<SmartsPojo> smartsPojoList) {
		this.smartsPojoList = smartsPojoList;
	}

	private void addSmartsPojo(SmartsPojo smartsPojo){
		getList().add(smartsPojo);
	}


}
