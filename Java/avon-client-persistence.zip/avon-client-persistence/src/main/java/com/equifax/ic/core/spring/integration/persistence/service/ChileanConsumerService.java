package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.ChileanConsumer;

public interface ChileanConsumerService {
	
	void insertChileanConsumer(ChileanConsumer chileanConsumer);
	
}
