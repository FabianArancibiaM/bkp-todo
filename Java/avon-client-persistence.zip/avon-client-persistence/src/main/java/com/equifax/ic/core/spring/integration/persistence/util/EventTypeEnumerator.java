package com.equifax.ic.core.spring.integration.persistence.util;

/**
 * 
 * @author Alan Sandoval axs831
 * @since 14-08-2018 1.0
 */
public enum EventTypeEnumerator {
	
	CI_REQUEST("CI-REQUEST"), CI_RESPONSE("CI-RESPONSE"), SMARTS_REQUEST("SMARTS-REQUEST"), SMARTS_RESPONSE("SMARTS-RESPONSE"), MIT_REQUEST("MIT-REQUEST"), 
	MIT_RESPONSE("MIT-RESPONSE"), ANAV_REQUEST("ANAV-REQUEST"), ANAV_RESPONSE("ANAV-RESPONSE");
	
	private String value;

	private EventTypeEnumerator(String s) {
		value = s;
	}

	public String getValue() {
		return value;
	}
	
}
