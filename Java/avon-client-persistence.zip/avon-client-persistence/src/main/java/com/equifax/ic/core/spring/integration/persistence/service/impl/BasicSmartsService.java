package com.equifax.ic.core.spring.integration.persistence.service.impl;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.equifax.ic.core.spring.integration.persistence.dao.SmartsDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.SmartsPojo;
import com.equifax.ic.core.spring.integration.persistence.service.SmartsService;

@Service
public class BasicSmartsService implements SmartsService {

    @Autowired
    private SmartsDao smartsDao;

    @Override
    public List<SmartsPojo> getAllSmarts() {
        return (List<SmartsPojo>) smartsDao.findAll();
    }

    @Override
    public SmartsPojo getSmartsById(Long id) {
        return smartsDao.findOne(id);
    }

    @Override
    public void insertSmarts(SmartsPojo smarts) {
        smartsDao.save(smarts);
    }

    @Override
    public SmartsPojo updateSmarts(SmartsPojo smarts) throws IOException {
        if(getSmartsById(smarts.getId()) == null){
            throw new IOException("Smarts does not exist");
        }
        return smartsDao.save(smarts);
    }
    
	@Override
	@Transactional
	public void insertList(List<?> smartsDecisioningList) {
		for (Object smartsDecisioning : smartsDecisioningList)
			smartsDao.save((SmartsPojo) smartsDecisioning);
	}
}
