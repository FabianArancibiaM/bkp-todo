package com.equifax.ic.core.spring.integration.persistence.config;

import com.equifax.ic.core.spring.integration.persistence.component.cache.CacheEvaluator;
import com.equifax.ic.core.spring.integration.persistence.component.cache.CacheExecutor;
import com.equifax.ic.core.spring.integration.persistence.service.MessagesService;
import com.equifax.ic.core.spring.integration.persistence.service.TransactionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;

@SpringBootConfiguration
public class CacheConfiguration {

    @Bean
    public CacheEvaluator cacheEvaluator(TransactionService transactionService, MessagesService messagesService, ObjectMapper objectMapper) {
        CacheEvaluator cacheEvaluator = new CacheEvaluator();
        cacheEvaluator.setTransactionService(transactionService);
        cacheEvaluator.setObjectMapper(objectMapper);
        cacheEvaluator.setMessagesService(messagesService);
        return cacheEvaluator;
    }

    @Bean
    public CacheExecutor cacheExecutor(MessagesService messagesService, ObjectMapper objectMapper) {
        CacheExecutor cacheExecutor = new CacheExecutor();
        cacheExecutor.setMessagesService(messagesService);
        cacheExecutor.setObjectMapper(objectMapper);
        return cacheExecutor;
    }

}
