package com.equifax.ic.core.spring.integration.persistence.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@ResponseStatus(value = INTERNAL_SERVER_ERROR)
public class OrchestrationCacheException extends RuntimeException {

    public OrchestrationCacheException(String message){
        super(message);
    }

    public OrchestrationCacheException(Throwable cause){
        super(cause);
    }

    public OrchestrationCacheException(String message, Throwable cause){
        super(message, cause);
    }

    public OrchestrationCacheException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace){
        super(message, cause, enableSuppression, writableStackTrace);
    }

}
