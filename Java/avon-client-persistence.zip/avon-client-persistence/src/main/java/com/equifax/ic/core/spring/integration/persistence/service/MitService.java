package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.MitPojo;

import java.io.IOException;
import java.util.List;

public interface MitService extends FactoryService {

    List<MitPojo> getAllMit();

    MitPojo getMitById(final Long id);

    void insertMit(MitPojo mit);

    MitPojo updateMit(MitPojo mit) throws IOException;
}
