package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.CostaRicanConsumer;

public interface CostaRicanConsumerService {
	
	void insertCostaRicanConsumer(CostaRicanConsumer consumer);

}