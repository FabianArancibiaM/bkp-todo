package com.equifax.ic.core.spring.integration.persistence.component.cache;

import com.equifax.ic.core.clientapi.domain.TransactionContext;
import com.equifax.ic.core.spring.integration.persistence.exception.OrchestrationCacheException;
import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import com.equifax.ic.core.spring.integration.persistence.service.MessagesService;
import com.equifax.ic.core.spring.integration.persistence.service.TransactionService;
import com.equifax.ic.core.spring.integration.persistence.util.ApplicantDomain;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * This class is responsible to evaluate if cache functionality is necessary for current chileanRut. To do this, it will
 * search if there is another transaction related to this rut within "x" number of days ago. If needed, class {@link CacheExecutor}
 * will be invoke.
 * </p>
 *
 * @author Alan Sandoval axs831
 * @since 30-07-2019 1.0
 */

public class CacheEvaluator {

    private static final Logger LOGGER = LoggerFactory.getLogger(CacheEvaluator.class);

    private static final String INITIAL_REQUEST = "INITIAL_REQUEST";
    private static final String CHILEAN_RUT_PATH = "/applicants/primaryConsumer/personalInformation/chileanRut";
    private static final String TRANSACTION_CONTEXT = "transactionContext";
    private static final String DATE_CREATED = "dateCreated";
    private static final String NOT_AVAILABLE_PATH = "/exclusionaryConditions/NotAvailable";
    private static final String ERRORS_PRESENT_PATH = "/exclusionaryConditions/ErrorsPresent";
    private static final String KPI = "equifax-cl-kpi";
    private static final String CCB = "ccb";
    private static final String PLATINUM360 = "equifax-cl-platinum360";
    private static final String DATASOURCES_ROOT_PATH = "/applicants/primaryConsumer/IG_RESPONSE/applicants/primaryConsumer";


    @Value("${cache.timeInDays:0}")
    private int cacheDays;

    private ObjectMapper objectMapper;

    private TransactionService transactionService;

    private MessagesService messagesService;

    public Boolean evaluateCache(Map<String, Object> payload, Map<String, Object> headers) {

        LOGGER.info("Evaluating cache...");

        if (cacheDays > 0) {

            JsonNode chileanRutNode;

            if (payload.containsKey(INITIAL_REQUEST) && payload.get(INITIAL_REQUEST) instanceof JsonNode) {
                JsonNode initialRequest = (JsonNode) payload.get(INITIAL_REQUEST);
                chileanRutNode = initialRequest.at(CHILEAN_RUT_PATH);
                if (chileanRutNode.isMissingNode()) {
                    throw new OrchestrationCacheException("'chileanRut' is missing from request. Cannot evaluate if use cache function or not");
                } else {
                    Date toDate = getToDate(headers);
                    String transactionIdForCache = transactionService.findLastTransactionIdNotCachedBetweenDates(chileanRutNode.asText(), getFromDate(toDate), toDate);
                    if (transactionIdForCache != null && evaluateDatasourceResponsesStatus(transactionIdForCache)) {
                        headers.put("transactionIdForCache", transactionIdForCache);
                        LOGGER.info("Cache evaluated. Executing cache functionality...");
                        return true;
                    }
                }
            } else {
                throw new OrchestrationCacheException("INITIAL_REQUEST not found in payload. CacheEvaluator failed");
            }
        }

        LOGGER.info("Cache evaluated and NOT executed. Following the normal workflow...");

        return false;
    }

    private Date getFromDate(Date toDate) {
        LocalDateTime localDateTime = toDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        localDateTime = localDateTime.minusDays(cacheDays);
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    private Date getToDate(Map<String, Object> headers) {
        TransactionContext transactionContext = getTransactionContext(headers);
        if (transactionContext == null) {
            LOGGER.warn("Current transaction not found in headers. Creating new date for 'fromDate' in cache functionality");
            return new Date();
        } else {
            if (transactionContext.containsKey(DATE_CREATED) && transactionContext.getProperty(DATE_CREATED) instanceof Date) {
                return (Date) transactionContext.getProperty(DATE_CREATED);
            } else {
                LOGGER.warn("'dateCreated' was not found in current TransactionContext. Creating new date for 'fromDate' in cache functionality");
                return new Date();
            }
        }
    }

    private TransactionContext getTransactionContext(Map<String, Object> headers) {
        if (headers.containsKey(TRANSACTION_CONTEXT) && headers.get(TRANSACTION_CONTEXT) instanceof TransactionContext) {
            return (TransactionContext) headers.get(TRANSACTION_CONTEXT);
        }

        return null;
    }

    private boolean evaluateDatasourceResponsesStatus(String transactionId) {
        Messages message = messagesService.getMessageResponseByTransactionId(transactionId);
        if (message != null) {
            try {
                JsonNode response = objectMapper.readTree(message.getMessageBlob());

                JsonNode primaryConsumerIgDatasourcesRootPath = response.at(DATASOURCES_ROOT_PATH);
                if (!primaryConsumerIgDatasourcesRootPath.isMissingNode()) {
                    if (checkSingleDSResponse(primaryConsumerIgDatasourcesRootPath.path(KPI), KPI, transactionId) &&
                            checkSingleDSResponse(primaryConsumerIgDatasourcesRootPath.path(CCB), CCB, transactionId) &&
                            checkSingleDSResponse(primaryConsumerIgDatasourcesRootPath.path(PLATINUM360), PLATINUM360, transactionId)) {

                        return true;
                    }
                }

            } catch (IOException e) {
                LOGGER.warn("Failed to convert blob message to json for transaction id {}. Cache aborted", transactionId);
            }
        } else {
            LOGGER.warn("Messsage was not found for transaction id {}. Cache aborted", transactionId);
        }

        return false;
    }

    private boolean checkSingleDSResponse(JsonNode currentDatasource, String datasourceName, String transactionId) {
        if (!currentDatasource.at(NOT_AVAILABLE_PATH).asBoolean(true) &&
                !currentDatasource.at(ERRORS_PRESENT_PATH).asBoolean(true)) {
            return true;
        } else {
            LOGGER.warn("Errors found (or missing node) in datasource '{}' for transaction id {}. Cache aborted", datasourceName, transactionId);
            return false;
        }
    }

    public int getCacheDays() {
        return cacheDays;
    }

    public void setCacheDays(int cacheDays) {
        this.cacheDays = cacheDays;
    }

    public TransactionService getTransactionService() {
        return transactionService;
    }

    public void setTransactionService(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public MessagesService getMessagesService() {
        return messagesService;
    }

    public void setMessagesService(MessagesService messagesService) {
        this.messagesService = messagesService;
    }
}
