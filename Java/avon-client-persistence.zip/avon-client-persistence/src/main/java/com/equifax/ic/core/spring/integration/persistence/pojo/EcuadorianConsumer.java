package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;

@Entity
@Table(name = "ECUADORIANCONSUMER")
public class EcuadorianConsumer {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    @SequenceGenerator(name = "SEQ", sequenceName = "ECUADORIANCONSUMER_SEQ", allocationSize = 1)
    private Long id;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ID_CONSUMER")
    private Consumer consumer;

    @Column(name = "TIPODOCUMENTO")
    private String tipoDocumento;

    @Column(name = "NUMERODOCUMENTO")
    private String numeroDocumento;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Consumer getConsumer() {
        return consumer;
    }

    public void setConsumer(Consumer consumer) {
        this.consumer = consumer;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

}
