package com.equifax.ic.core.spring.integration.persistence.service.impl;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.equifax.ic.core.spring.integration.persistence.dao.AnavDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.AnavPojo;
import com.equifax.ic.core.spring.integration.persistence.service.AnavService;

@Service
public class BasicAnavService implements AnavService {

    @Autowired
    private AnavDao anavDao;

    @Override
    @Transactional(readOnly = true)
    public List<AnavPojo> getAllAnavs() {
      return (List<AnavPojo>) anavDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public AnavPojo getAnavById(Long id) {
        return anavDao.findOne(id);
    }

    @Override
    @Transactional
    public void insertAnav(AnavPojo anav) {
        anavDao.save(anav);
    }

    @Override
    @Transactional
    public AnavPojo updateAnav(AnavPojo anav) throws IOException {
        if(getAnavById(anav.getId()) == null){
            throw new IOException("Anav does not exist");
        }
        return anavDao.save(anav);
    }
    
	@Override
	@Transactional
	public void insertList(List<?> anavAttributeAccessList) {
		for (Object anavAttributeAccess : anavAttributeAccessList)
			anavDao.save((AnavPojo) anavAttributeAccess);
		
	}
}
