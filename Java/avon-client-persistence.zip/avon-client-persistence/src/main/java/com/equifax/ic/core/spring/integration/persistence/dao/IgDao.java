package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.pojo.IgPojo;
import org.springframework.data.repository.CrudRepository;

public interface IgDao extends CrudRepository<IgPojo, Long> {
}
