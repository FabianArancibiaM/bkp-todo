package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.AnavPojo;

import java.io.IOException;
import java.util.List;

public interface AnavService extends FactoryService{

    List<AnavPojo> getAllAnavs();

    AnavPojo getAnavById(final Long id);

    void insertAnav(AnavPojo anav);

    AnavPojo updateAnav(AnavPojo anav) throws IOException;


}
