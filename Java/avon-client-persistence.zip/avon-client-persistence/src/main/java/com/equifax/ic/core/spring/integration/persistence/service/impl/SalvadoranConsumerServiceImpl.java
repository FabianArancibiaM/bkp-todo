package com.equifax.ic.core.spring.integration.persistence.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equifax.ic.core.spring.integration.persistence.dao.SalvadoranConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.SalvadoranConsumer;
import com.equifax.ic.core.spring.integration.persistence.service.SalvadoranConsumerService;

@Service
public class SalvadoranConsumerServiceImpl implements SalvadoranConsumerService {
	
	@Autowired
	private SalvadoranConsumerDao salvadoranConsumerDao;

	@Override
	@Transactional
	public void insertSalvadoranConsumer(SalvadoranConsumer consumer) {
		salvadoranConsumerDao.save(consumer);

	}

}