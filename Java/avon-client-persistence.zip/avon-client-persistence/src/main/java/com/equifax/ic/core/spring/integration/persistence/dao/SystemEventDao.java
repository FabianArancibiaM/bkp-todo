package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.repository.CrudRepository;

import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;

public interface SystemEventDao extends CrudRepository<SystemEvent, Long> {

    SystemEvent findByUuidAndDescription(String uuid, String description);

}
