package com.equifax.ic.core.spring.integration.persistence.factory.impl;

import java.util.ArrayList;
import java.util.List;

import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.pojo.MitPojo;

public class MitScoringFactory implements Factory {

    private List<MitPojo> mitPojoList = new ArrayList<>();

    public void logMitScoring(Integer finalScore, String modelId, String uuid, String applicantIdentifier) {
        MitPojo mitPojo = new MitPojo();
        mitPojo.setFinalscore(finalScore);
        mitPojo.setModelId(modelId);
        mitPojo.setUuid(uuid);
        mitPojo.setApplicantIdentifier(applicantIdentifier);
        addMitScoring(mitPojo);
    }

    @Override
    public List<MitPojo> getList() {
        return mitPojoList;
    }

    public void setMitScoringList(List<MitPojo> mitPojoList) {
        this.mitPojoList = mitPojoList;
    }

    private void addMitScoring(MitPojo mitPojo){
        getList().add(mitPojo);
    }
}
