package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.SmartsPojo;

import java.io.IOException;
import java.util.List;

public interface SmartsService extends FactoryService{

    List<SmartsPojo> getAllSmarts();

    SmartsPojo getSmartsById(final Long id);

    void insertSmarts(SmartsPojo smarts);

    SmartsPojo updateSmarts(SmartsPojo smarts) throws IOException;
}
