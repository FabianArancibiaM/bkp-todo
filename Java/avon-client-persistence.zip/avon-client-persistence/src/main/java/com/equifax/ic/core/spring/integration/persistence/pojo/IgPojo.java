package com.equifax.ic.core.spring.integration.persistence.pojo;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "IGDATASOURCEACCESS")
public class IgPojo {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    @SequenceGenerator(name = "SEQ", sequenceName = "IGDATASOURCEACCESS_SEQ", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "TRANSACTIONID")
    private String transactionId;

    @Column(name = "ORCHESTRATIONCODE")
    private String orchestration;

    @Column(name = "UUID")
    private String uuid;

    @Column(name = "APPLICANTIDENTIFIER")
    private String applicantIdentifier;

    @OneToMany(targetEntity=DataSourceBlob.class, fetch=FetchType.LAZY, mappedBy="idIgDataSourceAccess",cascade= CascadeType.ALL)
    private Set<DataSourceBlob> dataSourceBlob;

    public IgPojo(){
        this.dataSourceBlob = new HashSet<>();
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getOrchestration() {
        return orchestration;
    }

    public void setOrchestration(String orchestration) {
        this.orchestration = orchestration;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getApplicantIdentifier() {
        return applicantIdentifier;
    }

    public void setApplicantIdentifier(String applicantIdentifier) {
        this.applicantIdentifier = applicantIdentifier;
    }

    public Set<DataSourceBlob> getDataSourceBlob() {
        return dataSourceBlob;
    }

    public void setDataSourceBlob(Set<DataSourceBlob> dataSourceBlob) {
        this.dataSourceBlob = dataSourceBlob;
    }

    public void addIgDataSourceBlob(DataSourceBlob dataSourceBlob) { 
    	this.dataSourceBlob.add(dataSourceBlob); 
    }
}
