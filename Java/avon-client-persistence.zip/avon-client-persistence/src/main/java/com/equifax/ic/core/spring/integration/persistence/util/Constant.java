package com.equifax.ic.core.spring.integration.persistence.util;

public class Constant {

	public static final String ID_NUMBER = "identificationNumber";
}
