package com.equifax.ic.core.spring.integration.persistence.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.equifax.ic.core.spring.integration.persistence.dao.PeruvianConsumerDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.PeruvianConsumer;
import com.equifax.ic.core.spring.integration.persistence.service.PeruvianConsumerService;

@Service
public class PeruvianConsumerServiceImpl implements PeruvianConsumerService {

	@Autowired
	private PeruvianConsumerDao peruvianConsumerDao;
	
	@Override
	@Transactional
	public void insertPeruvianConsumer(PeruvianConsumer peruvianConsumer) {
		
		peruvianConsumerDao.save(peruvianConsumer);
		
	}

}
