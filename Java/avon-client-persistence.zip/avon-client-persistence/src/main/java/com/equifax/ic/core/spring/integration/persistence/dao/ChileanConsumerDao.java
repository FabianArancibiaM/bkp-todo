package com.equifax.ic.core.spring.integration.persistence.dao;

import org.springframework.data.repository.CrudRepository;

import com.equifax.ic.core.spring.integration.persistence.pojo.ChileanConsumer;

public interface ChileanConsumerDao extends CrudRepository<ChileanConsumer, Long>{
	
}
