package com.equifax.ic.core.spring.integration.persistence.service;

import com.equifax.ic.core.spring.integration.persistence.pojo.UruguayanConsumer;

public interface UruguayanConsumerService {

	void insertUruguayanConsumer(UruguayanConsumer uruguayanConsumer);

}
