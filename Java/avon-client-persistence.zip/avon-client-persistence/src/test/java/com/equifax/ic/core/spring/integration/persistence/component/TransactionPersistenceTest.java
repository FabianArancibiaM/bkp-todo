package com.equifax.ic.core.spring.integration.persistence.component;

import com.equifax.ic.core.spring.integration.persistence.factory.PersistenceFactories;
import com.equifax.ic.core.spring.integration.persistence.factory.impl.MessagesFactory;
import com.equifax.ic.core.spring.integration.persistence.factory.impl.SystemEventFactory;
import com.equifax.ic.core.spring.integration.persistence.pojo.EcuadorianConsumer;
import com.equifax.ic.core.spring.integration.persistence.pojo.Transaction;
import com.equifax.ic.core.spring.integration.persistence.service.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import static com.google.common.collect.Maps.newHashMap;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TransactionPersistenceTest {

    private ObjectMapper objectMapper;
    private SystemEventService systemEventService;
    private MessagesService messagesService;
    private TransactionPersistence  transactionPersistence;
    private ChileanConsumerService chileanConsumerService;
    private ArgentinianConsumerService argentinianConsumerService;
    private PeruvianConsumerService peruvianConsumerService;
    private UruguayanConsumerService uruguayanConsumerService;
    private HonduranConsumerService honduranConsumerService;
    private CostaRicanConsumerService costaRicanConsumerService;
    private SalvadoranConsumerService salvadoranConsumerService;
    private EcuadorianConsumerService ecuadorianConsumerService;
    private PersistenceFactories persistenceFactories;
    private TransactionService transactionService;
    private MicroServicesIdCollector microServicesIdCollector;
    private OrchestrationProperties orchestrationProperties;
    private Map<String, Object> headers;
    private Map<String, Object> payloadArgMap;
    private Map<String, Object> payloadUyMap;
    private Map<String, Object> payloadClMap;
    private Map<String, Object> payloadPeMap;
    private Map<String, Object> payloadHNMap;
    private Map<String, Object> payloadCRMap;
    private Map<String, Object> payloadSVMap;
    private Map<String, Object> payloadEcuMap;
    private String payloadArg = "{\"applicants\":{\"primaryConsumer\":{\"personalInformation\":{\"name\":[{\"identifier\":\"current\",\"name\":\"JOSE NESTOR\",\"lastName\":\"GUERRERO\"}],\"dni\":\"172108644\",\"matriz\":\"VN5557\",\"addresses\":[{\"identifier\":\"Current\"}],\"gender\":\"M\",\"reference\":\"367226900\",\"userName\":\"Administrador\",\"customerReferenceIdentifier\":\"ICFLEXARG\"},\"codigo_validacion_documento\":\"9\",\"ingresos_liquidos\":\"\",\"antiguedad_laboral\":\"\",\"situacion_laboral\":\"\",\"estado_civil\":\"\",\"cliente_entidad\":\"\",\"expensas_alquiler\":\"\",\"familia\":\"\",\"obra_social\":\"\",\"prestamos_personales\":\"\",\"prestamos_hipotecarios\":\"\",\"prestamos_prendarios\":\"\",\"consumos_tarjetas_credito\":\"\",\"gastos_totales\":\"\",\"producto_solicitado\":\"\",\"edad\":0,\"pp_monto_solicitado\":0,\"pp_cuota_solicitado\":0,\"pp_plazo_solicitado\":0,\"pp_tasa_solicitado\":\"\",\"pp_destino\":\"\",\"pr_monto_solicitado\":6,\"pr_cuota_solicitado\":0,\"pr_plazo_solicitado\":0,\"pr_tasa_solicitado\":\"\",\"pr_destino\":\"\",\"tj_tipo_solicitado\":\"\",\"tj_marca_solicitado\":\"\",\"tj_limite_solicitado\":0,\"tj_limite_cuotas_solicitado\":0,\"pedido_documentacion\":\"\"}}}";
    private String payloadPe = "{\"applicants\": {\"primaryConsumer\": {\"personalInformation\": {\"name\": [{\"identifier\": \"current\"}],\"peruIdType\": \"6\", \"peruIdNumber\":\"20448439942\", \"userName\":\"Administrador\",\"addresses\": [{\"identifier\": \"Current\"}],\"customerReferenceIdentifier\": \"IGCCBERROR\"}}}}";
    private String payloadCl = "{\"applicants\": {\"primaryConsumer\": {\"personalInformation\": {\"name\": [{\"identifier\": \"current\"}],\"chileanRut\": \"155258446\", \"chileanSerialNumber\":\"A0000000001\", \"userName\":\"Administrador\",\"addresses\": [{\"identifier\": \"Current\"}],\"customerReferenceIdentifier\": \"IGCCBERROR\"}}}}";
    private String payloadUy = "{\"applicants\":{\"primaryConsumer\":{\"personalInformation\":{\"name\":[{\"identifier\":\"current\",\"name\":\"JOSE NESTOR\",\"lastName\":\"GUERRERO\"}],\"documento\":\"172108644\",\"matriz\":\"VN5557\",\"addresses\":[{\"identifier\":\"Current\"}],\"afiliado\":\"5789\",\"gender\":\"M\",\"ficha\":\"367226900\",\"userName\":\"Administrador\",\"customerReferenceIdentifier\":\"ICFLEXURY\"},\"codigo_validacion_documento\":\"1\",\"edad\":\"0\",\"tipo_solicitud\":\"\",\"control_flujo_decision\":\"\",\"tipo_ficha\":\"\",\"ingresos_liquidos\":0,\"deudas_liquidas\":0,\"antiguedad_laboral\":0,\"situacion_laboral\":\"\",\"estado_civil\":\"\",\"cliente_entidad\":\"\",\"producto_solicitado\":\"\",\"pp_monto_solicitado\":0,\"pp_cuota_solicitado\":0,\"pp_plazo_solicitado\":0,\"pp_tasa_solicitado\":0,\"pp_destino\":0,\"pr_monto_solicitado\":0,\"pr_cuota_solicitado\":0,\"pr_plazo_solicitado\":0,\"pr_tasa_solicitado\":0,\"tj_tipo_solicitado\":\"\",\"tj_marca_solicitado\":\"\",\"tj_limite_solicitado\":0,\"tj_limite_cuotas_solicitado\":0,\"pedido_documentaci\u00F3n\":\"\",\"validacion_del_documento\":\"\",\"ingresos_unificados\":\"\",\"deudas_unificadas\":\"\"}}}";
    private String payloadEcu = "{ \"applicants\": { \"primaryConsumer\": { \"personalInformation\": { \"numeroDocumento\": \"61387404\", \"tipoDocumento\": \"C\", \"modelname\":\"ECU_MODELO_CHEQUES\", \"modelversion\":\"V1_0_51\", \"tipoDocumentoConyugue\":\"C\", \"numeroDocumentoConyugue\":\"1717170110\", \"username\":\"username\", \"userid\":\"12345\", \"reportid\":\"85\", \"usersector\":\"Financial\", \"id_transaction\":\"41235116\", \"customername\":\"BANCO DEL PICHINCHA\", \"customerid\":\"406\" } } } }";
    private Map<String, Map<String, String>> orchestrations;
    private Map<String, String> currentOrchestrationParameters;
    private Map<String, Boolean> persistenceParameters;

    @Before
    public void setUp() throws IOException {

        orchestrations = new LinkedHashMap<>();
        persistenceParameters = new LinkedHashMap<>();
        persistenceParameters.put("consumer", true);
   	 	persistenceParameters.put("message", true);
        currentOrchestrationParameters = new LinkedHashMap<>();
        orchestrations.put("HOGARDTH", currentOrchestrationParameters);
        objectMapper = new ObjectMapper();
        transactionPersistence = new TransactionPersistence();
        chileanConsumerService = mock(ChileanConsumerService.class);
        argentinianConsumerService = mock(ArgentinianConsumerService.class);
        peruvianConsumerService = mock(PeruvianConsumerService.class);
        uruguayanConsumerService = mock(UruguayanConsumerService.class);
        honduranConsumerService = mock(HonduranConsumerService.class);
        costaRicanConsumerService = mock(CostaRicanConsumerService.class);
        salvadoranConsumerService = mock(SalvadoranConsumerService.class);
        ecuadorianConsumerService = mock(EcuadorianConsumerService.class);
        transactionService = mock(TransactionService.class);
        systemEventService = mock(SystemEventService.class);
        messagesService = mock(MessagesService.class);
        persistenceFactories = mock(PersistenceFactories.class);
        orchestrationProperties = mock(OrchestrationProperties.class);
        microServicesIdCollector = mock(MicroServicesIdCollector.class);
        configurePayload();
        configureHeader();
    }

    @Test
    public void persistCiRequestArgentina(){

        ReflectionTestUtils.setField(this.transactionPersistence,"argentinianConsumerService", this.argentinianConsumerService);
        ReflectionTestUtils.setField(this.transactionPersistence,"systemEventService", this.systemEventService);
        ReflectionTestUtils.setField(this.transactionPersistence,"messagesService", this.messagesService);
        ReflectionTestUtils.setField(this.transactionPersistence,"transactionService", this.transactionService);
        ReflectionTestUtils.setField(this.transactionPersistence,"objectMapper", this.objectMapper);
        ReflectionTestUtils.setField(this.transactionPersistence,"orchestrationProperties", this.orchestrationProperties);
        ReflectionTestUtils.setField(this.transactionPersistence,"microServicesIdCollector", this.microServicesIdCollector);

        doNothing().when(argentinianConsumerService).insertArgentinianConsumer(Mockito.anyObject());
        doNothing().when(systemEventService).saveNewSystemEvent(Mockito.anyObject());
        doNothing().when(messagesService).saveNewMessage(Mockito.anyObject());
        doNothing().when(transactionService).insertTransaction(Mockito.anyObject());

        try {
            currentOrchestrationParameters.put("country", "arg");
            when(orchestrationProperties.getOrchestration()).thenReturn(orchestrations);
            when(orchestrationProperties.getCi()).thenReturn(persistenceParameters);

            transactionPersistence.persistCiRequest(payloadArgMap, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   @Test
    public void persistCiRequestUruguay(){

        ReflectionTestUtils.setField(this.transactionPersistence,"uruguayanConsumerService", this.uruguayanConsumerService);
        ReflectionTestUtils.setField(this.transactionPersistence,"systemEventService", this.systemEventService);
        ReflectionTestUtils.setField(this.transactionPersistence,"messagesService", this.messagesService);
        ReflectionTestUtils.setField(this.transactionPersistence,"transactionService", this.transactionService);
        ReflectionTestUtils.setField(this.transactionPersistence,"objectMapper", this.objectMapper);
        ReflectionTestUtils.setField(this.transactionPersistence,"orchestrationProperties", this.orchestrationProperties);
        ReflectionTestUtils.setField(this.transactionPersistence,"microServicesIdCollector", this.microServicesIdCollector);

        doNothing().when(uruguayanConsumerService).insertUruguayanConsumer(Mockito.anyObject());
        doNothing().when(systemEventService).saveNewSystemEvent(Mockito.anyObject());
        doNothing().when(messagesService).saveNewMessage(Mockito.anyObject());
        doNothing().when(transactionService).insertTransaction(Mockito.anyObject());

       try {
           currentOrchestrationParameters.put("country", "ury");
           when(orchestrationProperties.getOrchestration()).thenReturn(orchestrations);
           when(orchestrationProperties.getCi()).thenReturn(persistenceParameters);

            transactionPersistence.persistCiRequest(payloadUyMap, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void persistCiRequestPeru(){

        ReflectionTestUtils.setField(this.transactionPersistence,"peruvianConsumerService", this.peruvianConsumerService);
        ReflectionTestUtils.setField(this.transactionPersistence,"systemEventService", this.systemEventService);
        ReflectionTestUtils.setField(this.transactionPersistence,"messagesService", this.messagesService);
        ReflectionTestUtils.setField(this.transactionPersistence,"transactionService", this.transactionService);
        ReflectionTestUtils.setField(this.transactionPersistence,"objectMapper", this.objectMapper);
        ReflectionTestUtils.setField(this.transactionPersistence,"orchestrationProperties", this.orchestrationProperties);
        ReflectionTestUtils.setField(this.transactionPersistence,"microServicesIdCollector", this.microServicesIdCollector);

        doNothing().when(peruvianConsumerService).insertPeruvianConsumer(Mockito.anyObject());
        doNothing().when(systemEventService).saveNewSystemEvent(Mockito.anyObject());
        doNothing().when(messagesService).saveNewMessage(Mockito.anyObject());
        doNothing().when(transactionService).insertTransaction(Mockito.anyObject());


        try {
        	when(orchestrationProperties.getCi()).thenReturn(persistenceParameters);
            currentOrchestrationParameters.put("country", "per");
            when(orchestrationProperties.getOrchestration()).thenReturn(orchestrations);
            transactionPersistence.persistCiRequest(payloadPeMap, headers);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

     @Test
    public void persistCiRequestChile() {
    	 
         ReflectionTestUtils.setField(this.transactionPersistence,"chileanConsumerService", this.chileanConsumerService);
         ReflectionTestUtils.setField(this.transactionPersistence,"systemEventService", this.systemEventService);
         ReflectionTestUtils.setField(this.transactionPersistence,"messagesService", this.messagesService);
         ReflectionTestUtils.setField(this.transactionPersistence,"transactionService", this.transactionService);
         ReflectionTestUtils.setField(this.transactionPersistence,"objectMapper", this.objectMapper);
         ReflectionTestUtils.setField(this.transactionPersistence,"orchestrationProperties", this.orchestrationProperties);
         ReflectionTestUtils.setField(this.transactionPersistence,"microServicesIdCollector", this.microServicesIdCollector);
         
         
         doNothing().when(chileanConsumerService).insertChileanConsumer(Mockito.anyObject());
         doNothing().when(systemEventService).saveNewSystemEvent(Mockito.anyObject());
         doNothing().when(messagesService).saveNewMessage(Mockito.anyObject());
         doNothing().when(transactionService).insertTransaction(Mockito.anyObject());
         
         try {
             currentOrchestrationParameters.put("country", "cl");
             when(orchestrationProperties.getOrchestration()).thenReturn(orchestrations);
             when(orchestrationProperties.getCi()).thenReturn(persistenceParameters);
             
             transactionPersistence.persistCiRequest(payloadClMap, headers);
         } catch (Exception e) {
             e.printStackTrace();
         }

     }

    @Test(expected = Exception.class)
    public void persistCiRequestChileNullEndPointCIMap() throws Exception {

        Map<String, Object> transactionContext = new LinkedHashMap<>();
        transactionContext.put("organizationCode", "CLAROCHILE");
        transactionContext.put("configurationId", "configclaro");
        transactionContext.put("baselineId", "initialbaseline");
        transactionContext.put("orchestration", "HOGARDTH");
        Map headers = newHashMap();
        headers.put("transactionId", "Test");
        headers.put("transactionContext", transactionContext);
        headers.put("persistenceFactories", persistenceFactories);

        ReflectionTestUtils.setField(this.transactionPersistence, "chileanConsumerService", this.chileanConsumerService);
        ReflectionTestUtils.setField(this.transactionPersistence, "systemEventService", this.systemEventService);
        ReflectionTestUtils.setField(this.transactionPersistence, "messagesService", this.messagesService);
        ReflectionTestUtils.setField(this.transactionPersistence, "transactionService", this.transactionService);
        ReflectionTestUtils.setField(this.transactionPersistence, "objectMapper", this.objectMapper);
        ReflectionTestUtils.setField(this.transactionPersistence, "orchestrationProperties", this.orchestrationProperties);
        ReflectionTestUtils.setField(this.transactionPersistence, "microServicesIdCollector", this.microServicesIdCollector);

        doNothing().when(chileanConsumerService).insertChileanConsumer(Mockito.anyObject());
        doNothing().when(systemEventService).saveNewSystemEvent(Mockito.anyObject());
        doNothing().when(messagesService).saveNewMessage(Mockito.anyObject());
        doNothing().when(transactionService).insertTransaction(Mockito.anyObject());


        currentOrchestrationParameters.put("country", "cl");
        when(orchestrationProperties.getOrchestration()).thenReturn(orchestrations);
        transactionPersistence.persistCiRequest(payloadClMap, headers);

    }

    @Test
    public void persistCiRequestEcuador(){

        ReflectionTestUtils.setField(this.transactionPersistence,"ecuadorianConsumerService", this.ecuadorianConsumerService);
        ReflectionTestUtils.setField(this.transactionPersistence,"systemEventService", this.systemEventService);
        ReflectionTestUtils.setField(this.transactionPersistence,"messagesService", this.messagesService);
        ReflectionTestUtils.setField(this.transactionPersistence,"transactionService", this.transactionService);
        ReflectionTestUtils.setField(this.transactionPersistence,"objectMapper", this.objectMapper);
        ReflectionTestUtils.setField(this.transactionPersistence,"orchestrationProperties", this.orchestrationProperties);
        ReflectionTestUtils.setField(this.transactionPersistence,"microServicesIdCollector", this.microServicesIdCollector);

        doNothing().when(ecuadorianConsumerService).insertEcuadorianConsumer(Mockito.anyObject());
        doNothing().when(systemEventService).saveNewSystemEvent(Mockito.anyObject());
        doNothing().when(messagesService).saveNewMessage(Mockito.anyObject());
        doNothing().when(transactionService).insertTransaction(Mockito.anyObject());

        try {
            currentOrchestrationParameters.put("country", "ecu");
            when(orchestrationProperties.getOrchestration()).thenReturn(orchestrations);
            when(orchestrationProperties.getCi()).thenReturn(persistenceParameters);

            transactionPersistence.persistCiRequest(payloadEcuMap, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test
     public void persistCiResponse(){

         try {

             ReflectionTestUtils.setField(this.transactionPersistence,"transactionService", this.transactionService);
             ReflectionTestUtils.setField(this.transactionPersistence,"systemEventService", this.systemEventService);
             ReflectionTestUtils.setField(this.transactionPersistence,"objectMapper", this.objectMapper);

             when((transactionService.findTransactionById(Mockito.anyString()))).thenReturn(new Transaction());
             when(transactionService.updateTransaction(Mockito.anyObject())).thenReturn(new Transaction());
             when(persistenceFactories.getFactory(SystemEventFactory.class)).thenReturn(new SystemEventFactory());
             when(persistenceFactories.getFactory(MessagesFactory.class)).thenReturn(new MessagesFactory());
             when(systemEventService.findByUuidAndDescription(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
             doNothing().when(persistenceFactories).flushFactories();

             transactionPersistence.persistCiResponse(payloadArgMap, headers, new Transaction());
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

    private void configureHeader() {

        Map<String, Object> transactionContext = new LinkedHashMap<>();
        transactionContext.put("organizationCode", "CLAROCHILE");
        transactionContext.put("configurationId", "configclaro");
        transactionContext.put("baselineId","initialbaseline");
        transactionContext.put("orchestration","HOGARDTH");
        headers = newHashMap();
        headers.put("transactionId", "Test");
        headers.put("transactionContext", transactionContext);
        headers.put("persistenceFactories", persistenceFactories);
        headers.put("clientImplementationEndPoint","/clinicabicentenario-client-implementation/api/transaction/HOGARDTH/config/baseline/TEST");
    }


    private void configurePayload() throws IOException {

        payloadArgMap = newHashMap();
        ObjectNode payloadArJson = new ObjectMapper().readValue(payloadArg, ObjectNode.class);
        payloadArgMap.put("INITIAL_REQUEST", payloadArJson);

        payloadUyMap = newHashMap();
        ObjectNode payloadUyJson = new ObjectMapper().readValue(payloadUy, ObjectNode.class);
        payloadUyMap.put("INITIAL_REQUEST", payloadUyJson);

        payloadClMap = newHashMap();
        ObjectNode payloadClJson = new ObjectMapper().readValue(payloadCl, ObjectNode.class);
        payloadClMap.put("INITIAL_REQUEST", payloadClJson);

        payloadPeMap = newHashMap();
        ObjectNode payloadPeJson = new ObjectMapper().readValue(payloadPe, ObjectNode.class);
        payloadPeMap.put("INITIAL_REQUEST", payloadPeJson);

        payloadEcuMap = newHashMap();
        ObjectNode payloadEcuJson = new ObjectMapper().readValue(payloadEcu, ObjectNode.class);
        payloadEcuMap.put("INITIAL_REQUEST", payloadEcuJson);


    }
    
    @Test
    public void persistHonduranConsumer() {
    	ReflectionTestUtils.setField(this.transactionPersistence,"honduranConsumerService", this.honduranConsumerService);
        ReflectionTestUtils.setField(this.transactionPersistence,"systemEventService", this.systemEventService);
        ReflectionTestUtils.setField(this.transactionPersistence,"messagesService", this.messagesService);
        ReflectionTestUtils.setField(this.transactionPersistence,"transactionService", this.transactionService);
        ReflectionTestUtils.setField(this.transactionPersistence,"objectMapper", this.objectMapper);
        ReflectionTestUtils.setField(this.transactionPersistence,"orchestrationProperties", this.orchestrationProperties);
        ReflectionTestUtils.setField(this.transactionPersistence,"microServicesIdCollector", this.microServicesIdCollector);

        doNothing().when(honduranConsumerService).insertHonduranConsumer(Mockito.anyObject());
        doNothing().when(systemEventService).saveNewSystemEvent(Mockito.anyObject());
        doNothing().when(messagesService).saveNewMessage(Mockito.anyObject());
        doNothing().when(transactionService).insertTransaction(Mockito.anyObject());

        try {
            currentOrchestrationParameters.put("country", "hn");
            when(orchestrationProperties.getOrchestration()).thenReturn(orchestrations);
            when(orchestrationProperties.getCi()).thenReturn(persistenceParameters);

            transactionPersistence.persistCiRequest(payloadHNMap, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    	
    }
    
    @Test
    public void persistCostaRicanConsumer() {
    	ReflectionTestUtils.setField(this.transactionPersistence,"costaRicanConsumerService", this.costaRicanConsumerService);
        ReflectionTestUtils.setField(this.transactionPersistence,"systemEventService", this.systemEventService);
        ReflectionTestUtils.setField(this.transactionPersistence,"messagesService", this.messagesService);
        ReflectionTestUtils.setField(this.transactionPersistence,"transactionService", this.transactionService);
        ReflectionTestUtils.setField(this.transactionPersistence,"objectMapper", this.objectMapper);
        ReflectionTestUtils.setField(this.transactionPersistence,"orchestrationProperties", this.orchestrationProperties);
        ReflectionTestUtils.setField(this.transactionPersistence,"microServicesIdCollector", this.microServicesIdCollector);

        doNothing().when(costaRicanConsumerService).insertCostaRicanConsumer(Mockito.anyObject());
        doNothing().when(systemEventService).saveNewSystemEvent(Mockito.anyObject());
        doNothing().when(messagesService).saveNewMessage(Mockito.anyObject());
        doNothing().when(transactionService).insertTransaction(Mockito.anyObject());

        try {
            currentOrchestrationParameters.put("country", "cr");
            when(orchestrationProperties.getOrchestration()).thenReturn(orchestrations);
            when(orchestrationProperties.getCi()).thenReturn(persistenceParameters);

            transactionPersistence.persistCiRequest(payloadCRMap, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    	
    }
    
    @Test
    public void persistSalvadoranConsumer() {
    	ReflectionTestUtils.setField(this.transactionPersistence,"salvadoranConsumerService", this.salvadoranConsumerService);
        ReflectionTestUtils.setField(this.transactionPersistence,"systemEventService", this.systemEventService);
        ReflectionTestUtils.setField(this.transactionPersistence,"messagesService", this.messagesService);
        ReflectionTestUtils.setField(this.transactionPersistence,"transactionService", this.transactionService);
        ReflectionTestUtils.setField(this.transactionPersistence,"objectMapper", this.objectMapper);
        ReflectionTestUtils.setField(this.transactionPersistence,"orchestrationProperties", this.orchestrationProperties);
        ReflectionTestUtils.setField(this.transactionPersistence,"microServicesIdCollector", this.microServicesIdCollector);

        doNothing().when(salvadoranConsumerService).insertSalvadoranConsumer(Mockito.anyObject());
        doNothing().when(systemEventService).saveNewSystemEvent(Mockito.anyObject());
        doNothing().when(messagesService).saveNewMessage(Mockito.anyObject());
        doNothing().when(transactionService).insertTransaction(Mockito.anyObject());

        try {
            currentOrchestrationParameters.put("country", "sv");
            when(orchestrationProperties.getOrchestration()).thenReturn(orchestrations);
            when(orchestrationProperties.getCi()).thenReturn(persistenceParameters);

            transactionPersistence.persistCiRequest(payloadSVMap, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    	
    }
}