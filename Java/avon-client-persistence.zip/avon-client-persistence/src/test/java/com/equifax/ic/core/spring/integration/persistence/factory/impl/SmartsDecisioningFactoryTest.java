package com.equifax.ic.core.spring.integration.persistence.factory.impl;

import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import com.equifax.ic.core.spring.integration.persistence.pojo.SmartsPojo;

public class SmartsDecisioningFactoryTest {

    private SmartsDecisioningFactory smartsDecisioningFactory;
    private List<SmartsPojo> smartsPojoList;

    @Before
    public void setUp() throws Exception {
        smartsDecisioningFactory = new SmartsDecisioningFactory();
        smartsPojoList = new ArrayList<>();
    }

    @Test
    public void logSmartsDecisioning() {
        smartsDecisioningFactory.logSmartsDecisioning("", "", "", "", "", null, "", null);
    }

    @Test
    public void getList() {
        ReflectionTestUtils.setField(this.smartsDecisioningFactory, "smartsPojoList", this.smartsPojoList);
        smartsDecisioningFactory.getList();
    }

    @Test
    public void setSmartsPojoList() {
        ReflectionTestUtils.setField(this.smartsDecisioningFactory, "smartsPojoList", this.smartsPojoList);
        smartsDecisioningFactory.setSmartsPojoList(new LinkedList<>());
    }
}