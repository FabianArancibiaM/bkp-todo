package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.SmartsDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.SmartsPojo;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BasicSmartsServiceTest {

    private BasicSmartsService basicSmartsService;
    private SmartsDao smartsDao;

    @Before
    public void setUp(){
        basicSmartsService = new BasicSmartsService();
        smartsDao = mock(SmartsDao.class);
    }

    @Test
    public void getAllSmarts() {
        ReflectionTestUtils.setField(this.basicSmartsService,"smartsDao", this.smartsDao);
        when(smartsDao.findAll()).thenReturn(new LinkedList<>());
        basicSmartsService.getAllSmarts();
    }

    @Test
    public void getSmartsById() {
        ReflectionTestUtils.setField(this.basicSmartsService,"smartsDao", this.smartsDao);
        when(smartsDao.findOne(Mockito.anyLong())).thenReturn(new SmartsPojo());
        basicSmartsService.getSmartsById((Mockito.anyLong()));
    }

    @Test
    public void insertSmarts() {
        ReflectionTestUtils.setField(this.basicSmartsService,"smartsDao", this.smartsDao);
        when(smartsDao.save(Mockito.any(SmartsPojo.class))).thenReturn(new SmartsPojo());
        basicSmartsService.insertSmarts(new SmartsPojo());
    }

    @Test
    public void updateSmarts() {
        ReflectionTestUtils.setField(this.basicSmartsService,"smartsDao", this.smartsDao);
        when(smartsDao.save(Mockito.any(SmartsPojo.class))).thenReturn(new SmartsPojo());
        when(basicSmartsService.getSmartsById(Mockito.anyLong())).thenReturn(new SmartsPojo());
        try {
            basicSmartsService.updateSmarts((new SmartsPojo()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void insertList() {
        List<SmartsPojo> smartsDecisioningList= new ArrayList();
        smartsDecisioningList.add(new SmartsPojo());

        ReflectionTestUtils.setField(this.basicSmartsService,"smartsDao", this.smartsDao);
        when(smartsDao.save(Mockito.any(SmartsPojo.class))).thenReturn(new SmartsPojo());
        basicSmartsService.insertList(smartsDecisioningList);

    }
}