package com.equifax.ic.core.spring.integration.persistence.component;

import com.equifax.ic.core.spring.integration.persistence.exception.OrchestrationBadRequestException;
import org.junit.Before;
import org.junit.Test;

public class RequestValidatorTest {

    private String successRequest;

    private String requestWithoutPersonalInformation;

    private String requestWithConsumersInInvalidOrder;

    private String requestWithInvalidApplicantsKey;


    @Before
    public void before() {
        this.successRequest = "{\n" +
                "    \"applicants\": {\n" +
                "        \"primaryConsumer\": {\n" +
                "            \"personalInformation\": {\n" +
                "                \"chileanRut\": \"184566362\",\n" +
                "                \"chileanSerialNumber\": \"A000000002\",\n" +
                "                \"userName\": \"test\"\n" +
                "            }\n" +
                "        },\n" +
                "        \"secondaryConsumer\": {\n" +
                "            \"personalInformation\": {\n" +
                "                \"chileanRut\": \"184566362\",\n" +
                "                \"chileanSerialNumber\": \"A000000002\",\n" +
                "                \"userName\": \"test\"\n" +
                "            }\n" +
                "        },\n" +
                "        \"thirdConsumer\": {\n" +
                "            \"personalInformation\": {\n" +
                "               \"chileanRut\": \"184566362\",\n" +
                "               \"chileanSerialNumber\": \"A000000002\",\n" +
                "               \"userName\": \"test\"\n" +
                "           }\n" +
                "        }\n" +
                "    }\n" +
                "}";

        this.requestWithConsumersInInvalidOrder = "{\n" +
                "    \"applicants\": {\n" +
                "        \"primaryConsumer\": {\n" +
                "            \"personalInformation\": {\n" +
                "                \"chileanRut\": \"184566362\",\n" +
                "                \"chileanSerialNumber\": \"A000000002\"\n" +
                "            }\n" +
                "        },\n" +
                "        \"fifthConsumer\": {\n" +
                "            \"personalInformation\": {\n" +
                "                \"chileanRut\": \"184566362\",\n" +
                "                \"chileanSerialNumber\": \"A000000002\"\n" +
                "            }\n" +
                "        },\n" +
                "        \"thirdConsumer\": {\n" +
                "            \"personalInformation\": {}\n" +
                "        }\n" +
                "    }\n" +
                "}";

        this.requestWithoutPersonalInformation = "{\n" +
                "    \"applicants\": {\n" +
                "        \"primaryConsumer\": {\n" +
                "            \"personalInformation\": {\n" +
                "                \"chileanRut\": \"184566362\",\n" +
                "                \"chileanSerialNumber\": \"A000000002\"\n" +
                "            }\n" +
                "        },\n" +
                "        \"secondaryConsumer\": {\n" +
                "            \"personalInformation\": {\n" +
                "                \"chileanRut\": \"184566362\",\n" +
                "                \"chileanSerialNumber\": \"A000000002\"\n" +
                "            }\n" +
                "        },\n" +
                "        \"thirdConsumer\": {\n" +
                "            \"invalidPersonalInformation\": {}\n" +
                "        }\n" +
                "    }\n" +
                "}";

        this.requestWithInvalidApplicantsKey = "{\n" +
                "    \"invalidApplicants\": {\n" +
                "        \"primaryConsumer\": {\n" +
                "            \"personalInformation\": {\n" +
                "                \"chileanRut\": \"184566362\",\n" +
                "                \"chileanSerialNumber\": \"A000000002\"\n" +
                "            }\n" +
                "        },\n" +
                "        \"secondaryConsumer\": {\n" +
                "            \"personalInformation\": {\n" +
                "                \"chileanRut\": \"184566362\",\n" +
                "                \"chileanSerialNumber\": \"A000000002\"\n" +
                "            }\n" +
                "        },\n" +
                "        \"thirdConsumer\": {\n" +
                "            \"personalInformation\": {}\n" +
                "        }\n" +
                "    }\n" +
                "}";
    }

    @Test
    public void validateRequestTest() throws Exception {
        RequestValidator.validateRequest(successRequest);
    }

    @Test(expected = OrchestrationBadRequestException.class)
    public void requestWithConsumersInInvalidOrderTest() throws Exception {
        RequestValidator.validateRequest(requestWithConsumersInInvalidOrder);
    }

    @Test(expected = OrchestrationBadRequestException.class)
    public void requestWithoutPersonalInformationTest() throws Exception {
        RequestValidator.validateRequest(requestWithoutPersonalInformation);
    }

    @Test(expected = OrchestrationBadRequestException.class)
    public void requestWithInvalidApplicantsKeyTest() throws Exception {
        RequestValidator.validateRequest(requestWithInvalidApplicantsKey);
    }

}
