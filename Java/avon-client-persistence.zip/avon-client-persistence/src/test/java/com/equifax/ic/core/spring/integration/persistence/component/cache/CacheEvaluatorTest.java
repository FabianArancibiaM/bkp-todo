package com.equifax.ic.core.spring.integration.persistence.component.cache;

import com.equifax.ic.core.clientapi.domain.TransactionContext;
import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import com.equifax.ic.core.spring.integration.persistence.service.MessagesService;
import com.equifax.ic.core.spring.integration.persistence.service.TransactionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CacheEvaluatorTest {

    private CacheEvaluator cacheEvaluator = new CacheEvaluator();
    private Map<String, Object> headers = new LinkedHashMap<>();
    private Map<String, Object> payload = new LinkedHashMap<>();
    private String correctResponse;
    private String badResponse1;
    private String badResponse2;
    private String missingDatasource;

    @Before
    public void setUp() throws Exception {
        cacheEvaluator.setTransactionService(mock(TransactionService.class));
        cacheEvaluator.setMessagesService(mock(MessagesService.class));
        cacheEvaluator.setObjectMapper(new ObjectMapper());
        cacheEvaluator.setCacheDays(5);

        TransactionContext transactionContext = new TransactionContext();
        transactionContext.addProperty("dateCreated", new Date());
        headers.put("transactionContext", transactionContext);

        String initialRequest = "{\"applicants\":{\"primaryConsumer\":{\"personalInformation\":{\"chileanRut\":\"184566362\"}}}}";
        badResponse1 = "{\"clientImplementationStatus\":\"completed\",\"applicants\":{\"primaryConsumer\":{\"IG_RESPONSE\":{\"transactionId\":\"112712000000010006\",\"status\":\"completed\",\"applicants\":{\"primaryConsumer\":{\"personalInformation\":{\"chileanRut\":\"177056715\",\"chileanSerialNumber\":\"A000000002\"},\"equifax-cl-kpi\":{\"KPI\":{\"status\":500,\"DescriptionResponse\":\"The variable KPI KPI_IND_INTERDICTO Don't has value from the datasource\"},\"exclusionaryConditions\":{\"NotAvailable\":false,\"ErrorsPresent\":true},\"returnedProducts\":[\"KPI\"]},\"ccb\":{\"ccb\":{\"uuid\":\"6ecf7d4e-26b9-4c8d-9b4c-6b954745caf0\",\"transactionInfo\":null,\"errors\":{\"code\":\"8005: Invalid Password\",\"message\":\"\"}},\"exclusionaryConditions\":{\"ErrorsPresent\":true,\"NoHit\":false,\"NotAvailable\":false},\"nativeText\":null,\"returnedProducts\":null},\"equifax-cl-platinum360\":{\"platinum360\":{\"errors\":[{\"message\":\"I/O error on POST request for \\\"http://172.23.123.218/osb-efx/equifax/Platinum360Passenger\\\": Read timed out; nested exception is java.net.SocketTimeoutException: Read timed out\",\"category\":\"503\",\"errorType\":\"UNV\"}]},\"exclusionaryConditions\":{\"NotAvailable\":true,\"ErrorsPresent\":false},\"returnedProducts\":[\"platinum360\"]}}}}}},\"clientImplementationUUID\":\"a4d124d4-9e83-466e-bb04-d2e62a7f7074\",\"clientImplementationDateCreated\":\"2019-05-27T18:15:34.303+0000\",\"clientImplementationDateModified\":null}";
        badResponse2 = "{\"clientImplementationStatus\":\"completed\",\"applicants\":{\"primaryConsumer\":{\"IG_RESPONSE\":{\"transactionId\":\"112712000000030008\",\"status\":\"completed\",\"applicants\":{\"primaryConsumer\":{\"personalInformation\":{\"chileanRut\":\"147028431\",\"chileanSerialNumber\":\"A000000002\"},\"equifax-cl-kpi\":{\"KPI\":{\"kpiSection\":{\"attributes\":[{\"variableName\":\"KPI_NEG_AVON\",\"value\":\"1\"}]}},\"exclusionaryConditions\":{\"NotAvailable\":false,\"ErrorsPresent\":false},\"returnedProducts\":[\"KPI\"]},\"ccb\":{\"ccb\":{\"uuid\":\"6ecf7d4e-26b9-4c8d-9b4c-6b954745caf0\",\"transactionInfo\":null,\"errors\":{\"code\":\"8005: Invalid Password\",\"message\":\"\"}},\"exclusionaryConditions\":{\"ErrorsPresent\":true,\"NoHit\":false,\"NotAvailable\":false},\"nativeText\":null,\"returnedProducts\":null},\"equifax-cl-platinum360\":{\"platinum360\":{\"getInformePlatinum360Response\":{}},\"exclusionaryConditions\":{\"NotAvailable\":false,\"ErrorsPresent\":false},\"returnedProducts\":[\"platinum360\"]}}}}}},\"clientImplementationUUID\":\"2791e58f-25b4-4d77-8d82-20fa3eb81a9e\",\"clientImplementationDateCreated\":\"2019-05-30T15:00:40.060+0000\",\"clientImplementationDateModified\":null}";
        missingDatasource = "{\"clientImplementationStatus\":\"completed\",\"applicants\":{\"primaryConsumer\":{\"IG_RESPONSE\":{\"transactionId\":\"112712000000030008\",\"status\":\"completed\",\"applicants\":{\"primaryConsumer\":{\"personalInformation\":{\"chileanRut\":\"147028431\",\"chileanSerialNumber\":\"A000000002\"},\"equifax-cl-kpi\":{\"KPI\":{\"kpiSection\":{\"attributes\":[{\"variableName\":\"KPI_NEG_AVON\",\"value\":\"1\"}]}},\"exclusionaryConditions\":{\"NotAvailable\":false,\"ErrorsPresent\":false},\"returnedProducts\":[\"KPI\"]},\"ccb\":{\"ccb\":{\"uuid\":\"630a8f52-43b3-4c75-9d2d-ffc4d06219b1\",\"transactionInfo\":{},\"expg04Section\":{}},\"exclusionaryConditions\":{\"ErrorsPresent\":false,\"NoHit\":false,\"NotAvailable\":false},\"nativeText\":{\"raw\":\"\",\"type\":\"reponse\"},\"returnedProducts\":[\"ccb\"]}}}}}},\"clientImplementationUUID\":\"2791e58f-25b4-4d77-8d82-20fa3eb81a9e\",\"clientImplementationDateCreated\":\"2019-05-30T15:00:40.060+0000\",\"clientImplementationDateModified\":null}";
        correctResponse = "{\"clientImplementationStatus\":\"completed\",\"applicants\":{\"primaryConsumer\":{\"IG_RESPONSE\":{\"transactionId\":\"112712000000030008\",\"status\":\"completed\",\"applicants\":{\"primaryConsumer\":{\"personalInformation\":{\"chileanRut\":\"147028431\",\"chileanSerialNumber\":\"A000000002\"},\"equifax-cl-kpi\":{\"KPI\":{\"kpiSection\":{\"attributes\":[{\"variableName\":\"KPI_NEG_AVON\",\"value\":\"1\"}]}},\"exclusionaryConditions\":{\"NotAvailable\":false,\"ErrorsPresent\":false},\"returnedProducts\":[\"KPI\"]},\"ccb\":{\"ccb\":{\"uuid\":\"630a8f52-43b3-4c75-9d2d-ffc4d06219b1\",\"transactionInfo\":{},\"expg04Section\":{}},\"exclusionaryConditions\":{\"ErrorsPresent\":false,\"NoHit\":false,\"NotAvailable\":false},\"nativeText\":{\"raw\":\"\",\"type\":\"reponse\"},\"returnedProducts\":[\"ccb\"]},\"equifax-cl-platinum360\":{\"platinum360\":{\"getInformePlatinum360Response\":{}},\"exclusionaryConditions\":{\"NotAvailable\":false,\"ErrorsPresent\":false},\"returnedProducts\":[\"platinum360\"]}}}}}},\"clientImplementationUUID\":\"2791e58f-25b4-4d77-8d82-20fa3eb81a9e\",\"clientImplementationDateCreated\":\"2019-05-30T15:00:40.060+0000\",\"clientImplementationDateModified\":null}";

        payload.put("INITIAL_REQUEST", new ObjectMapper().readTree(initialRequest));

    }

    @Test
    public void evaluateFalseCache() {
        Assert.assertFalse(cacheEvaluator.evaluateCache(payload, headers));
    }

    @Test
    public void evaluateTrueCache() {
        TransactionService transactionService = cacheEvaluator.getTransactionService();
        when(transactionService.findLastTransactionIdNotCachedBetweenDates(anyString(), any(Date.class), any(Date.class))).thenReturn("12345");

        Messages message = new Messages();
        message.setMessageBlob(correctResponse.getBytes());

        MessagesService messagesService = cacheEvaluator.getMessagesService();
        when(messagesService.getMessageResponseByTransactionId(anyString())).thenReturn(message);

        Assert.assertTrue(cacheEvaluator.evaluateCache(payload, headers));
    }

    @Test
    public void evaluateBadDatasources() {
        TransactionService transactionService = cacheEvaluator.getTransactionService();
        when(transactionService.findLastTransactionIdNotCachedBetweenDates(anyString(), any(Date.class), any(Date.class))).thenReturn("12345");

        Messages message = new Messages();
        message.setMessageBlob(badResponse1.getBytes());

        MessagesService messagesService = cacheEvaluator.getMessagesService();
        when(messagesService.getMessageResponseByTransactionId(anyString())).thenReturn(message);

        Assert.assertFalse(cacheEvaluator.evaluateCache(payload, headers));
    }

    @Test
    public void evaluateBadDatasource() {
        TransactionService transactionService = cacheEvaluator.getTransactionService();
        when(transactionService.findLastTransactionIdNotCachedBetweenDates(anyString(), any(Date.class), any(Date.class))).thenReturn("12345");

        Messages message = new Messages();
        message.setMessageBlob(badResponse2.getBytes());

        MessagesService messagesService = cacheEvaluator.getMessagesService();
        when(messagesService.getMessageResponseByTransactionId(anyString())).thenReturn(message);

        Assert.assertFalse(cacheEvaluator.evaluateCache(payload, headers));
    }

    @Test
    public void evaluateMissingDatasource() {
        TransactionService transactionService = cacheEvaluator.getTransactionService();
        when(transactionService.findLastTransactionIdNotCachedBetweenDates(anyString(), any(Date.class), any(Date.class))).thenReturn("12345");

        Messages message = new Messages();
        message.setMessageBlob(missingDatasource.getBytes());

        MessagesService messagesService = cacheEvaluator.getMessagesService();
        when(messagesService.getMessageResponseByTransactionId(anyString())).thenReturn(message);

        Assert.assertFalse(cacheEvaluator.evaluateCache(payload, headers));
    }

}