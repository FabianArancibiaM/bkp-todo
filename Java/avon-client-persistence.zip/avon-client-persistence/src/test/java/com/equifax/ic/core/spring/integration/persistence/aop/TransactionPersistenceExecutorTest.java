package com.equifax.ic.core.spring.integration.persistence.aop;


import com.equifax.ic.core.spring.integration.persistence.component.MicroServicesIdCollector;
import com.equifax.ic.core.spring.integration.persistence.component.TransactionPersistence;
import com.equifax.ic.core.spring.integration.persistence.factory.Factory;
import com.equifax.ic.core.spring.integration.persistence.pojo.Transaction;
import com.equifax.ic.core.spring.integration.persistence.service.FactoryService;
import com.equifax.ic.core.spring.integration.persistence.service.TransactionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TransactionPersistenceExecutorTest {

    @Mock
    TransactionPersistence transactionPersistence;

    @Mock
    TransactionService transactionService;

    @Mock
    MicroServicesIdCollector microServicesIdCollector;

    @Mock
    Map<Factory, FactoryService> factoriesContainer;

    @Mock
    ObjectMapper objectMapper;

    @Mock
    HttpServletRequest httpServletRequest;

    @InjectMocks
    com.equifax.ic.core.spring.integration.persistence.aop.TransactionPersistenceExecutor raTransactionPersistenceExecutor;

    ProceedingJoinPoint proceedingJoinPointMock;

    Map<String, Object> headersMock;

    String requestMock;


    ResponseEntity responseEntityMock;

    @Before
    public void before() throws Throwable {
        MockitoAnnotations.initMocks(this);

        when(httpServletRequest.getRequestURI()).thenReturn("/clinicabicentenario-client-implementation/api/transaction/CLINICABICE/config/baseline/TEST");

        when(transactionService.findTransactionById(null)).thenReturn(new Transaction());

        when(objectMapper.convertValue(null, Map.class)).thenReturn(new HashMap());

        headersMock = new HashMap<>();

        proceedingJoinPointMock = mock(ProceedingJoinPoint.class);

        responseEntityMock=new ResponseEntity(HttpStatus.ACCEPTED);

        when(proceedingJoinPointMock.proceed()).thenReturn(responseEntityMock);
        requestMock ="{\n" +
                "  \"applicants\": {\n" +
                "    \"primaryConsumer\": {\n" +
                "      \"personalInformation\": {\n" +
                "        \"chileanRut\": \"184566362\",\n" +
                "        \"chileanSerialNumber\": \"A000000002\",\n" +
                "        \"userName\": \"test\"\n" +
                "      }\n" +
                "    }\n" +
                "  }\n" +
                "}";
    }

    @Test
    public void aroundExecuteOrchestrationExecutionTest() throws Throwable {
        raTransactionPersistenceExecutor.aroundExecuteOrchestrationExecution(proceedingJoinPointMock,requestMock,headersMock);
    }


}
