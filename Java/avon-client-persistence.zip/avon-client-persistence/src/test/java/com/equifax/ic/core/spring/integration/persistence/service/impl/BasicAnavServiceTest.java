package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.AnavDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.AnavPojo;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BasicAnavServiceTest {


    private AnavDao anavDao;
    private BasicAnavService basicAnavService;

   @Before
    public void setUp(){
        basicAnavService = new BasicAnavService();
        anavDao = mock(AnavDao.class);
    }

    @Test
    public void getAllAnavs() {
        ReflectionTestUtils.setField(this.basicAnavService,"anavDao", this.anavDao);
        when(anavDao.findAll()).thenReturn(new LinkedList<>());
        Assert.assertNotNull(basicAnavService.getAllAnavs());
    }

    @Test
    public void getAnavById() {
        ReflectionTestUtils.setField(this.basicAnavService,"anavDao", this.anavDao);
        when(anavDao.findOne(Mockito.anyLong())).thenReturn(new AnavPojo());
        basicAnavService.getAnavById((Mockito.anyLong()));
    }

    @Test
    public void insertAnav() {
        ReflectionTestUtils.setField(this.basicAnavService,"anavDao", this.anavDao);
        when(anavDao.save(Mockito.any(AnavPojo.class))).thenReturn(new AnavPojo());
        basicAnavService.insertAnav(new AnavPojo());
    }

    @Test
    public void updateAnav() {
        ReflectionTestUtils.setField(this.basicAnavService,"anavDao", this.anavDao);
        when(anavDao.save(Mockito.any(AnavPojo.class))).thenReturn(new AnavPojo());
        when(basicAnavService.getAnavById(Mockito.anyLong())).thenReturn(new AnavPojo());
        try {
            basicAnavService.updateAnav((new AnavPojo()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void insertList() {
        List<AnavPojo> anavDecisioningList= new ArrayList();
        anavDecisioningList.add(new AnavPojo());

        ReflectionTestUtils.setField(this.basicAnavService,"anavDao", this.anavDao);
        when(anavDao.save(Mockito.any(AnavPojo.class))).thenReturn(new AnavPojo());
        basicAnavService.insertList(anavDecisioningList);
    }
}