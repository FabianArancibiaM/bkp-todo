package com.equifax.ic.core.spring.integration.persistence.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class ConstantTest {

	@Test
	public void test() {
		Constant c = new Constant();
		assertNotNull(c);
		assertNotNull(c.ID_NUMBER);
	}

}
