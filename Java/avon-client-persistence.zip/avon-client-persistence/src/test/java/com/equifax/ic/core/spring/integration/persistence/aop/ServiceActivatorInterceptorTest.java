package com.equifax.ic.core.spring.integration.persistence.aop;

import com.equifax.ic.core.spring.integration.persistence.component.MicroServicesIdCollector;
import com.equifax.ic.core.spring.integration.persistence.util.PersistenceDomain;
import com.equifax.ic.product.clientconfig.domain.impl.ServiceActivator;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.integration.history.MessageHistory;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Constructor;
import java.util.*;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ServiceActivatorInterceptorTest {
    @Mock
    private Environment environmentMock;
    @InjectMocks
    private ServiceActivatorInterceptor serviceActivatorInterceptor;
    private Map<String, Object> headers;
    private MicroServicesIdCollector microServicesIdCollector;
    private Map<String, Object> microServicesMap;
    private String serviceId = "8c185b2e-16a1-45ca-b9a0-97020c2a290f";

    private static final String HISTORY = "history";

    @Before
    public void setUp() throws Exception {
        serviceActivatorInterceptor = new ServiceActivatorInterceptor();
        headers = new LinkedHashMap<>();
        microServicesMap = new LinkedHashMap<>();
        microServicesIdCollector = mock(MicroServicesIdCollector.class);

        ReflectionTestUtils.setField(serviceActivatorInterceptor, "microServicesIdCollector", microServicesIdCollector);
        environmentMock = mock(Environment.class);

        HashSet<String> mitList = new HashSet<>();
        mitList.add(serviceId);
        microServicesMap.put("mitList", mitList);

        List<Properties> propertiesList = new ArrayList<>();
        Properties property = new Properties();
        property.setProperty("name", serviceId);
        propertiesList.add(property);

        Constructor[] constructor = MessageHistory.class.getDeclaredConstructors();
        constructor[0].setAccessible(true);
        MessageHistory messageHistory = (MessageHistory) constructor[0].newInstance(propertiesList);

        headers.put(HISTORY, messageHistory);
    }

    @Test
    public void parametersBuilderTest() throws Exception {

        when(microServicesIdCollector.getMicroServicesMap()).thenReturn(microServicesMap);
        when(microServicesIdCollector.getServiceName(anyString())).thenReturn(serviceId);

        String executionTime = PersistenceDomain.BEFORE.toString();
        ReflectionTestUtils.invokeMethod(serviceActivatorInterceptor, "parametersBuilder", headers, executionTime);
    }

    @Test
    public void aroundGetApplicationUrlTest() throws Throwable {
        Mockito.when(environmentMock.getProperty("servicesLoadBalancerURL.insightgateway.enabled")).thenReturn("true");
        Mockito.when(environmentMock.getProperty("servicesLoadBalancerURL.insightgateway.baseUrl"))
                .thenReturn("http://localhost/insightgateway");
        ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
        ReflectionTestUtils.setField(serviceActivatorInterceptor, "environment", environmentMock);
        ServiceActivator serviceActivator = new ServiceActivator();
        serviceActivator.setApplicationId("insightgateway");
        serviceActivator.setServicePath("/apu/report/DPMAR/Test");
        serviceActivatorInterceptor.aroundGetApplicationUrl(joinPoint, serviceActivator);
    }
}