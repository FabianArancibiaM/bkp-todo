package com.equifax.ic.core.spring.integration.persistence.component.cache;

import com.equifax.ic.core.spring.integration.persistence.exception.OrchestrationCacheException;
import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import com.equifax.ic.core.spring.integration.persistence.service.MessagesService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CacheExecutorTest {

    private CacheExecutor cacheExecutor = new CacheExecutor();
    private Map<String, Object> headers = new LinkedHashMap<>();
    private Messages message;

    @Before
    public void setUp() throws Exception {
        headers.put("transactionIdForCache", "12345");
        cacheExecutor.setMessagesService(mock(MessagesService.class));
        cacheExecutor.setObjectMapper(new ObjectMapper());

        message = new Messages();
        message.setMessageBlob("{\"status\": \"test\"}".getBytes());
    }

    @Test
    public void executeCache() {
        MessagesService messagesService = cacheExecutor.getMessagesService();
        when(messagesService.getMessageResponseByTransactionId(anyString())).thenReturn(message);
        Assert.assertNotNull(cacheExecutor.executeCache(headers));
    }

    @Test(expected = OrchestrationCacheException.class)
    public void executeCacheNoMessage() {
        MessagesService messagesService = cacheExecutor.getMessagesService();
        when(messagesService.getMessageResponseByTransactionId(anyString())).thenReturn(null);
        cacheExecutor.executeCache(headers);
    }

    @Test(expected = OrchestrationCacheException.class)
    public void executeCacheNoTransactionId() {
        headers.clear();
        cacheExecutor.executeCache(headers);
    }
}