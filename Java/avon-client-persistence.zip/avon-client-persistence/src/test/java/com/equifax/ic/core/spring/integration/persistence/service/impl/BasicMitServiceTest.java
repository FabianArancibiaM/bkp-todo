package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.MitDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.MitPojo;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BasicMitServiceTest {

    private BasicMitService basicMitService;
    private MitDao mitDao;

    @Before
    public void setUp() {
        basicMitService = new BasicMitService();
        mitDao = mock(MitDao.class);
    }

    @Test
    public void getAllMit() {
        ReflectionTestUtils.setField(this.basicMitService,"mitDao", this.mitDao);
        when(mitDao.findAll()).thenReturn(new LinkedList<>());
        basicMitService.getAllMit();
    }

    @Test
    public void getMitById() {
        ReflectionTestUtils.setField(this.basicMitService,"mitDao", this.mitDao);
        when(mitDao.findOne(Mockito.anyLong())).thenReturn(new MitPojo());
        basicMitService.getMitById((Mockito.anyLong()));
    }

    @Test
    public void insertMit() {
        ReflectionTestUtils.setField(this.basicMitService,"mitDao", this.mitDao);
        when(mitDao.save(Mockito.any(MitPojo.class))).thenReturn(new MitPojo());
        basicMitService.insertMit(new MitPojo());
    }

    @Test
    public void updateMit() {
        ReflectionTestUtils.setField(this.basicMitService,"mitDao", this.mitDao);
        when(mitDao.save(Mockito.any(MitPojo.class))).thenReturn(new MitPojo());
        when(basicMitService.getMitById(Mockito.anyLong())).thenReturn(new MitPojo());
        try {
            basicMitService.updateMit((new MitPojo()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void insertList() {
        List<MitPojo> mitDecisioningList= new ArrayList();
        mitDecisioningList.add(new MitPojo());

        ReflectionTestUtils.setField(this.basicMitService,"mitDao", this.mitDao);
        when(mitDao.save(Mockito.any(MitPojo.class))).thenReturn(new MitPojo());
        basicMitService.insertList(mitDecisioningList);
    }
}