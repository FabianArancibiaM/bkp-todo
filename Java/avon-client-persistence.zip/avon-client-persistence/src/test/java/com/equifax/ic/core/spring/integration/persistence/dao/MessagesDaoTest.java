package com.equifax.ic.core.spring.integration.persistence.dao;

import com.equifax.ic.core.spring.integration.persistence.config.PersistenceConfiguration;
import com.equifax.ic.core.spring.integration.persistence.pojo.Messages;
import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = PersistenceConfiguration.class)
@DataJpaTest
@AutoConfigureTestDatabase
public class MessagesDaoTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private MessagesDao messagesDao;

    private Messages message2;

    @Before
    public void initialConfig() {

        SystemEvent systemEvent1 = new SystemEvent();
        systemEvent1.setDescription("Transaction completion");
        systemEvent1.setUuid("1111");

        SystemEvent systemEvent2 = new SystemEvent();
        systemEvent2.setDescription("Transaction completion");
        systemEvent2.setUuid("2222");

        SystemEvent systemEvent3 = new SystemEvent();
        systemEvent3.setDescription("Transaction initiation");
        systemEvent3.setUuid("2222");

        entityManager.persist(systemEvent1);
        entityManager.persist(systemEvent2);
        entityManager.persist(systemEvent3);

        Messages message1 = new Messages();
        message1.setMessageBlob("Response 1111".getBytes());
        message1.setIdSystemEvent(systemEvent1.getId());

        message2 = new Messages();
        message2.setMessageBlob("Response 2222".getBytes());
        message2.setIdSystemEvent(systemEvent2.getId());

        Messages message3 = new Messages();
        message3.setMessageBlob("Request 2222".getBytes());
        message3.setIdSystemEvent(systemEvent3.getId());

        entityManager.persist(message1);
        entityManager.persist(message2);
        entityManager.persist(message3);
    }

    @Test
    public void getMessageByTransactionIdNotNull() {
        Assert.assertNotNull(this.messagesDao.getMessageResponseByTransactionId("1111"));
    }

    @Test
    public void getMessageByTransactionId() {
        Messages message = this.messagesDao.getMessageResponseByTransactionId("2222");
        Assert.assertSame(message2, message);
    }
}