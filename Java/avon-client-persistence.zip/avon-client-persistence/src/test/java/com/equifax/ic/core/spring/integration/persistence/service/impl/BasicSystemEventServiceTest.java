package com.equifax.ic.core.spring.integration.persistence.service.impl;

import com.equifax.ic.core.spring.integration.persistence.dao.SystemEventDao;
import com.equifax.ic.core.spring.integration.persistence.pojo.SystemEvent;
import com.equifax.ic.core.spring.integration.persistence.service.SystemEventService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BasicSystemEventServiceTest {

    private BasicSystemEventService basicSystemEventService;

    private SystemEventDao systemEventDao;

    @Before
    public void setUp() throws Exception {

        basicSystemEventService = new BasicSystemEventService();

        systemEventDao = mock(SystemEventDao.class);
    }

    @Test
    public void getAllSystemEvents() {
        ReflectionTestUtils.setField(this.basicSystemEventService,"systemEventDao", this.systemEventDao);
        when(systemEventDao.findAll()).thenReturn(new LinkedList<SystemEvent>());
        basicSystemEventService.getAllSystemEvents();
    }

    @Test
    public void getSystemEventById() {
        ReflectionTestUtils.setField(this.basicSystemEventService,"systemEventDao", this.systemEventDao);
        when(systemEventDao.findOne(Mockito.anyLong())).thenReturn(new SystemEvent());
        basicSystemEventService.getSystemEventById((Mockito.anyLong()));
    }

    @Test
    public void saveNewSystemEvent() {
        ReflectionTestUtils.setField(this.basicSystemEventService,"systemEventDao", this.systemEventDao);
        when(systemEventDao.save(Mockito.any(SystemEvent.class))).thenReturn(new SystemEvent());
        basicSystemEventService.saveNewSystemEvent(new SystemEvent());
    }

    @Test
    public void updateSystemEvent() {
        ReflectionTestUtils.setField(this.basicSystemEventService,"systemEventDao", this.systemEventDao);
        when(systemEventDao.save(Mockito.any(SystemEvent.class))).thenReturn(new SystemEvent());
        when(basicSystemEventService.getSystemEventById(Mockito.anyLong())).thenReturn(new SystemEvent());

        try {
            basicSystemEventService.updateSystemEvent((new SystemEvent()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void insertList() {
        List<SystemEvent> systemEventList= new ArrayList();
        systemEventList.add(new SystemEvent());

        ReflectionTestUtils.setField(this.basicSystemEventService,"systemEventDao", this.systemEventDao);
        when(systemEventDao.save(Mockito.any(SystemEvent.class))).thenReturn(new SystemEvent());
        basicSystemEventService.insertList(systemEventList);
    }
}