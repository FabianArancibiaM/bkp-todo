package com.equifax.ic.core.spring.integration.persistence.factory.impl;

import com.equifax.ic.core.spring.integration.persistence.pojo.AnavPojo;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

public class AnavAttributeAccessFactoryTest {

    private AnavAttributeAccessFactory anavAttributeAccessFactory;
    private List<AnavPojo> anavPojoList;

    @Before
    public void setUp() throws Exception {
        anavAttributeAccessFactory = new AnavAttributeAccessFactory();
        anavPojoList = new ArrayList<>();
    }

    @Test
    public void logAnavAttributeAccess() {
        anavAttributeAccessFactory.logAnavAttributeAccess("", "", "", "");
    }

    @Test
    public void getList() {
        ReflectionTestUtils.setField(this.anavAttributeAccessFactory, "anavPojoList", this.anavPojoList);
        anavAttributeAccessFactory.getList();
    }

    @Test
    public void setAnavList() {
        ReflectionTestUtils.setField(this.anavAttributeAccessFactory, "anavPojoList", this.anavPojoList);
        anavAttributeAccessFactory.setAnavList(null);
    }
}